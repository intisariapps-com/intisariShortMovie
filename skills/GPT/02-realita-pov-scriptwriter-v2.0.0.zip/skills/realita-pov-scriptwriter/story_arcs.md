# Kerangka Cerita (Arc)

Pilih **satu** arc per naskah, sesuai ide dan pilihan pengguna. Jangan memakai arc yang sama berulang kali dalam satu percakapan bila pengguna meminta beberapa naskah. Semua arc tunduk pada `style_dna.md` (empati, tidak menghakimi).

## A. Kemenangan Hening
Cocok: tokoh sederhana yang konsisten pada prinsip, diremehkan, lalu terbukti kuat.
1. **Hook kontras**: penampilan bersahaja vs omongan orang.
2. **Flashback & prinsip**: awal perjuangan, prinsip baku, pasangan/rekan sefrekuensi.
3. **Kontras & krisis**: pemburu gengsi dan badai nyata; tokoh utama tetap tenang.
4. **Kemenangan hening & rangkulan**: tokoh utama menolong tanpa arogansi.
Akhir: tenteram dan hangat. Jaga: jatuhnya lawan bukan klimaks yang dirayakan; jangan membuat tokoh utama tanpa cela sama sekali (beri satu keraguan atau harga yang dibayar).

## B. Kamu yang Hampir Keliru
Cocok: godaan gengsi, cicilan, atau tekanan sosial.
1. Kamu berdiri di depan satu keputusan (membeli, ikut, menyetujui).
2. Tekanan datang dari omongan orang dan keinginan sendiri.
3. Satu pertanyaan atau kejadian kecil membuat Kamu berhenti.
4. Kamu memilih, dengan rasa tidak enak yang jujur; tidak ada tepuk tangan.
Akhir: tenang, belajar, tanpa pahlawan.

## C. Tanpa Antagonis
Cocok: tekanan dari keadaan atau diri sendiri (lelah, takut tertinggal, rasa bersalah).
1. Hari biasa yang mulai terasa berat.
2. Beban menumpuk tanpa ada yang "jahat".
3. Titik sunyi: Kamu berhadapan dengan diri sendiri.
4. Langkah kecil yang mengubah arah.
Akhir: lega yang sederhana.

## D. Pembalikan Sudut Pandang
Cocok: yang dikira pemamer ternyata memikul beban.
1. Kamu menilai seseorang dari luar.
2. Detail kecil mulai tidak cocok dengan penilaianmu.
3. Kebenaran terungkap lewat kejadian, bukan penjelasan.
4. Kamu mengoreksi diri, tanpa menggurui.
Akhir: empati menggantikan kesimpulan cepat.

## E. Akhir Terbuka / Getir
Cocok: pilihan sulit tanpa jawaban benar-salah yang jelas.
1. Situasi dilematis yang nyata.
2. Dua pilihan, masing-masing dengan harga.
3. Kamu memilih salah satu.
4. Akibat tidak sepenuhnya jelas; naskah berhenti dengan pertanyaan yang tertinggal.
Akhir: hangat tetapi tidak menyelesaikan segalanya.

## F. Bersama-sama
Cocok: masalah lingkungan, keluarga besar, atau komunitas.
1. Masalah bersama muncul.
2. Beberapa orang bergerak dengan caranya masing-masing.
3. Tidak ada satu pahlawan; kontribusi kecil menumpuk.
4. Kamu ada di antara mereka, bukan di atas mereka.
Akhir: kebersamaan, tanpa panggung.
