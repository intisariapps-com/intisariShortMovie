# Panjang Naskah & Aturan TTS

## Jumlah kata per durasi
Kecepatan baca lisan Indonesia natural: **2,2-2,5 kata/detik** (~135-150 WPM).

| Durasi | Perkiraan kata | Hook (maks.) |
|---|---|---|
| 1 menit | 130-150 | ~8 dtk |
| 3 menit | 400-450 | ~15 dtk |
| 5 menit | 660-750 | ~15 dtk |

Naskah dengan jeda dramatis atau dialog banyak boleh sedikit di bawah rentang. Bila pengguna memberi durasi lain, hitung dengan 135 kata/menit sebagai patokan awal.

## Menulis untuk telinga
- Kalimat ringkas, rata-rata di bawah 18-20 kata, dengan jeda napas lewat koma dan titik.
- Tulis persis seperti narator berbicara; hindari kalimat bersusun panjang.

## TTS-safe
- Tulis angka dan satuan sebagaimana diucapkan: "lima belas juta rupiah", "tujuh puluh satu persen", "jam sembilan malam".
- Tulis singkatan sebagaimana dibaca: "WhatsApp", bukan "WA"; PHK dan KUA boleh karena umum dieja.
- Tanpa emoji, tanpa simbol (`@ # & / %`), tanpa tanda kurung untuk catatan, tanpa huruf kapital semua untuk penekanan, tanpa tanda seru berlebihan.
- Dialog ditulis dengan tanda kutip biasa dan kata kerja bicara yang jelas ("katanya", "bisiknya").
