# Kategori 5: Sosial Lingkungan, Tetangga Komplek & Drama Arisan

Kehidupan bertetangga di perumahan: persaingan renovasi pagar, sindiran mobil baru di grup WhatsApp komplek, arisan mewah, dan kebiasaan menilai orang dari barang di garasi.

## 1. Persona tokoh utama
- Penghuni komplek bermotor tua yang jarang ikut pamer di grup chat, menolak arisan konsumtif, dan lebih suka merawat pekarangan atau mengajari anak-anak warga secara sukarela.

## 2. Sosok tekanan / lawan
- Warga atau pengurus paguyuban yang haus pengakuan, mendokumentasikan setiap renovasi, dan menebar rumor miring tentang warga yang hidup tenang.
- Alternatif: **tanpa lawan**, hanya sepi dan rasa tidak diterima di lingkungan.

## 3. Pemicu & arah plot
- **Krisis**: masalah warga, misalnya gorong-gorong mangkrak, iuran bermasalah, atau kebutuhan dana talangan darurat.
- **Twist**: yang paling vokal menghilang saat dimintai bantuan nyata; tokoh utama membantu tanpa minta namanya diumumkan.
- **Resolusi (versi arc A)**: warga tahu siapa yang tulus. Pada arc lain, terutama F, bantuan datang dari banyak orang. Sesuaikan dengan `story_arcs.md`.

## 4. Arc yang cocok
A, C, D, F.

## 5. Arah hook & CTA (topik, bukan kalimat)
- Hook: kebiasaan kecil tokoh yang diketahui semua orang (suara motor, rutinitas pagi) vs bisik-bisik di arisan.
- CTA tengah: berhenti peduli kata tetangga. CTA akhir: pamer atau tetap sederhana bila rezeki berlebih.
