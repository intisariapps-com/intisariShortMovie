# Kategori 2: Karir, Dunia Kerja & Side-Hustle Diam-Diam

Dinamika korporat: jebakan promosi yang memeras waktu (*golden handcuffs*), karyawan santai yang diam-diam membangun kemandirian ekonomi, *silent quitting* yang produktif.

## 1. Persona tokoh utama
- Staf operasional/IT/administrasi yang bekerja tepat waktu dan tidak gila hormat jabatan.
- Di luar jam kerja membangun bisnis digital, toko online, atau ternak sampingan tanpa bercerita ke rekan.
- Prinsip: pekerjaan utama adalah penyedia modal dan asuransi, bukan sumber harga diri mutlak.

## 2. Sosok tekanan / lawan
- Rekan atau atasan yang membanggakan lembur dan menyindir yang pulang tepat waktu.
- Alternatif: **tanpa lawan**, hanya rasa bersalah karena pulang lebih awal.

## 3. Pemicu & arah plot
- **Krisis**: efisiensi mendadak atau bonus dibatalkan; yang menyerahkan seluruh hidup ke kantor terguncang.
- **Twist**: tokoh utama mengajukan *resign* dengan tabungan darurat dan penghasilan sampingan yang sudah cukup.
- **Resolusi (versi arc A)**: atasan yang dulu mencibir bertanya soal peluang kemitraan. Pada arc lain, sesuaikan dengan `story_arcs.md`.

## 4. Arc yang cocok
A, B, C, E.

## 5. Arah hook & CTA (topik, bukan kalimat)
- Hook: momen pamit pulang tepat waktu dengan tatapan orang di ruangan; atau satu notifikasi transaksi di malam hari.
- CTA tengah: bekerja untuk hidup vs hidup untuk bekerja. CTA akhir: resign atau bertahan bila sampingan sudah menutup kebutuhan.
