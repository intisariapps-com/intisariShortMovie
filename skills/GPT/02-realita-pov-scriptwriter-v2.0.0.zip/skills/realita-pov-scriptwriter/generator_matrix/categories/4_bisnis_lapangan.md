# Kategori 4: Bisnis Lapangan, Juragan Tradisional vs Startup Gengsi

UMKM lapangan: juragan rongsokan, pengepul barang bekas, peternak bebek, penjual warung tegal. Penampilannya biasa saja, tetapi arus kas hariannya kuat.

## 1. Persona tokoh utama
- Pengusaha sektor riil tradisional yang tidak peduli citra: tanpa jas, tidak nongkrong di kafe mahal, tetapi arus kas harian likuid dan tanpa utang bank.

## 2. Sosok tekanan / lawan
- Pebisnis pemula yang mengutamakan kemasan (ruang kerja estetik, mobil cicilan, kartu nama berlapis emas) dengan arus kas operasional defisit dan bergantung pada investor atau utang.
- Alternatif: **tanpa lawan**, tokoh utama sendiri yang ragu apakah usahanya "cukup keren".

## 3. Pemicu & arah plot
- **Krisis**: musim sulit pendanaan atau kenaikan bunga yang mematikan bisnis bermodal gengsi; atau lonjakan bahan baku.
- **Twist**: usaha tradisional tetap dicari karena menjual kebutuhan harian.
- **Resolusi (versi arc A)**: tokoh utama membeli aset yang dilelang bank secara tunai tanpa menyombongkan diri. Pada arc lain, sesuaikan dengan `story_arcs.md`.

## 4. Arc yang cocok
A, C, D, E.

## 5. Arah hook & CTA (topik, bukan kalimat)
- Hook: penampilan lusuh di pinggir jalan vs sorotan orang di seberang; atau satu nota/sertifikat yang tidak disangka.
- CTA tengah: menilai orang dari pakaian. CTA akhir: bisnis terlihat keren tetapi boncos vs terlihat kotor tetapi menghasilkan.
