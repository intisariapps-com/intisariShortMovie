# Kategori 1: Finansial, Frugal Living & Stealth Wealth

Edukasi keuangan praktis dalam bentuk cerita: dividen, *compounding*, menghindari jeratan gaya hidup (*hedonic treadmill*), membedakan aset produktif dari beban gengsi. Semua angka adalah ilustrasi fiksi, bukan nasihat investasi.

## 1. Persona tokoh utama
- Pekerja kantoran biasa, analis data, atau staf dengan penghasilan rata-rata.
- Prinsip: menyisihkan gaji di awal bulan (*pay yourself first*), menghindari pinjaman konsumtif (paylater/kartu kredit), memakai barang sampai rusak.
- Pasangan yang satu visi, lebih menghargai rasa aman finansial daripada validasi sosial.

## 2. Sosok tekanan / lawan
- Manajer, teman kantor, atau tetangga berpenghasilan besar yang uangnya habis untuk cicilan rumah, mobil, dan liburan demi tampil di medsos; gemar mencibir kesederhanaan orang lain.
- Alternatif: **tanpa lawan**, hanya godaan cicilan dan rasa takut tertinggal pada diri tokoh sendiri.

## 3. Pemicu & arah plot
- **Krisis**: resesi atau restrukturisasi kantor yang memicu PHK.
- **Twist**: pesangon yang cepat habis karena cicilan, sementara tokoh utama tetap tenang.
- **Resolusi (versi arc A)**: menyeduhkan kopi, membantu membedah daftar utang dengan empati. Pada arc lain, sesuaikan dengan `story_arcs.md`.

## 4. Arc yang cocok
A, B, C, D.

## 5. Arah hook & CTA (topik, bukan kalimat)
- Hook: kontras rutinitas santai pada jam kerja vs bahan omongan orang; atau satu angka cicilan yang tidak masuk akal.
- CTA tengah: pasangan/kebiasaan yang sepaham soal uang. CTA akhir: bertahan bekerja atau berhenti bila penghasilan pasif cukup.
