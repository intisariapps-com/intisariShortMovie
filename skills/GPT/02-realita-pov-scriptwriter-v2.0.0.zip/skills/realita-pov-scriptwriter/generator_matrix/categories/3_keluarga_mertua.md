# Kategori 3: Keluarga, Mertua & Pasangan Sefrekuensi

Drama keluarga besar: tuntutan resepsi mewah demi gengsi orang tua/mertua, tradisi pamer saat kumpul Lebaran, dan ketangguhan pasangan yang kompak memilih hidup sederhana.

## 1. Persona tokoh utama
- Pasangan muda yang memilih akad sederhana atau resepsi intim, mengalihkan anggaran pesta untuk rumah mungil atau modal usaha bersama.
- Tetap tenang saat dibandingkan dengan ipar atau saudara yang berpesta megah.

## 2. Sosok tekanan / lawan
- Kerabat atau mertua yang mementingkan status di mata tetangga kampung, gemar membanding-bandingkan menantu, mas kawin, atau mobil.
- Alternatif: **tanpa lawan**, konflik batin pasangan sendiri saat tradisi dan kemampuan tidak sejalan.

## 3. Pemicu & arah plot
- **Krisis**: saudara yang berpesta mewah terbebani utang vendor dan cicilan bertahun-tahun; rumah tangganya renggang.
- **Twist**: tokoh utama hidup tenteram tanpa tagihan akhir bulan dan menjadi tempat bersandar saat keluarga besar kesulitan.
- **Resolusi (versi arc A)**: mertua menyadari ketenangan menantunya lebih berharga daripada komentar tamu semalam. Pada arc lain, sesuaikan dengan `story_arcs.md`.

## 4. Arc yang cocok
A, B, D, E, F.

## 5. Arah hook & CTA (topik, bukan kalimat)
- Hook: bisikan sindiran di ruang keluarga saat pengumuman sederhana; atau satu benda dari hari pernikahan.
- CTA tengah: menyebut pasangan/keluarga yang disyukuri. CTA akhir: pesta mewah bercicil vs akad sederhana dengan rumah.
