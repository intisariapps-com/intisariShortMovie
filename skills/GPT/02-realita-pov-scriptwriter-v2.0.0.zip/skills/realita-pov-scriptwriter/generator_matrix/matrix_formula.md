# Matriks Premis Realita-POV

Mesin ide untuk mengatasi *writer's block*. Premis dirakit dari variabel di bawah; hasilnya harus **berbeda struktur**, bukan hanya berbeda kostum.

## Rumus
`Premis = Tokoh (A) × Tekanan (B) × Krisis (C) × Penutup (D) × Arc (E) × Latar (F) × Nada (G)`

## Variabel

**A. Tokoh utama ("Kamu")**
1. Analis data/IT remote di kampung yang dikira pengangguran
2. Guru honorer bergaji minim yang konsisten menabung
3. Pemilik warung makan kaki lima/toko kelontong bermotor butut
4. Karyawan logistik yang disiplin berinvestasi
5. Mekanik bengkel kecil yang hidup tanpa cicilan
6. Ibu rumah tangga yang mengelola uang keluarga dengan ketat

**B. Tekanan / lawan** (boleh tanpa antagonis)
1. Tetangga bergaji besar tetapi cicilannya menyedot gaji
2. Rekan kerja yang gonta-ganti gadget lewat paylater
3. Kerabat/mertua yang menuntut pesta mewah demi gengsi
4. Teman lama yang pamer gaya hidup di medsos
5. Pemilik usaha kekinian yang meremehkan pedagang tradisional
6. **Tanpa lawan**: rasa lelah, takut tertinggal, atau godaan sendiri

**C. Krisis**
1. PHK massal/restrukturisasi kantor
2. Pasar saham jatuh/resesi lokal
3. Sakit mendadak anggota keluarga tanpa dana darurat
4. Cicilan/pinjol jatuh tempo
5. Lonjakan harga bahan baku yang mematikan usaha
6. Masalah bersama warga (dana, fasilitas, bencana kecil)

**D. Penutup**
1. Tokoh utama menyeduhkan kopi dan membantu memetakan jalan keluar
2. Melunasi sesuatu tanpa mencantumkan nama
3. Menawarkan modal kerja darurat dengan tulus
4. Lingkungan mendadak hening dan menyadari sesuatu
5. Hidup berjalan biasa; tidak ada yang berubah selain cara Kamu memandangnya
6. Berhenti di pertanyaan yang tertinggal

**E. Arc**: A Kemenangan Hening · B Hampir Keliru · C Tanpa Antagonis · D Pembalikan Sudut Pandang · E Akhir Terbuka · F Bersama-sama (lihat `story_arcs.md`)

**F. Latar**: kota besar Jabodetabek · kota menengah Jawa · desa/kampung · kota Sumatra · kota Sulawesi/Kalimantan · pesisir/pulau kecil

**G. Nada**: hangat · getir-lucu · hening-reflektif · tegang tertahan

Usia dan jenis kelamin tokoh utama dibuat bervariasi antar premis (muda 25-35, paruh baya 35-50, 50+).

## Cara memutar (ikuti urutan)
1. **Pilih kombinasi.**
   - Jika pengguna memberi angka bebas (*seed*), turunkan indeks tiap variabel: `((seed × k) mod jumlah_pilihan) + 1` dengan k berurutan 3, 5, 7, 11, 13, 17, 19. Untuk tiga premis, pakai seed, seed+1, seed+2.
   - Jika tidak ada angka, susun 3 premis sendiri dengan syarat: berbeda pada **minimal 4 dari 7 variabel**, memakai **minimal 2 arc berbeda**, dan latarnya tidak sama.
2. **Cek kebaruan**: jangan mengulang tokoh, latar, atau kombinasi yang sudah ditawarkan sebelumnya dalam percakapan.
3. **Satu kategori saja**: bila pengguna memilih premis, baca satu file di `categories/` yang paling dekat (1 Finansial, 2 Karir, 3 Keluarga, 4 Bisnis, 5 Sosial) untuk detail tokoh, tekanan, dan arah plot.
4. **Sajikan 3 premis singkat**, masing-masing berisi: premis 2 kalimat, arc, latar, nada, dan arah hook (tipe dari `hooks_and_ctas.md`).
5. Tanyakan: "Dari ketiga premis ini, nomor berapa yang paling pas untuk kita kembangkan?"

Contoh bentuk (jangan dipakai ulang sebagai premis): *Guru honorer di kota kecil Sulawesi (arc B, nada getir-lucu) hampir ikut arisan mewah karena sindiran rekan guru; satu pertanyaan muridnya membuatnya menunda.*
