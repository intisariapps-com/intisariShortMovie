# Hook & CTA

Berikut **tipe**, bukan kalimat siap pakai. Pilih satu, lalu bangun kalimat baru dengan tokoh, waktu, tempat, dan benda yang berbeda dari naskah sebelumnya. Jangan menyalin pola contoh kata per kata.

## Tipe hook (pilih satu; rotasi antar naskah)
1. **Adegan kontras**: tampilan luar yang bersahaja vs omongan atau kenyataan di baliknya.
2. **Benda kecil**: mulai dari satu benda (kunci, struk, helm, nota) yang membuka cerita.
3. **Ucapan orang lain**: kutipan sindiran atau gosip yang langsung dialamatkan ke Kamu.
4. **Angka janggal**: satu angka spesifik yang terasa tidak cocok dengan situasinya.
5. **Di tengah krisis (in medias res)**: mulai saat masalah sudah terjadi, lalu mundur.
6. **Pertanyaan tidak nyaman**: satu pertanyaan jujur yang menusuk, bukan retoris biasa.
7. **Kebiasaan aneh**: rutinitas tokoh yang membuat orang heran.

Skala hook mengikuti durasi (lihat `tts_and_length.md`): kira-kira 10-15% dari total durasi dan maksimal 15 detik.

## Tipe CTA tengah (refleksi pribadi)
- Ajak penonton mengingat pengalaman sendiri ("pernah gak...").
- Minta menyebut satu hal kecil yang mereka syukuri.
- Ajak menandai orang yang cocok dengan situasi cerita.

## Tipe CTA akhir (pemicu opini)
- Dilema dua pilihan dengan harga masing-masing.
- Prediksi: "kalau kamu jadi dia, apa yang kamu lakukan?"
- Pertanyaan angka atau takaran: "berapa lama kamu bertahan?"
- Pengakuan jujur yang aman dijawab di komentar.

## Aturan variasi
- Jangan menutup kedua CTA dengan frasa yang sama (mis. keduanya "tulis di komentar"). Ganti kata kerja ajakan: sebut, ceritakan, tandai, pilih, jawab jujur.
- CTA harus menyatu dengan cerita dan nada narator, bukan terdengar seperti iklan.
- Dilarang CTA yang menyudutkan atau mengadu penonton.
