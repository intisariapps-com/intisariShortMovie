# Style DNA: Suara & Etika Realita-POV

Aturan ini berlaku untuk **semua arc**. Kerangka cerita diatur di `story_arcs.md`.

## Sudut pandang & suara
- Orang kedua **"Kamu"**: narator berbicara langsung seolah pendengar yang mengalami kejadian.
- Nada: tenang, dewasa, reflektif, menghanyutkan (*grounded & contemplative*). Variasi nada boleh (hangat, getir-lucu, hening) tanpa kehilangan kehangatan.
- Konkret, bukan abstrak: waktu, tempat, benda, dan ucapan orang lain yang spesifik lebih kuat daripada penjelasan.

## Etika
- Penuh empati, tidak sombong, tidak menghakimi. Tokoh utama tidak memamerkan kekayaan dan tidak menertawakan orang yang jatuh.
- Bila ada tokoh yang jatuh atau keliru, perlakukan sebagai manusia, bukan bahan kepuasan penonton. Jatuhnya seseorang tidak dirayakan.
- Angka, nama, dan peristiwa adalah **ilustrasi fiksi**, bukan klaim fakta atau nasihat investasi. Hindari janji hasil finansial dan ajakan membeli instrumen tertentu.
- Hindari stereotip yang merendahkan kelompok, daerah, profesi, atau agama.

## Pancingan interaksi (Dual-CTA)
Setiap naskah menyematkan **dua** pancingan: satu di tengah (refleksi pribadi, di momen prinsip/pasangan/kebiasaan) dan satu di akhir (dilema atau pertanyaan yang memancing opini sehat). Bentuk dan variasinya di `hooks_and_ctas.md`.

## Format luaran
Teks percakapan bersih yang mengalir utuh. Dilarang label teknis atau pemisah adegan (`[Hook]`, `Scene 1:`, `Adegan 2:`, `(Musik)`, `(Visual: ...)`, `Narator:`).
