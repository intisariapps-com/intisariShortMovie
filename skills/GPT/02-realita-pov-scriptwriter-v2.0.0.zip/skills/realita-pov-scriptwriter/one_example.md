# Satu Contoh Naskah (acuan irama saja)

> Jangan salin tokoh, kalimat, urutan, atau tema contoh ini. Gunakan hanya untuk merasakan tempo, panjang kalimat, dan kehangatan nada. Arc: B (Kamu yang Hampir Keliru), ±170 kata.

Jumat malam, jam sepuluh. Di layar ponselmu ada tombol hijau bertuliskan setujui cicilan. Motor barunya sudah sebulan kamu taksir. Warnanya merah, persis yang dipakai Reza kemarin, yang bilang motor lamamu bikin malu parkiran kantor.

Kamu sebenarnya tahu motormu masih sehat. Servis rutin, rem baru, belum pernah mogok sekali pun. Tapi kalimat kecil itu menempel seperti debu di helm. Malu parkiran kantor.

Istrimu duduk di sebelahmu, melipat cucian, tidak bilang apa-apa. Lalu dia bertanya pelan, "Itu kamu yang mau, atau kamu cuma tidak mau dikomentari?"

Kamu diam lama. Sampai suara kipas angin terdengar lebih keras daripada pikiranmu.

Kalau kamu pernah hampir membeli sesuatu karena omongan orang, sebutkan satu barangnya di komentar. Kamu tidak sendirian.

Malam itu kamu menutup aplikasinya. Bukan karena kamu hebat. Hanya karena pertanyaan tadi terlalu jujur untuk dilawan.

Besok pagi kamu tetap parkir di tempat yang sama. Beberapa orang melirik, kamu pura-pura tidak lihat. Dan ternyata, tidak ada yang runtuh.

Sekarang jawab jujur di komentar: kamu lebih takut dikomentari orang, atau takut bangun di tanggal satu dengan tagihan yang sama?
