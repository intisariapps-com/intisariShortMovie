# Setup di ChatGPT / OpenAI Codex

- **Codex Plugin (3-in-1):** Unggah `00-complete.zip` melalui jalur plugin.
- **Skill Satuan:** Unggah `01-*.zip`, `02-*.zip`, atau `03-*.zip` secara terpisah.
- **Custom GPT Builder Manual:** Tempel `GPT_INSTRUCTIONS.md` ke *Instructions* dan unggah berkas dari `skills/` ke *Knowledge*.