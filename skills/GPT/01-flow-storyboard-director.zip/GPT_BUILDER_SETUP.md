# Setup Single Plugin di OpenAI ChatGPT / Codex

- **OpenAI Codex Plugin:** Unggah file ZIP ini langsung melalui antarmuka plugin (sudah memuat `.codex-plugin/plugin.json` dan `skills/flow-storyboard-director/`).
- **Custom GPT Builder Manual:** Salin teks dari `GPT_INSTRUCTIONS.md` ke kolom *Instructions*, dan unggah file referensi dari `skills/flow-storyboard-director/references/` ke *Knowledge*.
