# Setup Single Plugin di OpenAI ChatGPT / Codex

- **OpenAI Codex Plugin:** Unggah file ZIP ini langsung melalui antarmuka plugin (sudah memuat `.codex-plugin/plugin.json`, `plugin.json`, dan `skills/faceless-documentary-script/`).
- **Custom GPT Builder Manual:** Salin teks dari `GPT_INSTRUCTIONS.md` ke kolom *Instructions*, dan unggah file referensi dari `skills/faceless-documentary-script/references/` ke *Knowledge*.
