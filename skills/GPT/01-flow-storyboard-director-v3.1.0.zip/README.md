# Flow & Intisari Storyboard Director (v3.1.0)

Paket **Single-Skill Plugin (GPT)** resmi untuk keahlian:
- **Skill ID**: `flow-storyboard-director`
- **Versi**: `v3.1.0`
- **Deskripsi**: Sutradara visual AI untuk storyboard sinematik dan Google Flow.

Arsip ini memiliki struktur plugin standar dengan direktori `skills/flow-storyboard-director/` dan berkas manifest provider yang valid.
