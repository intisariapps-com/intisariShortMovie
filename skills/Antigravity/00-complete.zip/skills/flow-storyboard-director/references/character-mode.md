# Mode Konsistensi Karakter (@alias)

## Skema Karakter
- `@CamelCase` disematkan hanya untuk tokoh yang dipilih pengguna untuk dikunci dan benar-benar hadir di dalam frame visual.
- Daftarkan setiap tokoh **satu kali** di `characters[]` dengan field: `alias`, `name`, `role`, `description`, `visual_prompt`.
- Dilarang membuat field `"alias": ""`. Jika sebuah entitas tidak memiliki tag `@Alias`, jangan masukkan ke `characters[]` sebagai karakter terkunci.
- `visual_prompt` hanya memuat ciri fisik dan busana stabil; tidak boleh memuat pose sesaat, emosi spesifik, aksi, framing kamera, latar ruangan, atau nama gaya/medium.
- Salin `visual_prompt` kanonis **kata per kata** ke setiap adegan yang memuat karakter: `@Alias (visual_prompt)`.
- Setiap adegan memuat `emotion` dan `character_presence`.

## Kehadiran Karakter (`character_presence`)
Evaluasi nilai ini sebelum menyusun `image_prompt`:
- `required`: tokoh wajib hadir jelas di frame. Dipakai untuk aksi fisik langsung, dialog/reaksi emosional, perpindahan tempat, hook pembuka, dan momen klimaks cerita.
- `small`: tokoh hadir dalam skala kecil sebagai pengamat/penanda skala (maksimal 1/6 tinggi frame); lingkungan atau arsitektur tetap menjadi fokus utama.
- `none`: tokoh dilarang hadir sama sekali. Dipakai untuk adegan konsep abstrak, mekanisme teknis, visualisasi data, atau satu objek/simbol sentral (misal tiang bendera, surat naskah, radio kuno).

Aturan Keputusan:
1. Tanyakan: *"Apakah penonton perlu melihat tokoh untuk memahami narasi adegan ini?"* Jika tidak, gunakan `none` atau `small`.
2. `ADEGAN_01` dan adegan klimaks/penutup sangat disarankan `required`. `COVER` mengikuti Cover Engine (bisa `required`, `small`, atau `none`).
3. Jangan pernah menambah tokoh buatan hanya karena narasi memakai kata ganti orang kedua (*kamu*, *Anda*, *kita*).

Perilaku Prompt:
- `required`: `@Alias` + `visual_prompt` + ekspresi fisik & aksi.
- `small`: `@Alias` + `visual_prompt` dengan catatan skala kecil/pengamat, ekspresi netral.
- `none`: tanpa `@Alias` dan tanpa `visual_prompt`; subjek pertama adalah objek/arsitektur/lingkungan inti. Palet terkunci dan detail latar tetap berlaku.

## Emotion-Face Lock (`emotion`)
- Setiap adegan berkarakter wajib memiliki atribut `emotion` (misal: `"fokus, tegang"`, `"terkejut, cemas"`, `"bangga, haru"`).
- Terjemahkan `emotion` menjadi mikro-ekspresi fisik konkret pada `image_prompt` (bentuk mata, alis, bibir, gesture tangan).
- Perubahan emosi disalurkan lewat ekspresi wajah dan bahasa tubuh, bukan mengubah warna pakaian atau palet dasar karakter.
