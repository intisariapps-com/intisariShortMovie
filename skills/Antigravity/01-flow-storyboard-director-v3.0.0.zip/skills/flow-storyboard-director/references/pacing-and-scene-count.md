# Pacing & Auto Scene Count

## Adaptive Retention Pacing (rekomendasi utama)
Durasi adegan dinamis, bukan angka tetap. Rentang indikatif:
- hook 1,5-3,5 dtk · aksi 2,5-5 dtk · narasi biasa 4-7 dtk
- informasi kompleks 5-9 dtk · pengungkapan 3-7 dtk · emotional hold 6-10 dtk

Kecepatan baca lisan Indonesia: **2,2-2,5 kata/detik** (~135-150 WPM, ~0,42 dtk/kata).

**Formula durasi**: `estimated_seconds = (word_count * 60 / narrator_wpm) + punctuation_pause_seconds + emotional_pause_seconds`
- Default `narrator_wpm = 135` (fleksibel 115-170).
- Jeda: koma 0,12-0,25 dtk; titik/tanda tanya 0,25-0,5 dtk; elipsis 0,4-0,9 dtk.
- Bila ada audio/TTS timestamp aktual, pakai timestamp itu sebagai sumber utama.

## Kebijakan jumlah adegan
`Auto Scene Count` (default): N ditentukan dari segmentasi semantik alami, bukan total durasi dibagi 5 detik.

## Aturan mutlak pemotongan adegan
- Potong hanya pada batas kalimat utuh (`.!?`) atau jeda klausa mandiri (`,;`).
- Jangan memotong di tengah kata sambung/klausa dependen: `yang`, `dan`, `untuk`, `karena`, `sehingga`, `tapi`, `tetapi`, `namun`, `padahal`, `ketika`, `saat`, `kalau`, `jika`, `meskipun`, `dari`, `dengan`.
- Satu adegan = satu gagasan visual utuh. Jangan membuat adegan mini 4-5 kata yang memecah satu kalimat menjadi 3-4 adegan.

## Pilihan pacing alternatif
- **Balanced Storytelling**: 4,5-6,5 dtk / 11-16 kata per adegan (~10-13 adegan/menit).
- **Dynamic Fast-Paced**: 3,5-4,5 dtk per adegan.
- **Deep Cinematic Documentary**: 6,0-8,5 dtk / 16-22 kata per adegan (~7-9 adegan/menit).
