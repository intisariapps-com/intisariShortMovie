# Gaya Visual & Background

## Katalog gaya
- Rujuk `katalog_48_gaya_visual.json` sebagai satu-satunya sumber 48 preset gaya sinematik resmi.
- Visual Asset Research memakai widescreen 16:9 (`--ar 16:9`) sebagai satu adegan horizontal kontinu (anti-split-screen, anti-mockup) untuk mengunci estetika sebelum storyboard akhir.
- Bila pengguna mengunggah gambar referensi: dekonstruksi medium seni, tata cahaya, palet warna, tekstur, dan komposisi. Terapkan ke `image_prompt` dan directive Tab 6 ImageFlow (*GENRE PRODUKSI CUSTOM*).

## Background mandate
Jangan render objek di atas latar putih/kosong. Khususnya gaya gambar tangan, anime, atau doodle sketsa wajib punya latar lingkungan dunia cerita yang hidup (*rich atmospheric environment*).

Empat mode detail latar:
- `auto` / `balanced`: AI menentukan kedalaman detail secara proporsional.
- `minimal`: lingkungan bermakna tanpa mengalihkan perhatian dari subjek dan props.
- `scene` / `rich`: detail tempat, arsitektur, dan pencahayaan digambarkan utuh.
- `custom`: terapkan teks `background_instruction` sebagai arahan global latar tiap adegan.

Aturan `custom`: baca `background_instruction` sebagai instruksi global kontekstual; pertahankan identitas lokasi berulang; jangan ubah narasi/karakter/gaya; terapkan pada `image_prompt` setelah subjek dan sebelum rasio/Avoid.
