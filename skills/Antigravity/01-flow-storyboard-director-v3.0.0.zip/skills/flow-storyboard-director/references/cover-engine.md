# Cover Scene (item pertama di `scenes`)

**Zero-narrative cover**: judul tidak masuk voiceover. `narrative` = `"-"` pada format Custom GPT/Gem ini; format ImageFlow boleh `""` (keduanya berarti kosong).

Field tetap: `"id": "COVER"`, `"narrative": "-"`, `"video_prompt": ""`, `"retention_role": "static_cover"`, `"video_duration": 0`. COVER selalu still image.

## Pengaturan Cover (berdiri sendiri)
- **`cover_text`** (field root, `"on"` default atau `"off"`) ditetapkan dari pilihan Cover di Langkah 11. Tidak dipengaruhi pilihan headline Langkah 9 maupun `Headline: Tidak` di BYPASS (bila BYPASS tidak menyebut Cover, pakai `"on"`).
- **`"on"`**: `headline` COVER (juga `title_display` dan `editorial_text[0].text`) berisi **teks hook**, bukan sekadar judul. Maks. 8 kata dan 2 baris, Bahasa Indonesia, satu pola yang dicatat di `cover_hook_type`: `pertanyaan` (belum terjawab), `kontras` (dua hal berlawanan/angka mengejutkan), `rahasia` (larangan/hal tersembunyi), `sebelum_sesudah`, atau `cliffhanger`. Hook wajib dijawab isi video; jangan menjanjikan yang tidak ada di cerita.
- **`"off"`**: `headline` `""`, `editorial_text` `[]`, `cover_hook_type: "none"`, dan `image_prompt` melarang lettering.

## Visual cover
- Satu titik fokus besar yang mengisi sebagian besar frame + satu elemen penasaran (janggal, tertutup, atau kontras) yang sesuai cerita.
- Ukuran shot bebas (`Wide Shot`, `Medium Shot`, `Close-Up`) tetap diikuti `framing`. Wajah tidak diwajibkan; `character_presence` COVER mengikuti `character-mode.md`.
- Warna: pasangan kontras tertinggi dari `palette_lock`; jangan menambah warna di luar palet.
- **Zona aman 9:16** (patokan konservatif, bukan spesifikasi resmi): jaga teks dan wajah utama di luar pita ~15% teratas, sisi kiri-kanan ~10-15%, dan ~25-35% terbawah. Letakkan teks hook di area atas-tengah di bawah pita teratas, huruf besar dan kontras tinggi.
- Tetap berlaku: safety, palet terkunci, `[Avoid: ..., sc_tag_cover]`, `--ar`. Jangan memaksakan gaya 3D.
- `image_prompt` COVER: subjek/aksi/latar yang merangkum cerita + elemen penasaran, lalu (bila `"on"`) arahan teks hook di zona aman, `Palette lock`, rasio, dan `[Avoid: ..., sc_tag_cover]`.
