# Mode Atmosferik & Timelapse

## Atmosferik (Dokumenter/Sains/Sejarah)
- Dilarang memakai `@` di naskah maupun prompt visual.
- Fokus pada subjek murni: alam, lanskap, sel mikroskopis, artefak sejarah.
- Master Blueprint: 3 prompt fokus non-karakter tanpa `@`.

## Timelapse (Dual-Anchor Lock)
Kunci 2 tag subjek: `@MasterBackground` dan `@SubjekUtama` (hanya di `image_prompt`).
- `image_prompt`: *"Exact locked tripod camera, identical 35mm angle and composition..."*
- `video_prompt`: *"Accelerated seamless time-lapse motion, dynamic lighting, fixed locked tripod camera..."*

**Kontinuitas**: jangan mengganti model objek dan latar antar adegan. Hanya transisi fase pelapukan/pertumbuhan secara bertahap.
