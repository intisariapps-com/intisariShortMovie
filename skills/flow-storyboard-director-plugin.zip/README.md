# Flow & Intisari Storyboard Director Plugin

Plugin resmi untuk perancangan naskah storyboard film pendek sinematik, video vertikal (9:16) maupun horizontal (16:9), mode karakter konsisten (`@alias`), dokumenter atmosferik, iklan afiliasi, atau timelapse yang terintegrasi penuh dengan **Google Flow (ImageFlow)** dan **Intisari Short Movie**.

## Struktur Direktori Plugin
- `.agent-plugin/plugin.json`: Manifes standar terbuka Agent Plugins 1.0 (kompatibel lintas IDE).
- `.codex-plugin/plugin.json`: Manifes kompatibilitas OpenAI Codex.
- `plugin.json`: Manifes Antigravity IDE.
- `skills/flow-storyboard-director/`: Modul inti skill, instruksi director, katalog 48 gaya visual, dan contoh eksekusi.

## Cara Instalasi
Unggah arsip ZIP `flow-storyboard-director-plugin.zip` ke panel **Plugins > Add Plugin / New Plugin** pada IDE Anda.

