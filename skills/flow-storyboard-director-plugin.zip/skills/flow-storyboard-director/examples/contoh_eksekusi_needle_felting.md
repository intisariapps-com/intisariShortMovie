Berdasarkan parameter dan gambar referensi yang Anda berikan, kita akan menggunakan **Gaya Normal (Durasi 6 Detik)** untuk mencapai total durasi 1 menit (10 Adegan). Pacing ini akan menjaga narasi dokumenter thriller tetap stabil dan dapat dicerna dengan baik.

Untuk gambar referensi yang diunggah (`KP_202609041319.jpeg`), saya telah mengekstrak gaya visualnya (Art Style) yaitu **3D needle felting, tekstur wol lembut, kain tenun, dan pencahayaan miniatur yang hangat**. Gaya visual ini akan diterapkan pada tema Megathrust yang serius, menciptakan visualisasi kontras yang sangat unik dan *eye-catching* (layaknya model diorama sains).

Berikut adalah storyboard eksekusi Anda:

### JUDUL VIDEO

```text
Monster Tertidur di Dasar Laut: Misteri Megathrust Nusantara

```

### CAPTION SOSIAL MEDIA

```text
Ancaman nyata di bawah kaki kita. 🌊 Menyelami misteri Zona Megathrust Nusantara, monster geologi yang sedang mengumpulkan kekuatannya. Apakah peradaban kita sudah siap menghadapinya? 

Tonton sampai habis untuk melihat bagaimana sains memprediksi masa depan pesisir kita! 

#Megathrust #GempaBumi #Tsunami #Geologi #EdukasiSains #BMKG #MisteriLaut #FeltArt #Animasi3D

```

### PROMPT COVER VIDEO (THUMBNAIL)

```text
A dynamic 3D poster of a massive glowing tectonic fault line deep underwater, cinematic lighting, with bold glowing typography text "MEGATHRUST NUSANTARA". Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, and warm miniature lighting, 8k resolution, --ar 9:16

```

---

### STORYBOARD VISUAL

**Adegan 1**

* **Narasi (Indonesia)**:

```text
Di dasar laut Nusantara, monster raksasa sedang tertidur pulas dalam keheningan yang mencekam.

```

* **Prompt Gambar (Image)**:

```text
Deep dark ocean floor, a mysterious and eerie glowing underwater trench. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Slow camera zoom in into the dark trench, subtle floating particles

```

**Adegan 2**

* **Narasi (Indonesia)**:

```text
Inilah zona Megathrust, pertemuan lempeng tektonik yang menyimpan akumulasi energi selama ratusan tahun.

```

* **Prompt Gambar (Image)**:

```text
A glowing sci-fi holographic tectonic map of the Indonesian archipelago floating in the dark. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Camera pans slowly across the glowing fault lines, slow pulsing light effect

```

**Adegan 3**

* **Narasi (Indonesia)**:

```text
Pakar geologi terus memantau pergerakan ini, menyadari ancaman patahan bumi yang bisa terjadi sewaktu-waktu.

```

* **Prompt Gambar (Image)**:

```text
A highly detailed scientific monitoring station with glowing radar screens and seismographs in a dark room. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Camera tracks left slowly over the monitoring instruments, blinking lights on the screens

```

**Adegan 4**

* **Narasi (Indonesia)**:

```text
Tekanan tektonik terus meningkat, layaknya sebuah pegas raksasa yang ditarik hingga batas maksimalnya.

```

* **Prompt Gambar (Image)**:

```text
Two massive tectonic plates pushing against each other underground, with intense red glowing pressure points. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Extremely slow push-in, subtle but tense vibration effect on the friction points

```

**Adegan 5**

* **Narasi (Indonesia)**:

```text
Jika monster ini terbangun, gempa dahsyat dan gelombang tsunami mematikan siap menyapu daratan.

```

* **Prompt Gambar (Image)**:

```text
An abstract representation of a massive tsunami wave forming from a sudden seabed displacement. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Upward camera tilt following the sudden rise of the massive wave column

```

**Adegan 6**

* **Narasi (Indonesia)**:

```text
Sejarah telah membuktikan kekuatannya, menyisakan duka mendalam bagi peradaban yang sama sekali tidak bersiap.

```

* **Prompt Gambar (Image)**:

```text
A faded, sepia-toned diorama of an ancient coastal village looking fragile near a dark vast ocean. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Slow pull back camera movement, revealing the vast empty ocean behind the village

```

**Adegan 7**

* **Narasi (Indonesia)**:

```text
Namun umat manusia tidak tinggal diam menghadapi ancaman mematikan yang bersembunyi di bawah kita.

```

* **Prompt Gambar (Image)**:

```text
A massive, towering coastal defense sea-wall protecting a modern city from the ocean. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Crane shot moving upwards slowly to reveal the grand scale of the defense wall

```

**Adegan 8**

* **Narasi (Indonesia)**:

```text
Kota pesisir futuristik kini dirancang dengan teknologi tahan gempa dan sistem peringatan dini canggih.

```

* **Prompt Gambar (Image)**:

```text
A bright futuristic coastal city with glowing neon accents and geometric earthquake-resistant buildings. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Wide cinematic shot, slow pan right showing the beautiful and resilient city infrastructure

```

**Adegan 9**

* **Narasi (Indonesia)**:

```text
Kita hidup berdampingan dengan sang raksasa, selalu waspada agar tragedi masa lalu tidak terulang.

```

* **Prompt Gambar (Image)**:

```text
Cross-section view showing a peaceful bright city above ground, and a dark glowing tectonic fault line deep below it. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Slow zoom out to capture both the underground threat and the peaceful surface simultaneously

```

**Adegan 10**

* **Narasi (Indonesia)**:

```text
Megathrust bukanlah mitos belaka, melainkan realitas sains. Sudahkah kita siap saat ia terbangun nanti?

```

* **Prompt Gambar (Image)**:

```text
Close up of the deep dark ocean floor, with a single, intense red glowing line starting to illuminate the darkness. Applied in the exact art style of [REF: KP_202609041319.jpeg], featuring 3D felt animation, needle felting texture, soft wool materials, woven fabric textures, and warm miniature lighting, --ar 9:16

```

* **Prompt Video (Motion)**:

```text
Static shot, the red glow slowly intensifies, smoothly fade to black at the end

```

---

### REKAP FULL NARASI & DATA TAMBAHAN

**FULL NARASI (Indonesia)**

```text
Di dasar laut Nusantara, monster raksasa sedang tertidur pulas dalam keheningan yang mencekam. Inilah zona Megathrust, pertemuan lempeng tektonik yang menyimpan akumulasi energi selama ratusan tahun. Pakar geologi terus memantau pergerakan ini, menyadari ancaman patahan bumi yang bisa terjadi sewaktu-waktu. Tekanan tektonik terus meningkat, layaknya sebuah pegas raksasa yang ditarik hingga batas maksimalnya. Jika monster ini terbangun, gempa dahsyat dan gelombang tsunami mematikan siap menyapu daratan. Sejarah telah membuktikan kekuatannya, menyisakan duka mendalam bagi peradaban yang sama sekali tidak bersiap. Namun umat manusia tidak tinggal diam menghadapi ancaman mematikan yang bersembunyi di bawah kita. Kota pesisir futuristik kini dirancang dengan teknologi tahan gempa dan sistem peringatan dini canggih. Kita hidup berdampingan dengan sang raksasa, selalu waspada agar tragedi masa lalu tidak terulang. Megathrust bukanlah mitos belaka, melainkan realitas sains. Sudahkah kita siap saat ia terbangun nanti?

```

**ESTIMASI DURASI FINAL**

```text
Total estimasi durasi: 60 detik (136 kata, pacing 136 kata per menit / ~6 detik per kalimat).

```

**SHORT TITLE / KEYWORD**

```text
Misteri Megathrust Monster Nusantara

```
