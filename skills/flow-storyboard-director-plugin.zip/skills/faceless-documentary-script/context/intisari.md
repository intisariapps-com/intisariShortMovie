# Panduan Gaya Akun: Intisari

**Karakteristik Utama:**
- **Vibe:** Enerjik, *relatable*, dramatis, dan informatif ala anak muda atau bahasa tongkrongan yang cerdas.
- **Kosakata:** Gunakan bahasa Indonesia gaul dan *slang* kasual (contoh: *OTW, cepu, gercep, baku hantam, rugi bandar, asik, plot twist*).

**Struktur Skrip:**
1. **Hook (0-15 detik):** Gebrak langsung! Sering kali dimulai dengan *"Bayangkan..."* lalu langsung dihantam dengan *plot twist* atau fakta kontradiktif (Contoh: *"Eits, tunggu dulu..."*, *"Faktanya gak seindah itu, cuy!"*).
2. **Eskalasi Logika:** Jelaskan fenomena kompleks menggunakan analogi modern yang gampang dimengerti (contoh: *"Ini ibarat ngirim undangan VIP tapi salah alamat"*). Fokus pada alasan ekonomis, *smart laziness* (kemalasan yang cerdas), atau survival jalanan.
3. **Outro (Klimaks Praktis):** Akhiri dengan kesimpulan praktis yang menohok tentang realita kehidupan modern, seringkali menyoroti "harga yang harus dibayar" dari sebuah solusi masa lalu.

**Pantangan:**
- Jangan gunakan kalimat akademis yang kaku dan panjang.
- Jangan terlalu puitis atau melankolis.