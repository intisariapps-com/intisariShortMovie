**Identitas Inti SudutPaham**

* **Misi Saluran:** Meluruskan asumsi keliru dan membongkar alasan tersembunyi di balik fenomena sehari-hari menggunakan logika praktis, ekonomi, atau sains.
* **Slogan Utama:** "Bongkar Fakta. Biar Gak Salah Paham."
* **Persona Karakter:** Cerdas, *to the point*, logis, dan berbicara layaknya teman tongkrongan yang tahu banyak rahasia tersembunyi.

**Identitas Visual**

* **Palet Warna:** Biru Navy (mewakili misteri, fakta, dan kredibilitas) dipadukan dengan Kuning Terang (mewakili pencerahan, ide, dan peringatan). Kontras ini sangat mencolok untuk algoritma *Reels* dan *Shorts*.
* **Tipografi:** Gunakan *font* tebal dan modern (seperti Montserrat, Poppins, atau Arial Black) untuk teks di dalam video (*caption/subtitle*) agar terbaca jelas meski di layar kecil.
* **Gaya Video (Faceless):** Gunakan potongan video atau gambar pendukung yang berganti cepat setiap 2-3 detik. Berikan penekanan visual seperti efek *zoom*, lingkaran merah, atau tanda panah kuning saat narator mengungkap sebuah rahasia.

**Identitas Verbal & Pola Naskah**

* **Karakter Suara (Voice Over):** Dinamis, bertempo sedikit cepat, dengan penekanan intonasi yang dramatis saat masuk ke bagian *twist* ("Eits, buang jauh-jauh pikiran itu...").
* **Pembuka (Hook) Konsisten:** Selalu gunakan bantahan asumsi, misalnya "Selama ini kita semua salah paham soal..." atau "Pernah sadar nggak kenapa...".
* **Penutup (Outro) Paten:** "Dari SudutPaham yang baru, [Masukkan 1 kalimat kesimpulan]. Oh begitu paktanya, jadi jangan sampai salah paham ya! Jangan lupa follow akun SudutPaham yaa."

**Pilar Topik Konten**

1. **Strategi Bisnis Gelap:** Alasan lantai kasino tidak pernah menggunakan jam dinding, atau taktik tata letak supermarket yang membuat pembeli tersesat.
2. **Desain Tersembunyi:** Fungsi bulu sikat gigi yang warnanya berbeda, atau alasan lubang tambahan pada sepatu olahraga.
3. **Sains Kehidupan Sehari-hari:** Kenapa suara rekaman kita terdengar sangat berbeda di telinga sendiri.

Apakah Anda ingin kita mulai memproduksi draf naskah video pertama berdasarkan salah satu pilar topik di atas?