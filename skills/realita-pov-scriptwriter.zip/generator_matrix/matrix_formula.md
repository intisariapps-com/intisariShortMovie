# The Infinite Matrix: Rumus Permutasi Cerita Realita-POV

Dokumen ini adalah mesin generator ide tak terbatas untuk mencegah *writer's block*. Dengan mengombinasikan 4 variabel di bawah ini, kreator dapat menghasilkan ratusan premis cerita unik yang selalu segar dan relevan dengan realitas sosial masyarakat Indonesia.

---

## 1. Rumus Kombinasi Permutasi

$$\text{Premis RealitaPOV} = [\text{Tokoh Underdog (A)}] \times [\text{Antagonis Gengsi (B)}] \times [\text{Ujian Krisis (C)}] \times [\text{Kemenangan Hening (D)}]$$

---

## 2. Tabel Variabel Matriks Cerita

| Variabel | Elemen Cerita | Pilihan Karakter & Situasi |
| :---: | :--- | :--- |
| **A** | **Tokoh Utama ("Kamu")** | 1. Analis data / IT remote work di kampung yang dikira pengangguran/ngepet.<br/>2. Guru honorer bergaji minim yang konsisten menabung reksadana/emas.<br/>3. Pemilik warung makan kaki lima / toko kelontong dengan motor butut.<br/>4. Karyawan logistik biasa yang disiplin berinvestasi saham dividen.<br/>5. Mekanik bengkel motor kecil yang mengutamakan hidup tanpa cicilan. |
| **B** | **Antagonis Gengsi (Sosok Pamer)** | 1. Tetangga komplek manajer bergaji puluhan juta tapi cicilan 90% gaji.<br/>2. Rekan satu divisi yang selalu gonta-ganti gadget terbaru via paylater.<br/>3. Kerabat keluarga/mertua yang menuntut pesta resepsi mewah demi gengsi.<br/>4. Teman sekolah yang pamer mobil sewaan dan gaya hidup glamor di medsos.<br/>5. Pemilik ruko kafe kekinian yang menertawakan pedagang kaki lima tradisional. |
| **C** | **Ujian Badai / Krisis Nyata** | 1. Gelombang PHK massal / restrukturisasi kantor korporat.<br/>2. Jatuhnya pasar saham / resesi ekonomi lokal.<br/>3. Krisis kesehatan mendadak anggota keluarga tanpa asuransi darurat.<br/>4. Jatuh tempo cicilan bunga pinjol / kredit macet gaya hidup.<br/>5. Inflasi bahan baku mendadak yang mematikan bisnis bermodal gengsi. |
| **D** | **Kemenangan Hening (Silent Victory)** | 1. Tokoh utama menyeduhkan kopi di teras dan memetakan jalan keluar tanpa menghina.<br/>2. Tokoh utama diam-diam melunasi tunggakan tanpa mencantumkan namanya.<br/>3. Tokoh utama menawarkan modal kerja darurat dengan senyuman tulus.<br/>4. Grup WhatsApp / lingkungan komplek mendadak hening dan menyadari kebenaran.<br/>5. Tokoh utama tetap tenang menyiram tanaman / sarungan menjalani hidup damai. |

---

## 3. Contoh Hasil Putaran Matriks (Preset Demonstrasi)

### Kombinasi 1 (Finansial & Investasi): $A_4 \times B_1 \times C_1 \times D_1$
> **Premis**: Karyawan logistik Bekasi bergaji pas-pasan yang dikira nganggur karena sarungan di rumah, padahal hidup dari dividen Rp15 juta/bulan. Tetangga manajer pamer mobil baru tiba-tiba terkena PHK dan curhat di teras malam-malam karena cicilannya Rp31 juta/bulan.

### Kombinasi 2 (Karir & Remote Work): $A_1 \times B_4 \times C_4 \times D_4$
> **Premis**: Pemuda kampung yang jarang keluar rumah dan sering dicurigai warga ikut pesugihan atau judi online, padahal bekerja sebagai software engineer remote dengan gaji dollar. Teman masa kecil yang meremehkannya saat pulang kampung pamer mobil sewaan akhirnya dikejar debt collector di depan balai desa.

### Kombinasi 3 (Bisnis Tradisional vs Gengsi): $A_3 \times B_5 \times C_5 \times D_3$
> **Premis**: Penjual pecel lele sederhana yang selalu memakai baju lusuh dan menabung untung hariannya untuk membeli ruko tunai. Di seberangnya, pemilik kafe estetik bermodal pinjaman bank yang suka mencibir aroma asap warung akhirnya bangkrut saat bahan baku melonjak dan meminta bantuan modal.

---

## 4. Instruksi Bagi AI saat Mode "Putar Matriks" Aktif
Jika pengguna meminta ide baru:
1. Ambil 1 kombinasi acak dari tabel di atas atau formulasikan variasi segar yang seimbang.
2. Sajikan kepada pengguna dalam bentuk **3 Pilihan Premis Singkat** beserta potensi *Hook* pembukanya.
3. Tanyakan kepada pengguna: *"Dari ketiga premis di atas, nomor berapa yang paling pas untuk kita kembangkan naskahnya?"*

