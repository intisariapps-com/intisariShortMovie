# Kategori 4: Bisnis Lapangan, Juragan Tradisional vs Startup Gengsi

Kategori ini mengangkat fenomena UMKM lapangan Indonesia: juragan rongsokan, pengepul barang bekas, peternak bebek, atau penjual warung tegal yang penampilannya dekil dan memakai sandal jepit, namun arus kas hariannya mengalahkan gaji direktur eksekutif.

---

## 1. Persona Karakter Utama
- Pengusaha sektor riil tradisional yang tidak peduli pada citra kemewahan. Tidak memakai jas, tidak nongkrong di kafe mahal, tetapi memiliki perputaran kas harian yang sangat likuid dan tanpa utang bank.

---

## 2. Sosok Antagonis Sosial
- Pebisnis pemula yang mengedepankan kemasan: sewa ruang kerja estetik di gedung perkantoran mewah, mobil dinas cicilan, kartu nama berlapis emas, tetapi arus kas operasionalnya selalu defisit dan bergantung pada investor atau utang.

---

## 3. Pemicu Badai & Plot Twist
- **Krisis**: Perubahan iklim pendanaan (*funding winter*) atau kenaikan suku bunga pinjaman modal yang mematikan bisnis bermodal gengsi.
- **Twist**: Bisnis lapangan tradisional milik tokoh utama justru semakin dicari karena menjual kebutuhan primer harian masyarakat.
- **Resolusi**: Tokoh utama membeli aset atau ruko milik pebisnis parlente yang dilelang bank secara tunai tanpa perlu menyombongkan diri.

---

## 4. Bank Contoh Hook Pembuka
> *"Setiap sore orang-orang melihatmu dengan celana pendek bernoda minyak dan kaos oblong kusam di pinggir jalan. Di ruko seberang, seorang pemuda berdasi rapi memandangmu sambil memamerkan kafe barunya. Tapi mereka tidak tahu, ruko tempat kafe itu berdiri, kamu yang punya sertifikatnya..."*

---

## 5. Preset Dual-CTA
- **Mid-CTA**: *"Jangan pernah menilai isi dompet orang dari pakaian yang dia pakai. Pernah ketemu orang seperti ini? Tulis ceritamu di komentar."*
- **Closing CTA**: *"Pilih bisnis yang kelihatan keren tapi boncos, atau bisnis yang kelihatannya kotor tapi menghasilkan miliaran? Tulis di komentar."*

