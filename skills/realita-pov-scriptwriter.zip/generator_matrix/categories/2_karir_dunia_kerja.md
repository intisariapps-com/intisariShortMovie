# Kategori 2: Karir, Dunia Kerja & Side-Hustle Diam-Diam

Kategori ini mengangkat dinamika realita korporat: jebakan promosi jabatan yang memeras waktu (*golden handcuffs*), karyawan santai yang diam-diam membangun kemandirian ekonomi, serta fenomena *silent quitting* yang produktif.

---

## 1. Persona Karakter Utama
- **Profesi**: Staf operasional biasa, staf IT, atau karyawan administrasi yang bekerja tepat waktu (teng-go) dan tidak gila hormat jabatan.
- **Aktivitas Tersembunyi**: Di luar jam kerja membangun bisnis digital, toko online, atau ternak sampingan di kampung tanpa pernah bercerita ke rekan sekantor.
- **Prinsip**: Pekerjaan utama adalah penyedia modal kerja dan asuransi, bukan sumber harga diri mutlak.

---

## 2. Sosok Antagonis Sosial
- Rekan kerja atau atasan yang membanggakan lembur hingga larut malam, menganggap loyalitas buta adalah satu-satunya jalan hidup, dan sering menyindir karyawan yang pulang tepat waktu (*"Enak banget jam 5 udah cabut, gak punya ambisi ya?"*).

---

## 3. Pemicu Badai & Plot Twist
- **Krisis**: Perusahaan melakukan efisiensi mendadak atau membatalkan bonus tahunan. Rekan yang gila kerja syok berat karena seluruh hidupnya diserahkan ke kantor.
- **Twist**: Tokoh utama dengan tenang mengajukan surat pengunduran diri (*resign*) dengan tabungan darurat dan penghasilan pasif yang sudah melebihi gaji direktur.
- **Resolusi**: Atasan yang dulu mencibir datang bertanya peluang kemitraan bisnis di luar kantor.

---

## 4. Bank Contoh Hook Pembuka
> *"Jam 5 sore tepat, kamu merapikan meja kerja dan pamit pulang. Di sudut ruangan, seniormu melempar tatapan sinis sambil menunjuk tumpukan berkasnya. Tapi malam ini, saat dia masih minum kopi di kantor demi lembur tak berbayar, toko onlinemu mencetak transaksi ke seribu..."*

---

## 5. Preset Dual-CTA
- **Mid-CTA**: *"Bekerja itu untuk hidup, bukan hidup untuk bekerja. Setuju atau tidak? Tulis di komentar."*
- **Closing CTA**: *"Kalau bisnis sampinganmu sudah bisa menutupi kebutuhan bulanan, kamu bakal langsung resign atau tetap bertahan di kantor? Tulis pendapatmu di komentar."*

