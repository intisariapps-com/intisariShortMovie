# Kategori 3: Keluarga, Mertua & Pasangan Sefrekuensi

Kategori ini menyoroti drama keluarga besar di Indonesia: tuntutan resepsi pernikahan mewah demi gengsi orang tua/mertua, tradisi pamer saat kumpul keluarga Lebaran, serta ketangguhan pasangan suami-istri yang kompak memilih hidup sederhana.

---

## 1. Persona Karakter Utama
- Pasangan suami-istri muda yang memilih akad sederhana di KUA atau resepsi intim, mengalihkan seluruh anggaran pesta untuk membeli rumah mungil tanpa riba atau modal usaha bersama.
- Tetap tenang saat dibandingkan dengan ipar atau saudara lain yang mengadakan pesta megah di gedung mewah.

---

## 2. Sosok Antagonis Sosial
- Kerabat atau mertua yang sangat mementingkan status sosial di mata tetangga kampung, sering membanding-bandingkan pencapaian menantu, serta gemar membicarakan mas kawin dan mobil kerabat lain.

---

## 3. Pemicu Badai & Plot Twist
- **Krisis**: Saudara yang menggelar pesta mewah ternyata terbebani utang vendor dan cicilan bank selama bertahun-tahun. Hubungan rumah tangganya renggang akibat pertengkaran finansial.
- **Twist**: Tokoh utama dan pasangannya hidup tenteram tanpa tagihan di akhir bulan, dan menjadi tempat bersandar saat keluarga besar mengalami krisis.
- **Resolusi**: Mertua yang dulu mencibir akhirnya menyadari bahwa ketenangan batin menantunya jauh lebih berharga daripada komentar tamu undangan satu malam.

---

## 4. Bank Contoh Hook Pembuka
> *"Hari itu, ruang keluarga hening saat kamu dan istrimu mengumumkan pernikahan sederhana di KUA. Bibimu tersenyum tipis sambil berbisik, 'Kasian ya, nikah kok kayak gak niat.' Tapi empat tahun kemudian, saat saudara sepupumu masih pusing membayar cicilan catering, sertifikat rumah pertamamu sudah lunas di atas meja..."*

---

## 5. Preset Dual-CTA
- **Mid-CTA**: *"Punya pasangan yang gak gengsian itu rezeki seumur hidup. Siapa pasanganmu yang kamu syukuri hari ini? Tag atau sebut di komentar."*
- **Closing CTA**: *"Pesta mewah sehari tapi nyicil bertahun-tahun, atau akad sederhana tapi langsung punya rumah? Tentukan pilihanmu di komentar."*

