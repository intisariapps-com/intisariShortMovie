# Kategori 1: Finansial, Frugal Living & Stealth Wealth

Kategori ini berfokus pada edukasi keuangan praktis: dividen saham, *compounding interest*, menghindari jeratan gaya hidup (*hedonic treadmill*), serta membedakan antara aset produktif vs beban gengsi.

---

## 1. Persona Karakter Utama
- **Profesi**: Pekerja kantoran biasa, analis data, atau pegawai staf dengan penghasilan rata-rata.
- **Prinsip**: Disiplin menyisihkan gaji di awal bulan (*pay yourself first*), tidak pernah menggunakan pinjaman konsumtif (paylater/kartu kredit), memakai motor/gadget sampai rusak.
- **Pasangan**: Pasangan hidup yang satu visi (*frugal partner*) yang lebih menghargai rasa aman finansial daripada validasi sosial.

---

## 2. Sosok Antagonis Sosial
- Manajer/teman kantor atau tetangga komplek bergaji besar (Rp20–40 juta) tetapi seluruh uangnya habis untuk mencicil rumah mewah, mobil baru, dan liburan demi pamer di media sosial.
- Gemar mencibir kesederhanaan orang lain (*"Kok gak ganti mobil?", "Pelit banget sama diri sendiri"*).

---

## 3. Pemicu Badai & Plot Twist
- **Krisis**: Resesi ekonomi / gelombang restrukturisasi kantor yang memicu PHK massal.
- **Twist**: Pesangon si antagonis habis dalam hitungan bulan karena beban cicilan menumpuk. Sementara portofolio dividen tokoh utama terus mengalirkan uang tanpa harus bekerja.
- **Resolusi**: Tokoh utama menyeduhkan kopi hangat, membantu membedah daftar utang di atas kertas, dan menyarankan jalan keluar realistis dengan penuh empati.

---

## 4. Bank Contoh Hook Pembuka
> *"Senin, jam 9 pagi. Satu kompleks sudah berangkat kerja. Kamu masih pakai sarung, menyiram pohon cabai di depan rumah. Di grup WhatsApp ibu-ibu, kamu lagi dibahas..."*

---

## 5. Preset Dual-CTA
- **Mid-CTA**: *"Kalau kamu juga punya pasangan yang satu pikiran soal uang, tulis satu pikiran di komentar. Itu lebih langka dari saham bagus."*
- **Closing CTA**: *"Kalau kamu bisa hidup dari dividen, kamu tetap kerja atau berhenti seperti mereka? Tulis di komentar."*

