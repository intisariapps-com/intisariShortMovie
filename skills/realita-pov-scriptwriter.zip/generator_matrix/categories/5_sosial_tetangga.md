# Kategori 5: Sosial Lingkungan, Tetangga Komplek & Drama Arisan

Kategori ini menyoroti kehidupan bertetangga di perumahan suburban Indonesia: persaingan renovasi pagar, sindiran mobil baru di grup WhatsApp komplek, arisan mewah, dan kebiasaan menilai martabat orang dari merk barang yang tampak di garasi.

---

## 1. Persona Karakter Utama
- Penghuni komplek yang memilih motor tua, jarang ikut pamer di grup chat warga, menolak ajakan arisan konsumtif, dan lebih suka menghabiskan waktu luang merawat pekarangan rumah atau mengajari anak-anak warga secara sukarela.

---

## 2. Sosok Antagonis Sosial
- Tokoh warga atau pengurus paguyuban komplek yang haus pengakuan, mendokumentasikan setiap renovasi rumah di status medsos, dan gemar menebar rumor miring tentang warga lain yang hidup tenang (*"Kok suaminya jam 10 pagi masih di rumah? Jangan-jangan pengangguran"*).

---

## 3. Pemicu Badai & Plot Twist
- **Krisis**: Masalah lingkungan warga (misal: perbaikan gorong-gorong komplek yang mangkrak akibat iuran digelapkan atau butuh dana talangan darurat puluhan juta rupiah).
- **Twist**: Si pamer menghilang saat dimintai bantuan nyata. Tokoh utama diam-diam mentransfer dana talangan langsung ke panitia tanpa meminta namanya diumumkan di pengeras suara masjid atau grup chat.
- **Resolusi**: Seluruh warga komplek akhirnya tahu siapa yang memiliki ketulusan dan ketenangan hidup sejati.

---

## 4. Bank Contoh Hook Pembuka
> *"Satu komplek tahu motor bebekmu sudah berumur 12 tahun. Suara knalpotnya hafal di telinga satpam gerbang depan. Di arisan RT minggu lalu, seorang tetangga berbisik sambil tersenyum sinis, 'Kasihan ya, suaminya gak mampu beliin mobil.' Tapi pagi ini, saat bendahara komplek menangis karena dana renovasi jalan kurang 50 juta, kamu yang diam-diam menyelesaikannya..."*

---

## 5. Preset Dual-CTA
- **Mid-CTA**: *"Ketenangan hidup itu dimulai saat kita berhenti peduli pada apa kata tetangga. Setuju? Tulis di komentar."*
- **Closing CTA**: *"Kalau kamu punya rezeki berlebih, kamu bakal pamer ke tetangga atau tetap hidup sederhana seperti biasa? Tulis di komentar."*

