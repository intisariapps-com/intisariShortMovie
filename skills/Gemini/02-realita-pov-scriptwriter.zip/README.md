# Realita POV Scriptwriter (v2.0.0)

Paket **Single-Skill Plugin (Gemini)** resmi untuk keahlian:
- **Skill ID**: `realita-pov-scriptwriter`
- **Versi**: `v2.0.0`
- **Deskripsi**: Penulis naskah cerita Realita-POV, frugal living, dan drama sosial.

Arsip ini memiliki struktur plugin standar dengan direktori `skills/realita-pov-scriptwriter/` dan berkas manifest provider yang valid.
