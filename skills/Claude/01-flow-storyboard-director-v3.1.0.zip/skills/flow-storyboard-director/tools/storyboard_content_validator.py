"""Validator isi storyboard JSON (flow-storyboard-director v3.1).

Tugas file ini: memeriksa SATU file JSON storyboard terhadap aturan skill,
dengan kode (tanpa token AI). Pasangannya, storyboard_batch_import.py, hanya
memeriksa/menggabungkan file antar-bab dan tidak memeriksa isi adegan.

Pemakaian:
    from storyboard_content_validator import (
        load_llm_json, autofix_storyboard, validate_storyboard,
        validate_chapter_set, format_for_repair)

    data = load_llm_json(raw_text)                 # buang ```json fence / teks pembuka
    data, fixes = autofix_storyboard(data)         # perbaikan deterministik
    result = validate_storyboard(data, source_text=naskah)       # satu berkas
    # multi-bab: validate_chapter_set([("x_bab1_config.json", d1), ("x_bab2_config.json", d2)])
    if not result["ok"]:
        prompt_perbaikan = format_for_repair(result)   # kirim ke AI, ringkas

CLI:
    python storyboard_content_validator.py file.json [file2.json ...] [--source naskah.txt] [--strict] [--fix] [--json]
"""

from __future__ import annotations

import argparse
import copy
import difflib
import json
import math
import os
import re
import sys
from typing import Any

STRATEGIES_DUAL = {"first_3", "golden_25", "rhythm_3point", "full"}
STRATEGIES = STRATEGIES_DUAL | {"adaptive_motion"}

CINEMATIC_GUARD = ["3d render", "cgi", "cartoon", "anime", "illustration", "plastic",
                   "doll", "distorted", "blurry", "low quality"]
FLAT_GUARD = ["hands", "fingers", "holding paper", "photograph", "camera", "real life",
              "realistic human", "mockup", "sketchbook", "border", "frame", "white margins",
              "3d render", "cgi", "distorted", "blurry", "low quality"]

SHOTS = ["Extreme Wide Shot", "Wide Shot", "Medium Shot", "Close-Up", "Macro Shot"]
HOOK_TYPES = {"pertanyaan", "kontras", "rahasia", "sebelum_sesudah", "cliffhanger"}
PRESENCE = {"required", "small", "none"}
DEPENDENT_WORDS = {"yang", "dan", "untuk", "karena", "sehingga", "tapi", "tetapi", "namun",
                   "padahal", "ketika", "saat", "kalau", "jika", "meskipun", "dari", "dengan"}
ROLES_ADAPTIVE = {
    "high": {"golden_hook", "climax_rehook", "ending_hook", "video_motion"},
    "low": {"optional_motion", "ending_hook"},
    "none": {"still_only"},
}
LAYOUT_BAD = re.compile(r"split[- ]screen|collage|multi[- ]frame|\bgrid\b|diptych|triptych", re.I)
SAFETY_BAD = re.compile(
    r"\b(blood|bloody|gore|gory|knife|dagger|sword|gun|rifle|pistol|weapon|"
    r"disney|marvel|pixar|nintendo|pokemon|ghibli|mickey|batman|superman|spiderman)\b", re.I)
TIME_LITERAL = re.compile(r"\b\d+(?:\.\d+)?[\s-]*(?:s|sec|secs|second|seconds)\b", re.I)
AVOID_BLOCK = re.compile(r"\[Avoid:\s*([^\]]*)\]")
SC_TAG = re.compile(r"sc_tag_\w+")
ROOT_SAME_KEYS = ("aspect_ratio", "recommended_speed", "interaction_mode", "cover_text",
                  "palette_lock", "visual_reference", "video_metadata")


# --------------------------------------------------------------------------- util
def load_llm_json(text: str) -> Any:
    """Parse JSON dari output AI: buang ```fence``` dan teks di luar objek JSON."""
    cleaned = re.sub(r"```(?:json)?", "", text or "").strip()
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("Tidak ditemukan objek JSON ({...}); output mungkin terpotong.")
    try:
        return json.loads(cleaned[start:end + 1])
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"JSON tidak valid di baris {exc.lineno} kolom {exc.colno}: {exc.msg}. "
            "Penyebab umum: kutip dalam teks tidak di-escape (\\\"), koma berlebih, atau output terpotong."
        ) from exc


def _words(text: str) -> list[str]:
    return re.findall(r"\w+", (text or "").casefold())


def _expected_tag(scene_id: str) -> str | None:
    if scene_id == "COVER":
        return "sc_tag_cover"
    match = re.fullmatch(r"ADEGAN_(\d+)", scene_id or "")
    return f"sc_tag_{match.group(1)}" if match else None


class _Report:
    def __init__(self) -> None:
        self.errors: list[dict] = []
        self.warnings: list[dict] = []

    def err(self, code: str, path: str, msg: str) -> None:
        self.errors.append({"code": code, "path": path, "message": msg})

    def warn(self, code: str, path: str, msg: str) -> None:
        self.warnings.append({"code": code, "path": path, "message": msg})


# ------------------------------------------------------------------------ autofix
def autofix_storyboard(data: Any) -> tuple[Any, list[str]]:
    """Perbaikan deterministik tanpa AI. Mengembalikan (data_baru, daftar_perubahan)."""
    fixed = copy.deepcopy(data)
    changes: list[str] = []
    if not isinstance(fixed, dict) or not isinstance(fixed.get("scenes"), list):
        return fixed, changes

    for idx, scene in enumerate(fixed["scenes"]):
        if not isinstance(scene, dict):
            continue
        sid = str(scene.get("id") or "")
        path = f"scenes[{idx}]({sid})"

        prompt = scene.get("image_prompt")
        if isinstance(prompt, str):
            new = prompt.replace("Palette lock: Palette lock:", "Palette lock:")
            tag = _expected_tag(sid)
            if tag and AVOID_BLOCK.search(new):
                stripped = re.sub(r",?\s*" + SC_TAG.pattern, "", new)
                stripped = re.sub(r"(\[Avoid:[^\]]*?)\s*\]", lambda m: f"{m.group(1)}, {tag}]", stripped)
                stripped = stripped.replace("[Avoid: ,", "[Avoid:").replace("[Avoid:  ", "[Avoid: ")
                new = stripped
            if new != prompt:
                scene["image_prompt"] = new
                changes.append(f"{path}: image_prompt dirapikan (sc_tag/Palette lock).")

        video = scene.get("video_prompt")
        if isinstance(video, str) and video:
            new = AVOID_BLOCK.sub("", video)
            new = re.sub(r"--ar\s*\S+", "", new)
            new = SC_TAG.sub("", new)
            new = re.sub(r"\s{2,}", " ", new).strip()
            if new != video:
                scene["video_prompt"] = new
                changes.append(f"{path}: token terlarang dibuang dari video_prompt.")

        if sid == "COVER":
            wanted = {"narrative": scene.get("narrative") if scene.get("narrative") in ("-", "") else "-",
                      "video_prompt": ""}
            vm = fixed.get("video_metadata")
            if isinstance(vm, dict):
                wanted.update({"retention_role": "static_cover", "video_duration": 0})
                if vm.get("strategy") == "adaptive_motion":
                    wanted["motion_need"] = "none"
            for key, value in wanted.items():
                if scene.get(key) != value:
                    scene[key] = value
                    changes.append(f"{path}: {key} diset ke {value!r}.")
    return fixed, changes


# ------------------------------------------------------------------------ checks
def _check_root(data: dict, rep: _Report) -> tuple[str, list[dict]]:
    palette = data.get("palette_lock")
    if not isinstance(palette, str) or not palette.strip():
        rep.err("PALETTE_MISSING", "palette_lock", "palette_lock kosong/hilang.")
    elif not palette.startswith("Palette lock:"):
        rep.warn("PALETTE_FORMAT", "palette_lock", "Format baku: 'Palette lock: warna1, warna2, ...'.")
    if data.get("cover_text") not in ("on", "off"):
        rep.err("COVER_TEXT_INVALID", "cover_text", "cover_text harus 'on' atau 'off'.")
    chapter = data.get("chapter")
    if chapter is not None and (not isinstance(chapter, int) or isinstance(chapter, bool) or chapter < 1):
        rep.err("CHAPTER_INVALID", "chapter", "chapter harus bilangan bulat >= 1.")
    if not isinstance(data.get("visual_reference"), str) or not data["visual_reference"].strip():
        rep.warn("VISUAL_REFERENCE", "visual_reference", "visual_reference kosong/hilang (dipakai untuk konsistensi gaya antar bab).")

    vm = data.get("video_metadata")
    strategy = "still"
    if vm is not None:
        if not isinstance(vm, dict):
            rep.err("VIDEO_METADATA_INVALID", "video_metadata", "video_metadata harus object.")
        else:
            strategy = vm.get("strategy")
            if strategy not in STRATEGIES:
                rep.err("STRATEGY_INVALID", "video_metadata.strategy",
                        f"strategy harus salah satu dari {sorted(STRATEGIES)}.")
                strategy = "unknown"
            if vm.get("bulk_duration") != 10:
                rep.err("BULK_DURATION", "video_metadata.bulk_duration", "bulk_duration harus 10.")
            expected = False if strategy == "adaptive_motion" else True
            if strategy != "unknown" and vm.get("always_populate_prompts") is not expected:
                rep.err("ALWAYS_POPULATE", "video_metadata.always_populate_prompts",
                        f"untuk {strategy} harus {str(expected).lower()}.")

    chars = data.get("characters", [])
    registry: list[dict] = []
    if not isinstance(chars, list):
        rep.err("CHARACTERS_INVALID", "characters", "characters harus array (boleh kosong).")
    else:
        seen = set()
        for i, ch in enumerate(chars):
            path = f"characters[{i}]"
            if not isinstance(ch, dict):
                rep.err("CHARACTER_INVALID", path, "harus object.")
                continue
            alias = ch.get("alias")
            if not isinstance(alias, str) or not re.fullmatch(r"@[A-Z][A-Za-z0-9]*", alias):
                rep.err("ALIAS_FORMAT", f"{path}.alias", "alias wajib berformat @CamelCase (tidak boleh kosong).")
            elif alias in seen:
                rep.err("ALIAS_DUPLICATE", f"{path}.alias", f"{alias} terdaftar lebih dari sekali.")
            else:
                seen.add(alias)
            for field in ("name", "role", "description", "visual_prompt"):
                if not isinstance(ch.get(field), str) or not ch[field].strip():
                    rep.err("CHARACTER_FIELD", f"{path}.{field}", f"{field} wajib terisi.")
            registry.append(ch)
    return strategy, registry


def _check_prompt(scene: dict, path: str, sid: str, data: dict, registry: list[dict],
                  rep: _Report, state: dict) -> None:
    prompt = scene.get("image_prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        rep.err("IMAGE_PROMPT_EMPTY", f"{path}.image_prompt", "image_prompt kosong.")
        return

    if "NEGATIVE_PROMPT" in prompt:
        rep.err("NEGATIVE_BLOCK", f"{path}.image_prompt", "Jangan pakai blok NEGATIVE_PROMPT; pakai [Avoid: ...] inline.")

    blocks = AVOID_BLOCK.findall(prompt)
    body = prompt
    if len(blocks) != 1 or not prompt.rstrip().endswith("]"):
        rep.err("AVOID_BLOCK", f"{path}.image_prompt", "Harus tepat satu [Avoid: ...] di akhir prompt.")
    else:
        body = prompt[:prompt.rindex("[Avoid:")]
        items = [x.strip() for x in blocks[0].split(",") if x.strip()]
        tag = _expected_tag(sid)
        if tag and (not items or items[-1] != tag):
            rep.err("SC_TAG", f"{path}.image_prompt", f"token terakhir di Avoid harus {tag}.")
        if len(SC_TAG.findall(prompt)) != 1:
            rep.err("SC_TAG_COUNT", f"{path}.image_prompt", "sc_tag harus muncul tepat sekali.")
        guard_items = {i for i in items if not SC_TAG.fullmatch(i)}
        missing_c = [g for g in CINEMATIC_GUARD if g not in guard_items]
        missing_f = [g for g in FLAT_GUARD if g not in guard_items]
        if not missing_c:
            state["guards"].add("cinematic")
        elif not missing_f:
            state["guards"].add("flat")
        else:
            near = missing_c if len(missing_c) <= len(missing_f) else missing_f
            rep.err("AVOID_GUARD", f"{path}.image_prompt", f"Avoid guard tidak lengkap; kurang: {', '.join(near)}.")

    ratios = re.findall(r"--ar\s*(9:16|16:9)", body)
    if len(ratios) != 1:
        rep.err("RATIO", f"{path}.image_prompt", "Harus ada tepat satu '--ar 9:16' atau '--ar 16:9' sebelum [Avoid].")
    else:
        state["ratios"].add(ratios[0])

    palette = data.get("palette_lock")
    if isinstance(palette, str) and palette.strip() and palette not in prompt:
        rep.err("PALETTE_COPY", f"{path}.image_prompt", "Palette lock harus identik kata per kata dengan root palette_lock.")

    if prompt.lstrip().lower().startswith(("single frame", "rendered as")):
        rep.err("PROMPT_START", f"{path}.image_prompt", "Prompt tidak boleh diawali 'Single frame'/gaya; mulai dari subjek.")
    if LAYOUT_BAD.search(body):
        rep.err("LAYOUT_TERM", f"{path}.image_prompt", "Dilarang split-screen/grid/kolase.")
    if SAFETY_BAD.search(body):
        rep.warn("SAFETY_TERM", f"{path}.image_prompt",
                 f"Kata berisiko untuk filter Flow: {SAFETY_BAD.search(body).group(0)}.")

    # ukuran shot (wajib untuk adegan cerita, opsional untuk COVER)
    probe, found = body, []
    for shot in SHOTS:
        pattern = re.compile(r"(?<![\w-])" + re.escape(shot) + r"(?![\w-])", re.I)
        if pattern.search(probe):
            found.append(shot)
            probe = pattern.sub(" ", probe)
    if sid != "COVER":
        if len(found) != 1:
            rep.err("SHOT_SIZE", f"{path}.image_prompt",
                    f"Pilih tepat satu ukuran shot dari {SHOTS}; ditemukan: {found or 'tidak ada'}.")
        elif not re.search(re.escape(found[0]) + r"\s+framing", body, re.I):
            rep.warn("SHOT_FRAMING", f"{path}.image_prompt", f"'{found[0]}' sebaiknya diikuti kata 'framing'.")
        state["shots"].append((sid, found[0] if len(found) == 1 else None))
    elif len(found) > 1:
        rep.err("SHOT_SIZE", f"{path}.image_prompt", "COVER maksimal satu ukuran shot.")

    # karakter @
    aliases = re.findall(r"@[A-Za-z0-9_]+", prompt)
    known = {c.get("alias"): c for c in registry if isinstance(c, dict)}
    presence = scene.get("character_presence")
    if registry:
        if presence not in PRESENCE:
            rep.err("PRESENCE", f"{path}.character_presence", f"harus salah satu dari {sorted(PRESENCE)}.")
        if not isinstance(scene.get("emotion"), str) or not scene["emotion"].strip():
            rep.err("EMOTION", f"{path}.emotion", "emotion wajib untuk proyek berkarakter.")
    for alias in sorted(set(aliases)):
        if alias not in known:
            rep.err("ALIAS_UNREGISTERED", f"{path}.image_prompt", f"{alias} tidak terdaftar di characters[].")
            continue
        canonical = f"{alias} ({known[alias].get('visual_prompt', '')})"
        if canonical not in prompt:
            rep.err("ALIAS_VISUAL", f"{path}.image_prompt",
                    f"{alias} harus ditulis persis '{alias} (visual_prompt)' sesuai characters[].")
    if aliases and presence == "none":
        rep.err("PRESENCE_NONE", f"{path}.image_prompt", "character_presence 'none' dilarang memuat @alias.")
    if registry and presence == "required" and not aliases:
        rep.warn("PRESENCE_REQUIRED", f"{path}.image_prompt", "character_presence 'required' tetapi tidak ada @alias.")


def _check_video_prompt(scene: dict, path: str, rep: _Report) -> None:
    video = scene.get("video_prompt")
    if not isinstance(video, str):
        rep.err("VIDEO_PROMPT_TYPE", f"{path}.video_prompt", "video_prompt harus string (boleh kosong).")
        return
    bad = []
    if "@" in video:
        bad.append("@")
    if "--ar" in video:
        bad.append("--ar")
    if "[Avoid" in video:
        bad.append("[Avoid")
    if "sc_tag" in video:
        bad.append("sc_tag")
    if LAYOUT_BAD.search(video):
        bad.append("split-screen/grid/kolase")
    if TIME_LITERAL.search(video):
        bad.append(f"angka waktu literal '{TIME_LITERAL.search(video).group(0)}'")
    if bad:
        rep.err("DIFFUSERS_SAFE", f"{path}.video_prompt", f"Mengandung: {', '.join(bad)}.")


def _check_cover(scene: dict, path: str, data: dict, strategy: str, rep: _Report) -> None:
    if scene.get("narrative") not in ("-", ""):
        rep.err("COVER_NARRATIVE", f"{path}.narrative", "narrative COVER harus '-' (atau '').")
    if scene.get("video_prompt") not in ("",):
        rep.err("COVER_VIDEO", f"{path}.video_prompt", "COVER selalu still: video_prompt harus ''.")
    if strategy != "still":
        if scene.get("retention_role") != "static_cover":
            rep.err("COVER_ROLE", f"{path}.retention_role", "retention_role COVER harus 'static_cover'.")
        if scene.get("video_duration") != 0:
            rep.err("COVER_VIDEO_DURATION", f"{path}.video_duration", "video_duration COVER harus 0.")
    if strategy == "adaptive_motion" and scene.get("motion_need") != "none":
        rep.err("COVER_MOTION", f"{path}.motion_need", "motion_need COVER harus 'none'.")

    headline = scene.get("headline")
    editorial = scene.get("editorial_text")
    if data.get("cover_text") == "on":
        if not isinstance(headline, str) or not headline.strip():
            rep.err("COVER_HEADLINE", f"{path}.headline", "cover_text 'on' butuh headline hook.")
        else:
            if len(headline.split()) > 8:
                rep.err("COVER_HOOK_LENGTH", f"{path}.headline", "Hook maksimal 8 kata.")
            if scene.get("title_display") != headline:
                rep.err("COVER_TITLE_DISPLAY", f"{path}.title_display", "title_display harus identik dengan headline.")
            if not (isinstance(editorial, list) and editorial and editorial[0].get("text") == headline):
                rep.err("COVER_EDITORIAL", f"{path}.editorial_text", "editorial_text[0].text harus identik dengan headline.")
        if scene.get("cover_hook_type") not in HOOK_TYPES:
            rep.err("COVER_HOOK_TYPE", f"{path}.cover_hook_type", f"harus salah satu dari {sorted(HOOK_TYPES)}.")
    elif data.get("cover_text") == "off":
        if headline != "" or editorial != [] or scene.get("cover_hook_type") != "none":
            rep.err("COVER_OFF", path, "cover_text 'off': headline '', editorial_text [], cover_hook_type 'none'.")
        if "exact indonesian" in str(scene.get("image_prompt", "")).lower():
            rep.err("COVER_OFF_PROMPT", f"{path}.image_prompt", "cover_text 'off': prompt tidak boleh meminta lettering.")


def _check_story_text(scene: dict, path: str, rep: _Report) -> None:
    narrative = scene.get("narrative")
    if not isinstance(narrative, str) or not narrative.strip() or narrative.strip() == "-":
        rep.err("NARRATIVE_EMPTY", f"{path}.narrative", "narrative adegan cerita tidak boleh kosong/'-'.")
        return
    if "@" in narrative:
        rep.err("NARRATIVE_AT", f"{path}.narrative", "Dilarang '@' di narrative (TTS-Safe).")
    words = _words(narrative)
    if len(words) < 4:
        rep.warn("MINI_SCENE", f"{path}.narrative", "Adegan terlalu pendek (<4 kata); gabungkan dengan adegan lain.")
    if words and words[-1] in DEPENDENT_WORDS:
        rep.warn("CUT_MID_CLAUSE", f"{path}.narrative", f"Adegan berakhir di kata sambung '{words[-1]}'.")
    if not re.search(r"[.!?,;…:]\s*[\"')\]]*\s*$", narrative):
        rep.warn("CUT_PUNCT", f"{path}.narrative", "Adegan tidak berakhir di tanda baca batas kalimat/klausa.")

    duration = scene.get("duration")
    if not isinstance(duration, (int, float)) or isinstance(duration, bool) or duration <= 0:
        rep.err("DURATION", f"{path}.duration", "duration harus angka > 0.")
    else:
        estimate = len(words) * 60 / 135
        if estimate and not (estimate * 0.5 <= duration <= estimate * 2.5 + 2):
            rep.warn("DURATION_OFF", f"{path}.duration",
                     f"duration {duration}s jauh dari estimasi baca ~{estimate:.1f}s.")

    headline = scene.get("headline")
    editorial = scene.get("editorial_text")
    if isinstance(editorial, list) and editorial:
        if editorial[0].get("text") != headline:
            rep.err("HEADLINE_EDITORIAL", f"{path}.editorial_text", "editorial_text[0].text harus identik dengan headline.")
        if isinstance(headline, str) and headline and headline not in str(scene.get("image_prompt", "")):
            rep.warn("HEADLINE_IN_PROMPT", f"{path}.image_prompt", "Teks headline tidak ditemukan persis di image_prompt.")


def _scene_num(scene: dict) -> int | None:
    match = re.fullmatch(r"ADEGAN_(\d+)", str(scene.get("id")))
    return int(match.group(1)) if match else None


def _check_strategy(stories: list[tuple[int, dict]], strategy: str, rep: _Report) -> None:
    for idx, scene in stories:
        path = f"scenes[{idx}]({scene.get('id')})"
        num = _scene_num(scene)
        video = scene.get("video_prompt") or ""
        vdur = scene.get("video_duration")
        role = scene.get("retention_role")
        if strategy == "still":
            if video:
                rep.err("STILL_VIDEO", f"{path}.video_prompt", "Mode still: video_prompt harus ''.")
        elif strategy in STRATEGIES_DUAL:
            if not video:
                rep.err("DUAL_VIDEO_EMPTY", f"{path}.video_prompt", f"Strategi {strategy}: semua adegan cerita wajib punya video_prompt.")
            if vdur != 10:
                rep.err("VIDEO_DURATION", f"{path}.video_duration", "video_duration harus 10.")
            if strategy == "full" and role != "video_motion":
                rep.err("ROLE", f"{path}.retention_role", "strategi full: retention_role 'video_motion'.")
            elif strategy == "first_3":
                want = "golden_hook" if (num is not None and num <= 3) else "optional_motion"
                if role != want:
                    rep.err("ROLE", f"{path}.retention_role", f"strategi first_3: harus '{want}'.")
            elif strategy == "golden_25" and role not in {"golden_hook", "optional_motion"}:
                rep.err("ROLE", f"{path}.retention_role", "strategi golden_25: golden_hook atau optional_motion.")
            elif strategy == "rhythm_3point" and role not in {"golden_hook", "climax_rehook", "ending_hook", "optional_motion"}:
                rep.err("ROLE", f"{path}.retention_role", "retention_role tidak valid untuk rhythm_3point.")
        elif strategy == "adaptive_motion":
            need = scene.get("motion_need")
            if need not in ROLES_ADAPTIVE:
                rep.err("MOTION_NEED", f"{path}.motion_need", "harus 'high', 'low', atau 'none'.")
                continue
            reason = scene.get("motion_reason")
            if not isinstance(reason, str) or not reason.strip() or len(reason.split()) > 6:
                rep.err("MOTION_REASON", f"{path}.motion_reason", "motion_reason wajib, maksimal 6 kata.")
            if role not in ROLES_ADAPTIVE[need]:
                rep.err("ROLE", f"{path}.retention_role", f"motion_need '{need}': role harus salah satu {sorted(ROLES_ADAPTIVE[need])}.")
            if need == "none":
                if video or vdur != 0:
                    rep.err("MOTION_NONE", path, "motion_need 'none': video_prompt '' dan video_duration 0.")
            else:
                if not video:
                    rep.err("MOTION_VIDEO_EMPTY", f"{path}.video_prompt", f"motion_need '{need}': video_prompt wajib terisi.")
                if vdur != 10:
                    rep.err("VIDEO_DURATION", f"{path}.video_duration", "video_duration harus 10.")


def _check_golden25(stories: list[tuple[int, dict]], rep: _Report) -> None:
    lead = math.ceil(len(stories) * 0.25)
    for pos, (_, scene) in enumerate(stories, 1):
        want = "golden_hook" if pos <= lead else "optional_motion"
        if scene.get("retention_role") != want:
            rep.warn("ROLE", f"scenes({scene.get('id')})", f"strategi golden_25: diharapkan '{want}'.")


def _check_adaptive_global(stories: list[tuple[int, dict]], rep: _Report, share: bool) -> None:
    needs = [(s.get("id"), s.get("motion_need")) for _, s in stories]
    run = 0
    for sid, need in needs:
        run = run + 1 if need == "none" else 0
        if run > 2:
            rep.err("NONE_RUN", f"scenes({sid})", "Adegan 'none' maksimal 2 berurutan.")
            break
    if share and len(needs) >= 5:
        ratio = sum(1 for _, x in needs if x in ("high", "low")) / len(needs)
        if not 0.30 <= ratio <= 0.60:
            rep.err("MOTION_SHARE", "scenes", f"Proporsi high+low {ratio:.0%}; harus 30%-60%.")
    if stories and _scene_num(stories[0][1]) == 1 and needs[0][1] != "high":
        rep.warn("HOOK_MOTION", f"scenes({needs[0][0]})", "ADEGAN_01 (hook pembuka) disarankan 'high'.")


def _check_source(stories: list[tuple[int, dict]], source_text: str, rep: _Report) -> None:
    mine = _words(" ".join(str(s.get("narrative", "")) for _, s in stories))
    ref = _words(source_text)
    if mine == ref:
        return
    matcher = difflib.SequenceMatcher(None, ref, mine, autojunk=False)
    shown = 0
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        shown += 1
        if shown > 5:
            rep.err("NARRATION_DIFF", "scenes", "... (selisih lain tidak ditampilkan).")
            break
        ctx = " ".join(ref[max(0, i1 - 3):i1])
        rep.err("NARRATION_DIFF", "scenes",
                f"Narasi tidak 100% sama ({tag}) setelah '...{ctx}': sumber='{' '.join(ref[i1:i2])}' | json='{' '.join(mine[j1:j2])}'.")


# ------------------------------------------------------------------------- main
def validate_storyboard(data: Any, source_text: str | None = None, strict: bool = False,
                        expected_start: int | None = None) -> dict:
    """Validasi SATU berkas storyboard. `expected_start`: nomor ADEGAN pertama yang diharapkan."""
    rep = _Report()
    if not isinstance(data, dict):
        rep.err("ROOT", "$", "Root JSON harus object.")
        return _result(rep, "unknown", 0, strict)
    scenes = data.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        rep.err("SCENES", "scenes", "scenes harus array tidak kosong.")
        return _result(rep, "unknown", 0, strict)

    strategy, registry = _check_root(data, rep)
    raw_chapter = data.get("chapter")
    chapter = raw_chapter if isinstance(raw_chapter, int) and not isinstance(raw_chapter, bool) and raw_chapter >= 1 else None
    later = chapter is not None and chapter > 1
    state = {"guards": set(), "ratios": set(), "shots": []}
    stories: list[tuple[int, dict]] = []
    numbers: list[int] = []
    ids_seen, last_num = set(), None

    for idx, scene in enumerate(scenes):
        if not isinstance(scene, dict):
            rep.err("SCENE_TYPE", f"scenes[{idx}]", "scene harus object.")
            continue
        sid = scene.get("id")
        path = f"scenes[{idx}]({sid})"
        if sid in ids_seen:
            rep.err("ID_DUPLICATE", f"{path}.id", "id duplikat.")
        ids_seen.add(sid)

        if idx == 0 and sid != "COVER" and not later:
            rep.err("COVER_FIRST", f"{path}.id", "Item pertama harus id 'COVER' (hanya proyek tunggal atau Bab 1).")
        if sid == "COVER" and later:
            rep.err("COVER_LATER", f"{path}.id", f"Bab {chapter} tidak boleh memuat COVER (cover hanya di Bab 1).")
        elif sid == "COVER" and idx != 0:
            rep.err("COVER_POSITION", f"{path}.id", "COVER hanya boleh sebagai item pertama.")
        match = re.fullmatch(r"ADEGAN_(\d{2,})", str(sid))
        if sid != "COVER":
            if not match:
                rep.err("ID_FORMAT", f"{path}.id", "id adegan harus ADEGAN_NN (minimal 2 digit).")
            else:
                num = int(match.group(1))
                numbers.append(num)
                if last_num is None:
                    if later and num == 1:
                        rep.err("ID_RESTART", f"{path}.id", f"Bab {chapter} harus melanjutkan penomoran bab sebelumnya, bukan mulai dari 01.")
                    elif not later and num != 1:
                        rep.warn("ID_START", f"{path}.id", f"penomoran dimulai dari {num}, bukan 01.")
                    if expected_start is not None and num != expected_start:
                        rep.err("ID_START_EXPECTED", f"{path}.id", f"adegan pertama harus ADEGAN_{expected_start:02d}.")
                elif num != last_num + 1:
                    rep.err("ID_GAP", f"{path}.id", f"nomor tidak berurutan (setelah {last_num:02d} muncul {num:02d}).")
                last_num = num
            stories.append((idx, scene))

        for field in ("narrative", "image_prompt", "video_prompt", "duration"):
            if field not in scene:
                rep.err("FIELD_MISSING", f"{path}.{field}", f"field '{field}' wajib ada.")

        _check_prompt(scene, path, str(sid), data, registry, rep, state)
        _check_video_prompt(scene, path, rep)
        if sid == "COVER":
            _check_cover(scene, path, data, strategy, rep)
        else:
            _check_story_text(scene, path, rep)

    if len(state["ratios"]) > 1:
        rep.err("RATIO_MIXED", "scenes", f"Rasio campur: {sorted(state['ratios'])}.")
    explicit = data.get("aspect_ratio")
    if explicit is None:
        if "16:9" in state["ratios"]:
            rep.err("ASPECT_RATIO_MISSING", "aspect_ratio",
                    "aspect_ratio wajib; tanpa itu proyek 16:9 terdaftar sebagai 9:16 oleh app.")
        else:
            rep.warn("ASPECT_RATIO_MISSING", "aspect_ratio", "aspect_ratio hilang; sebaiknya diisi '9:16' atau '16:9'.")
    elif explicit not in ("9:16", "16:9"):
        rep.err("ASPECT_RATIO_INVALID", "aspect_ratio", "harus '9:16' atau '16:9'.")
    elif state["ratios"] and explicit not in state["ratios"]:
        rep.err("RATIO_ROOT", "aspect_ratio", f"aspect_ratio {explicit} tidak cocok dengan prompt {sorted(state['ratios'])}.")
    if len(state["guards"]) > 1:
        rep.warn("GUARD_MIXED", "scenes", "Avoid guard sinematik dan 2D tercampur antar adegan.")

    run = 1
    for i in range(1, len(state["shots"])):
        same = state["shots"][i][1] and state["shots"][i][1] == state["shots"][i - 1][1]
        run = run + 1 if same else 1
        if run >= 3:
            rep.warn("SHOT_REPEAT", f"scenes({state['shots'][i][0]})", "Tiga ukuran shot sama berturut-turut; variasikan.")
            break

    if strategy != "unknown":
        _check_strategy(stories, strategy, rep)
        if strategy == "golden_25" and chapter is None:
            _check_golden25(stories, rep)
        if strategy == "adaptive_motion":
            _check_adaptive_global(stories, rep, share=chapter is None)
    if source_text:
        _check_source(stories, source_text, rep)
    return _result(rep, strategy, len(scenes), strict, chapter=chapter,
                   story_range=(min(numbers), max(numbers)) if numbers else None)


def _result(rep: _Report, strategy: str, count: int, strict: bool, **extra: Any) -> dict:
    errors = rep.errors + (rep.warnings if strict else [])
    result = {"ok": not errors, "strategy": strategy, "scene_count": count,
              "errors": errors, "warnings": [] if strict else rep.warnings}
    result.update(extra)
    return result


def _chapter_from_name(name: str) -> int | None:
    match = re.search(r"(?:bab|chapter|part|episode)[_\-\s]*0*(\d+)", name or "", re.I)
    return int(match.group(1)) if match else None


def _dump(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False)


def _roster_diff(base: Any, other: Any) -> str:
    a = {c.get("alias"): c for c in base if isinstance(c, dict)} if isinstance(base, list) else {}
    b = {c.get("alias"): c for c in other if isinstance(c, dict)} if isinstance(other, list) else {}
    for alias in a.keys() | b.keys():
        if alias not in b:
            return f"{alias} ada di Bab 1 tetapi tidak ada di bab ini."
        if alias not in a:
            return f"{alias} ada di bab ini tetapi tidak ada di Bab 1."
        fields = sorted(f for f in a[alias].keys() | b[alias].keys() if a[alias].get(f) != b[alias].get(f))
        if fields:
            return f"{alias} berbeda pada field: {', '.join(fields)}."
    return "urutan roster berbeda."


def validate_chapter_set(files: list[tuple[str, Any]], source_text: str | None = None, strict: bool = False) -> dict:
    """Validasi satu set berkas bab: tiap berkas + konsistensi antar-bab.

    files: [(nama_berkas, data_json), ...]. Naskah sumber (opsional) = naskah PENUH semua bab.
    """
    rep = _Report()
    items: list[dict] = []
    for name, data in files:
        result = validate_storyboard(data, strict=False)
        for item in result["errors"]:
            rep.err(item["code"], f"{name}:{item['path']}", item["message"])
        for item in result["warnings"]:
            rep.warn(item["code"], f"{name}:{item['path']}", item["message"])
        from_name = _chapter_from_name(name)
        from_data = data.get("chapter") if isinstance(data, dict) else None
        if not isinstance(from_data, int) or isinstance(from_data, bool):
            from_data = None
            rep.err("CHAPTER_FIELD", f"{name}:chapter", "root 'chapter' (bilangan bulat) wajib pada proyek multi-bab.")
        if from_name is None:
            rep.warn("CHAPTER_NAME", name, "nama berkas sebaiknya memuat 'bab<N>' (mis. judul_bab2_config.json).")
        elif from_data is not None and from_name != from_data:
            rep.err("CHAPTER_NAME_MISMATCH", name, f"nama berkas bab {from_name} tetapi root chapter {from_data}.")
        items.append({"name": name, "data": data, "result": result,
                      "chapter": from_data if from_data is not None else from_name})

    valid = [i for i in items if isinstance(i["data"], dict) and isinstance(i["data"].get("scenes"), list)
             and i["data"]["scenes"] and i["chapter"] is not None]
    chapters = [i["chapter"] for i in valid]
    if len(chapters) != len(set(chapters)):
        rep.err("CHAPTER_DUPLICATE", "chapter", f"Nomor bab ganda: {sorted(chapters)}.")
    ordered = sorted(valid, key=lambda i: i["chapter"])
    if [i["chapter"] for i in ordered] != list(range(1, len(ordered) + 1)):
        rep.err("CHAPTER_SEQ", "chapter", f"Bab harus berurutan mulai dari 1 tanpa lompat (ditemukan: {sorted(chapters)}).")

    all_ids: dict[str, str] = {}
    previous_end = None
    for item in ordered:
        for scene in item["data"]["scenes"]:
            sid = scene.get("id") if isinstance(scene, dict) else None
            if sid in all_ids:
                rep.err("ID_DUPLICATE_SET", f"{item['name']}:{sid}", f"id sudah dipakai di {all_ids[sid]}.")
            elif sid:
                all_ids[sid] = item["name"]
        span = item["result"].get("story_range")
        if span and previous_end is not None and span[0] != previous_end + 1:
            rep.err("NUMBERING_GAP", f"{item['name']}:scenes",
                    f"bab ini mulai ADEGAN_{span[0]:02d}, seharusnya ADEGAN_{previous_end + 1:02d}.")
        if span:
            previous_end = span[1]

    strategy = "still"
    stories: list[tuple[int, dict]] = []
    if ordered:
        base = ordered[0]
        vm = base["data"].get("video_metadata")
        strategy = vm.get("strategy", "still") if isinstance(vm, dict) else "still"
        for item in ordered[1:]:
            for key in ROOT_SAME_KEYS:
                if _dump(base["data"].get(key)) != _dump(item["data"].get(key)):
                    rep.err("ROOT_MISMATCH", f"{item['name']}:{key}", f"'{key}' harus identik dengan Bab 1.")
            if base["data"].get("title") != item["data"].get("title"):
                rep.warn("TITLE_MISMATCH", f"{item['name']}:title", "title sebaiknya sama di semua bab.")
            if _dump(base["data"].get("characters", [])) != _dump(item["data"].get("characters", [])):
                rep.err("ROSTER_MISMATCH", f"{item['name']}:characters",
                        "roster characters[] harus identik dengan Bab 1: "
                        + _roster_diff(base["data"].get("characters", []), item["data"].get("characters", [])))
        for item in ordered:
            stories.extend((idx, s) for idx, s in enumerate(item["data"]["scenes"])
                           if isinstance(s, dict) and s.get("id") != "COVER")
        if strategy == "adaptive_motion":
            _check_adaptive_global(stories, rep, share=True)
        elif strategy == "golden_25":
            _check_golden25(stories, rep)
        if source_text:
            _check_source(stories, source_text, rep)
    return _result(rep, strategy, sum(i["result"]["scene_count"] for i in items), strict,
                   chapters=[i["chapter"] for i in ordered])


def format_for_repair(result: dict, max_items: int = 20) -> str:
    """Ringkas daftar error agar murah dikirim ke AI untuk perbaikan terarah."""
    lines = [f"[{e['code']}] {e['path']}: {e['message']}" for e in result["errors"][:max_items]]
    extra = len(result["errors"]) - max_items
    if extra > 0:
        lines.append(f"... dan {extra} error lain.")
    return ("Perbaiki HANYA bagian berikut pada JSON storyboard, jangan ubah narasi atau bagian lain, "
            "lalu kirim JSON utuh:\n" + "\n".join(lines))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validator isi storyboard JSON (satu berkas atau set bab).")
    parser.add_argument("files", nargs="+", help="satu berkas, atau beberapa berkas bab")
    parser.add_argument("--source", help="berkas naskah sumber (naskah penuh) untuk cek narasi 100%%")
    parser.add_argument("--strict", action="store_true", help="warning dianggap error")
    parser.add_argument("--fix", action="store_true", help="terapkan autofix dan tulis ke <file>.fixed.json")
    parser.add_argument("--json", action="store_true", help="keluaran JSON")
    args = parser.parse_args(argv)

    loaded = []
    for path in args.files:
        with open(path, encoding="utf-8-sig") as handle:
            data = load_llm_json(handle.read())
        if args.fix:
            data, changes = autofix_storyboard(data)
            out = path.rsplit(".", 1)[0] + ".fixed.json"
            with open(out, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            print(f"Autofix {os.path.basename(path)}: {len(changes)} perubahan -> {out}", file=sys.stderr)
        loaded.append((os.path.basename(path), data))
    source = open(args.source, encoding="utf-8").read() if args.source else None
    if len(loaded) == 1:
        result = validate_storyboard(loaded[0][1], source_text=source, strict=args.strict)
    else:
        result = validate_chapter_set(loaded, source_text=source, strict=args.strict)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"strategi={result['strategy']} adegan={result['scene_count']} "
              f"error={len(result['errors'])} warning={len(result['warnings'])}")
        for item in result["errors"]:
            print(f"ERROR   [{item['code']}] {item['path']}: {item['message']}")
        for item in result["warnings"]:
            print(f"WARNING [{item['code']}] {item['path']}: {item['message']}")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
