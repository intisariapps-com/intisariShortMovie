# Cover Scene = Thumbnail YouTube (item pertama `scenes`, hanya proyek tunggal atau Bab 1)

Cover adalah gambar pertama yang dilihat calon penonton. Tugasnya: **membuat orang berhenti menggulir dan mengeklik**, lalu isi video harus menepati janjinya. Bab 2 dan seterusnya TIDAK punya COVER.

## Kontrak JSON (tetap)
`"id": "COVER"`, `"narrative": "-"` (format ImageFlow boleh `""`), `"video_prompt": ""`, `"retention_role": "static_cover"` dan `"video_duration": 0` (mode dual/adaptive), `"motion_need": "none"` (adaptive). COVER selalu still image.

## Pengaturan Cover (`cover_text`, field root, terpisah dari pilihan headline adegan)
- Ditetapkan dari pilihan Cover di Langkah 4 wawancara: `[1] Cover dengan Teks Hook` → `"on"` (default; juga bila BYPASS tidak menyebut Cover), `[2] Cover Bersih` → `"off"`.
- **`"on"`**: `headline`, `title_display`, dan `editorial_text[0].text` berisi **teks hook yang IDENTIK**, Bahasa Indonesia, batas keras 8 kata dan 2 baris (**ideal 2-5 kata**), satu pola yang dicatat di `cover_hook_type`.
- **`"off"`**: `headline` `""`, `editorial_text` `[]`, `cover_hook_type: "none"`, dan `image_prompt` melarang lettering. Aturan visual di bawah tetap berlaku.

## Proses merancang cover (lakukan diam-diam, jangan ditampilkan)
1. **Cari celah rasa penasaran**: pindai SELURUH naskah, bukan hanya kalimat pembuka. Pilih fakta paling mengejutkan, konflik, angka, larangan, atau hal janggal yang jawabannya baru ada di video.
2. **Pilih satu pola hook** dari tabel di bawah.
3. **Tetapkan satu titik fokus + satu elemen penasaran** (lihat Visual).
4. **Tata warna & kontras** dari `palette_lock`.
5. **Tata letak teks & zona aman**, lalu lewati checklist di akhir.

## Pola hook (`cover_hook_type`)
| Tipe | Rumus | Contoh bentuk |
|---|---|---|
| `pertanyaan` | Siapa/Mengapa/Benarkah + hal janggal | `SIAPA SEBENARNYA PEMBANGUNNYA?` |
| `kontras` | A, tapi B / angka yang mengejutkan | `BUKAN BUDAK, TAPI PEKERJA` |
| `rahasia` | hal tersembunyi / terlarang | `RAHASIA DI BALIK PINTU TERKUNCI` |
| `sebelum_sesudah` | Dulu X, kini Y | `DULU SEPI, KINI JADI KOTA` |
| `cliffhanger` | momen puncak yang menggantung | `SATU MALAM YANG MENGUBAH SEGALANYA` |

- Kata pemicu yang efektif: *ternyata, sebenarnya, rahasia, bukan, mengapa, terakhir, tak disangka*. Hindari judul generik ala buku (*Sejarah ...*, *Tentang ...*, *Fakta ...*).
- Teks cover dan judul video saling melengkapi, bukan salinan: cover memicu emosi/penasaran dalam beberapa kata; judul memuat kata kunci pencarian.
- **Kejujuran wajib**: hook harus terjawab oleh isi video; jangan melebih-lebihkan klaim, jangan menjual tragedi atau tokoh nyata untuk sensasi, dan jangan menyesatkan (kebijakan thumbnail platform).

## Visual: aturan klik
- **Satu titik fokus besar** (mengisi sekitar separuh frame) + **satu elemen penasaran** (janggal, tertutup, skala tak wajar, kontras, atau arah pandang menuju sesuatu). Total hanya tiga hal: subjek, elemen penasaran, teks. Tidak ada keramaian objek kecil.
- **Momen tegang, bukan hasil akhir**: tampilkan sesaat sebelum/sesudah puncak agar jawabannya tetap di dalam video. Jangan spoiler penuh jawaban hook.
- **Kontras tinggi**: subjek terang di latar gelap atau sebaliknya; gunakan pasangan kontras tertinggi dari `palette_lock`, jangan menambah warna di luar palet. Hindari gambar gelap total atau pucat karena hilang di feed.
- **Ekspresi**: bila ada tokoh, tampilkan emosi jelas (terkejut, cemas, tegang) dengan mata/wajah terbaca; gaya 2D menyalurkannya lewat pose dan bentuk mata. Arah pandang atau arah gerak mengarah ke elemen penasaran atau ke teks.
- **Komposisi**: aturan sepertiga, sisakan ruang kosong untuk teks, kedalaman depan-tengah-belakang dalam SATU frame (tanpa kolase/split-screen).
- **Terbaca di ukuran kecil**: bayangkan thumbnail selebar jempol; bila detail hilang, sederhanakan.
- Ukuran shot bebas (`Wide Shot`, `Medium Shot`, `Close-Up`) dan tetap diikuti `framing`. `character_presence` COVER mengikuti `character-mode.md`.

## Teks pada gambar (`cover_text: "on"`)
- Huruf kapital tebal, kontras tinggi terhadap latar, satu kata kunci boleh diberi warna aksen dari palet. Tanpa paragraf, URL, atau watermark.
- Model gambar sering salah mengeja teks panjang: gunakan kata pendek, minim tanda baca, maksimal 2 baris.

## Zona aman & rasio
Cover mengikuti rasio proyek (`--ar` sama dengan semua adegan). Patokan konservatif, bukan spesifikasi resmi:
- **9:16**: jaga teks dan wajah utama di luar pita ~15% teratas, sisi kiri-kanan ~10-15%, dan ~25-35% terbawah. Teks hook di area atas-tengah.
- **16:9**: kosongkan ~15% pojok kanan bawah (label durasi YouTube menutupinya) dan beri margin tepi ~5-8%. Teks di sepertiga kiri/atas, subjek di sisi lain.
- Bila proyek 9:16 juga butuh thumbnail horizontal 16:9, varian itu ditawarkan di Paket SEO (`seo-caption.md`), bukan di JSON.

## `image_prompt` COVER
Urutan: subjek/aksi yang merangkum cerita + elemen penasaran → ukuran shot + `framing` → latar → (bila `"on"`) arahan teks hook di zona aman, misalnya `set the exact Indonesian hook "..." in bold high-contrast lettering in the upper-center safe zone` → medium/gaya → `Palette lock` → `--ar` → `[Avoid: ..., sc_tag_cover]`. Tetap berlaku: safety, palet terkunci, Avoid guard. Jangan memaksakan gaya 3D.

## Checklist (cek diam-diam sebelum menulis JSON)
1. Hook Indonesia, satu pola, maksimal 8 kata (ideal 2-5), dan terjawab di video.
2. Satu fokus + satu elemen penasaran, tanpa spoiler penuh.
3. Kontras tinggi dari palet, tanpa warna di luar palet.
4. Teks dan wajah berada di zona aman, terbaca di ukuran kecil.
5. Lolos safety dan tidak menyesatkan.
