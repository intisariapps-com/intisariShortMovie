# Paket SEO & Caption (dibuat HANYA setelah pengguna mengetik `SEO`)

## Masukan
Judul dan `caption` di JSON, teks hook COVER, narasi semua adegan (semua bab), `duration` tiap adegan, `aspect_ratio`. Platform utama: `9:16` → YouTube Shorts / TikTok / Reels; `16:9` → YouTube video panjang. Bila pengguna menyebut platform lain, ikuti pengguna.

## Aturan
- Bahasa Indonesia. Gunakan hanya fakta yang ada di naskah.
- **Jangan mengarang** statistik, sumber, nama tokoh, atau volume pencarian. Beri catatan bahwa kata kunci perlu divalidasi lewat saran pencarian YouTube/Google. Sumber yang tidak ada di naskah ditulis sebagai placeholder `[ISI SUMBER]`.
- Janji pada judul, cover, dan deskripsi harus terjawab di video.
- Setiap bagian ditaruh di blok kode ` ```text ` TERPISAH agar mudah disalin, dengan judul bagian tebal di atasnya.

## Bagian keluaran (urut)
1. **Ringkasan & Kata Kunci**: topik inti satu kalimat; 1 kata kunci utama; 3-5 kata kunci sekunder; 3-5 frasa long-tail/pertanyaan pencarian yang relevan dengan isi naskah.
2. **Judul**: 5 alternatif, masing-masing maksimal 60 karakter, kata kunci utama di awal, pola berbeda (pertanyaan, angka dari naskah, kontras, rahasia, manfaat). Tandai 1 rekomendasi dengan alasan satu kalimat. Judul tidak menyalin teks hook cover.
3. **Deskripsi YouTube**: dua baris pertama (sekitar 150 karakter) memuat kata kunci dan hook; ringkasan 2-3 kalimat natural; poin pembahasan; **timestamp** dihitung dari `duration` adegan (format `0:00`, tandai "estimasi"; hanya untuk video 16:9, Shorts tanpa timestamp); ajakan berinteraksi; sumber (`[ISI SUMBER]` bila perlu); 3 hashtag di akhir.
4. **Tag YouTube**: 10-15 tag, total maksimal 500 karakter, urut dari paling relevan, campuran frasa luas dan spesifik.
5. **Hashtag**: YouTube 3-5 (maksimal 15; lebih dari itu diabaikan); TikTok/Reels 3-5 campuran satu luas dan sisanya niche.
6. **Caption pendek per platform**: Shorts, TikTok, Reels. Baris 1 berupa hook (maksimal ~80 karakter), isi 1-2 kalimat, pertanyaan ajakan, hashtag. Nada TikTok santai, Reels sedikit lebih rapi.
7. **Komentar sematan (pinned comment)**: satu pertanyaan terbuka yang memantik diskusi dan terkait hook.
8. **Varian Thumbnail (A/B)**: 3 alternatif teks hook (maksimal 8 kata, ideal 2-5) dengan tipe berbeda, tandai 1 rekomendasi. Bila proyek 9:16 dan pengguna ingin thumbnail horizontal: sertakan satu `image_prompt` cover `--ar 16:9` mengikuti `cover-engine.md` (Palette lock dan Avoid guard sama, tanpa `sc_tag`).
9. **Cek Kejujuran & Kepatuhan**: daftar singkat klaim faktual yang perlu diverifikasi; pengingat memeriksa kebijakan terbaru platform soal pengungkapan konten buatan AI/sintetis; pengingat hak cipta musik dan aset pihak ketiga.
