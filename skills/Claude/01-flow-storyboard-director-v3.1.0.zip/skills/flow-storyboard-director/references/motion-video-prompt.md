# Strategi Video Motion & `video_prompt`

## Prinsip umum
- `video_prompt` standar **10 detik** (Dual-Prompt).
- **`still` (default)**: seluruh adegan `video_prompt: ""`.
- **`COVER` selalu still**: `video_prompt: ""`, `retention_role: "static_cover"`, agar tipografi cover tetap tajam.
- **Pemisahan durasi**: `scenes[i].duration` = durasi baca narasi alami (detik); `video_duration: 10` dan root `video_metadata.bulk_duration: 10` = target klip I2V (agar FFmpeg memotong bersih, *single take*).

## Strategi Dual-Prompt (`first_3`, `golden_25`, `rhythm_3point`, `full`)
**Zero Wasted Prompts**: 100% adegan cerita (`ADEGAN_01` s/d terakhir) tetap mendapat `video_prompt` 10 detik. Strategi hanya menandai prioritas lewat `retention_role`, tidak mengosongkan `video_prompt` adegan lain, supaya satu JSON siap untuk semua strategi dan upgrade ke Full tanpa regenerate.
- `first_3`: `ADEGAN_01..03` = `golden_hook`; sisanya `optional_motion`.
- `golden_25`: 25% adegan awal = `golden_hook`; sisanya `optional_motion`.
- `rhythm_3point`: Hook awal (01-03), Klimaks tengah (~55%), Ending = `golden_hook` / `climax_rehook` / `ending_hook`; sisanya `optional_motion`.
- `full`: seluruh `ADEGAN_01..N` = `video_motion`.

## Strategi `adaptive_motion`
Mode ini tidak tunduk pada "Zero Wasted Prompts". AI menilai tiap adegan cerita (bukan COVER) dan mengisi `motion_need` (`high`/`low`/`none`) dan `motion_reason` (Bahasa Indonesia, maks. 6 kata).
- **`high`** → `video_prompt` 10s penuh. Untuk aksi fisik/perpindahan/perjalanan; pengungkapan, klimaks, momen epik; hook pembuka (`ADEGAN_01..02`) dan penutup; fenomena alam bergerak (air, awan, api, partikel). `retention_role`: `golden_hook` (hook awal), `climax_rehook` (klimaks), `ending_hook` (penutup), atau `video_motion` (lainnya).
- **`low`** → `video_prompt` 10s gerak halus (`Subtle Facial & Emotion` atau `Atmospheric Drift`). Untuk emotional hold, tatapan diam, suasana tenang yang tetap hidup. `retention_role`: `optional_motion`, atau `ending_hook` bila adegan penutup.
- **`none`** → `video_prompt: ""`. Untuk diagram, data, istilah teknis, objek statis yang harus terbaca, atau gerak yang mengganggu. `retention_role`: `still_only`.

Aturan pengaman:
1. `COVER`: `static_cover`, `video_prompt: ""`, `motion_need: "none"`.
2. Adegan `none` maksimal 2 berurutan (dihitung untuk seluruh proyek, termasuk melintasi batas bab).
3. Proyek ≥ 5 adegan cerita: total `high` + `low` di 30%-60% adegan cerita (dihitung untuk seluruh proyek, bukan per bab); di bawah 5 adegan bebas sesuai narasi.
4. Tiga adegan berurutan dengan jenis gerak sama diselang-seling agar tidak monoton.
5. `motion_need` tidak mengubah `character_presence`, `emotion`, atau `visual_prompt` karakter.
6. `video_prompt` mengikuti DIFFUSERS-SAFE.
7. Root `video_metadata.strategy: "adaptive_motion"` dan `always_populate_prompts: false`.

## Kamus trajektori kamera (pilih yang cocok dengan narasi)
- Emosi/tatapan/wajah → `Subtle Facial & Emotion`: *"intimate cinematic shallow depth-of-field portrait tracking subtle emotional changes and natural breathing"*
- Aksi kinetik/perjalanan → `Tracking Pan`: *"smooth steady horizontal tracking pan shot following subject movements"*
- Momen epik/megah/keajaiban → `Orbital Arc`: *"smooth cinematic orbital camera rotating 45 to 90 degrees around focal subject"*
- Fisika lingkungan/suasana alam → `Atmospheric Drift`: *"slow floating camera drift capturing dynamic atmospheric particles and soft lighting shifts"*
- Tegangan dramatis/hook kaget → `Cinematic Push-In`: *"smooth dramatic push-in dolly shot intensifying scene tension"*

## Formula Elastic 10s Front-Loaded
- **0-3 dtk**: langsung aksi subjek konkret + gerak kamera segera dimulai, tanpa jeda diam (tetap berdampak bila FFmpeg memotong di 3-5 dtk).
- **3-10 dtk**: momentum kamera konstan, gerak napas/kain alami, partikel atmosfer/cahaya lembut, `high temporal consistency, zero freezing`, tanpa ending mendadak atau cut.

## DIFFUSERS-SAFE
Di dalam `video_prompt` jangan ada `@`, `--ar`, `[Avoid: ...]`, `sc_tag_*`, instruksi split-screen, atau angka waktu literal (`"10 seconds"`, `"at 5s"`). Rujuk tokoh dengan kata benda Inggris deskriptif (*the man*, *the woman*).
