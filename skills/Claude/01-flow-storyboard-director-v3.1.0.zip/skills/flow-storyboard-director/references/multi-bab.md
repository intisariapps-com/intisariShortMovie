# Aturan Multi-Bab

Berlaku bila naskah dibagi beberapa bab. Satu bab = satu berkas JSON. Tujuannya agar berkas-berkas itu lolos validator dan bisa digabung importer tanpa konflik.

1. **Pembagian bab di Master Blueprint**: tulis rentang final dan terkunci, misalnya `Bab 1: COVER + ADEGAN_01-ADEGAN_12`, `Bab 2: ADEGAN_13-ADEGAN_24`. Bab dipotong di akhir kalimat, tidak di tengah kalimat.
2. **Nama berkas**: `<judul_snake_case>_bab<N>_config.json` (N tanpa nol di depan). Root berisi `"chapter": N`.
3. **Penomoran lanjut**: Bab 2 dimulai dari adegan setelah adegan terakhir Bab 1 (Bab 1 berakhir `ADEGAN_12` → Bab 2 mulai `ADEGAN_13`). `sc_tag` mengikuti nomor global (`ADEGAN_13` → `sc_tag_13`). Minimal 2 digit; mulai `ADEGAN_100` memakai 3 digit.
4. **COVER hanya di Bab 1.** JSON Bab 2 dan seterusnya tidak memuat COVER; `scenes[0]` adalah adegan cerita pertama bab itu.
5. **Root metadata IDENTIK di semua bab** (salin dari Bab 1, jangan diubah): `title` (tanpa kata "Bab"), `caption`, `aspect_ratio`, `recommended_speed`, `interaction_mode`, `cover_text`, `palette_lock`, `visual_reference`, `video_metadata`.
6. **Roster `characters[]` IDENTIK di semua bab**: salin seluruh roster dari Master Blueprint apa adanya, termasuk tokoh yang baru muncul di bab berikutnya, tanpa catatan bab pada `role`. Tag `@alias` di `image_prompt` tetap hanya pada adegan tempat tokoh benar-benar hadir (`character-mode.md`).
7. **Narasi**: tiap bab hanya memuat narasi bab itu, 100% utuh, tanpa duplikasi. Gabungan semua bab = naskah penuh.
8. **Motion**: aturan proporsi `adaptive_motion` (30%-60%) dan batas `none` maksimal 2 berurutan dihitung untuk seluruh proyek, termasuk melintasi batas bab. Strategi `first_3` memakai nomor global (`ADEGAN_01`-`ADEGAN_03` ada di Bab 1).
9. **Penutup per bab**: bab yang bukan terakhir diakhiri satu kalimat berisi rentang adegan bab berikutnya, tanpa tawaran SEO. Tawaran SEO hanya setelah bab terakhir.
