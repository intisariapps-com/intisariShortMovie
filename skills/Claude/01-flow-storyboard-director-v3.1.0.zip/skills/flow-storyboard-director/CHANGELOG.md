# v3.1.0

## Keputusan desain
- Multi-bab: penomoran `ADEGAN_NN` dan `sc_tag_NN` **lanjut** antar-bab (nomor global).
- COVER **hanya di Bab 1**; fungsinya thumbnail YouTube.
- Paket SEO **ditawarkan setelah JSON final** (bab terakhir / proyek tunggal), dibuat hanya bila pengguna mengetik `SEO`.

## Perubahan plugin
- `SKILL.md`: referensi dimuat sesuai kebutuhan (cover-engine hanya Bab 1, multi-bab hanya proyek bab); aturan format JSON, root wajib, Single Still Murni, "validasi oleh app", tawaran SEO.
- `references/cover-engine.md`: ditulis ulang sebagai panduan thumbnail klik-able (celah penasaran, 5 pola hook, aturan visual, zona aman 9:16 dan 16:9, checklist). Referensi basi "Langkah 11/9" dihapus.
- `references/multi-bab.md` (baru), `references/seo-caption.md` (baru).
- Skema: tambah `chapter`, `aspect_ratio`; `visual_reference` kini ada di ketiga skema.
- `interview-steps.md`: baris Pembagian Bab dan penjelasan opsi Cover. `character-mode.md` dan `motion-video-prompt.md`: rujukan aturan antar-bab.
- `examples/`: contoh lama (format pra-v3) dihapus; diganti pasangan JSON dua bab + naskah sumber (lolos validator dan importer).

## Alat
- `tools/storyboard_content_validator.py`: validator isi satu berkas + `validate_chapter_set` untuk set bab (urutan bab, lanjutan nomor, COVER hanya Bab 1, root metadata dan roster identik, proporsi motion tingkat proyek, narasi 100% terhadap naskah penuh).

## Belum dikerjakan (opsional)
- Mode `PERBAIKI:` (AI hanya mengeluarkan adegan yang salah) perlu dukungan app untuk menimpa per `id`.
- Importer: peringatan bila root metadata antar-bab berbeda (kini sudah ditangkap validator).
