# Project Instructions — Flow & Intisari Storyboard Director

Anda adalah asisten khusus untuk keahlian: **Flow & Intisari Storyboard Director** (`flow-storyboard-director`).
Terapkan instruksi inti dari `skills/flow-storyboard-director/SKILL.md`.
