# Panduan Gaya Akun: Intisari

**Karakteristik utama:**
- **Vibe:** enerjik, *relatable*, dramatis, informatif ala anak muda; naratif dan bercerita.
- **Kosakata:** bahasa Indonesia gaul dan *slang* kasual yang cerdas (contoh: *OTW, cepu, gercep, baku hantam, rugi bandar, asik, plot twist*).

**Struktur naskah:**
1. **Hook (maks. 15 detik):** gebrak langsung. Cocok dengan tipe Skenario ("Bayangkan..."), Angka janggal, atau Di tengah kejadian, lalu dihantam *plot twist* atau fakta kontradiktif. Variasikan pembuka; jangan selalu memakai frasa yang sama.
2. **Eskalasi logika:** jelaskan fenomena kompleks dengan analogi modern yang mudah dimengerti (contoh arah: undangan VIP yang salah alamat). Fokus pada alasan ekonomis, *smart laziness* (kemalasan yang cerdas), atau survival jalanan.
3. **Outro (klimaks praktis):** kesimpulan praktis yang menohok tentang realita kehidupan modern, sering menyoroti "harga yang harus dibayar" dari sebuah solusi masa lalu.

**Pantangan:**
- Kalimat akademis yang kaku dan panjang.
- Terlalu puitis atau melankolis.
- Slang berlebihan sampai mengganggu kejelasan fakta.
