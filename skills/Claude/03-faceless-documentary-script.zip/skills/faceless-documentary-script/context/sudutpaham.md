# Panduan Gaya Akun: SudutPaham

**Identitas inti**
- **Misi:** meluruskan asumsi keliru dan membongkar alasan di balik fenomena sehari-hari dengan logika praktis, ekonomi, atau sains.
- **Slogan:** "Bongkar Fakta. Biar Gak Salah Paham."
- **Persona:** cerdas, *to the point*, logis; teman tongkrongan yang tahu banyak hal di balik layar.

**Identitas verbal**
- **Suara:** dinamis, tempo sedikit cepat, penekanan dramatis pada bagian *twist*. Berbeda dari Intisari, naskah ini lebih lugas dan berurutan: bantahan, lalu bukti, lalu kesimpulan.
- **Hook (konsisten):** selalu berupa bantahan asumsi atau pertanyaan "pernah sadar nggak". Variasikan susunan kalimatnya di tiap naskah; jangan menyalin frasa contoh persis.
- **Outro (paten, brand):** "Dari SudutPaham yang baru, [1 kalimat kesimpulan]. Oh begitu faktanya, jadi jangan sampai salah paham ya! Jangan lupa follow akun SudutPaham yaa."

**Pilar topik (inspirasi Mode Ideasi)**
1. **Strategi bisnis di balik layar:** tata letak toko, desain kasino, taktik harga.
2. **Desain tersembunyi:** fungsi detail kecil pada benda sehari-hari.
3. **Sains kehidupan sehari-hari:** fenomena tubuh dan lingkungan yang jarang dijelaskan.
Setiap topik wajib melewati verifikasi (lihat `research_protocol.md`); contoh klaim populer di kanal ini sering tidak terbukti.

**Identitas visual (hanya untuk serah-terima storyboard, abaikan saat menulis naskah)**
Palet biru navy dan kuning terang; font tebal modern (Montserrat/Poppins/Arial Black); potongan visual berganti tiap 2-3 detik dengan penekanan zoom, lingkaran merah, atau panah kuning pada momen pengungkapan.
