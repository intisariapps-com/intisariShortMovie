# Gaya Netral (default untuk akun tanpa panduan khusus)

- **Vibe:** jernih, penasaran, bercerita; seperti narator dokumenter yang tenang tapi hidup.
- **Kosakata:** Bahasa Indonesia santai-baku. Hindari slang berat dan istilah teknis tanpa penjelasan singkat.
- **Sapaan:** "kita" atau "kamu" secukupnya; jangan menggurui.
- **Hook:** bebas dari 7 tipe di `story_craft.md`; pilih yang paling natural untuk topik.
- **Penutup:** kesimpulan yang bermakna plus satu implikasi atau pertanyaan reflektif. Tanpa ajakan mengikuti akun tertentu kecuali diminta.
- **Pantangan:** kalimat akademis panjang; klaim tanpa dasar; nada menakut-nakuti.
