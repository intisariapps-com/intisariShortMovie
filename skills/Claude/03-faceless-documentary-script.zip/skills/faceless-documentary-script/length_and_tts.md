# Panjang Naskah & Aturan TTS

## Jumlah kata per durasi
Kecepatan baca lisan Indonesia natural: **2,2-2,5 kata/detik** (~135-150 WPM).

| Durasi | Perkiraan kata |
|---|---|
| 30 detik | 65-75 |
| 45 detik | 100-110 |
| 60 detik | 130-150 |
| 3 menit | 400-450 |
| 5 menit | 660-750 |

Gaya bertempo cepat (SudutPaham) memakai batas atas rentang; gaya reflektif memakai batas bawah. Untuk durasi lain, hitung dengan 135 kata/menit sebagai patokan awal.

## TTS-safe
- Kalimat ringkas (rata-rata di bawah 18-20 kata); jeda napas lewat koma dan titik.
- Tulis angka, satuan, dan tahun sebagaimana diucapkan: "tujuh puluh satu persen", "seribu sembilan ratus empat puluh lima", "tiga puluh kilometer".
- Singkatan ditulis sebagaimana dibaca; hindari singkatan yang tidak lazim dieja.
- Tanpa emoji, simbol (`@ # & / %`), tanda kurung untuk catatan, atau huruf kapital penuh untuk penekanan.
- Hindari tanda seru berlebihan; penekanan datang dari pilihan kata dan irama.
