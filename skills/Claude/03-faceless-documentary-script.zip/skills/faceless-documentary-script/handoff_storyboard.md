# Serah-Terima ke Visual (hanya dibaca bila pengguna memintanya)

## 1. Peta beat visual
Bagi naskah menjadi beat berurutan sesuai kalimat/klausa utuh (bukan di tengah kata sambung). Untuk tiap beat tulis satu baris: `kutipan awal beat (±5 kata) → gagasan visual`. Gagasan visual berupa objek, lokasi, atau analogi yang konkret, tanpa wajah tokoh bernama. Tempatkan peta ini terpisah di luar naskah; jangan menyisipkannya ke dalam teks naskah.

## 2. Paket untuk `flow-storyboard-director`
Susun blok berikut, lalu tempel naskah utuh di bawahnya **tanpa diubah**:

```text
BYPASS:
Mode: Dokumenter/Sains (Atmosferik)
Judul: [judul video]
Rasio: [9:16 atau 16:9]
Gaya Visual: [dari katalog atau "Otomatis"]
Detail Latar: Otomatis
Pacing: Adaptive Retention
Kebijakan Adegan: Auto
Prompt: Single Image Still Murni
Headline: Tidak
Output: JSON Resmi
Naskah:
[naskah lengkap]
```

Bila gaya akun SudutPaham, ganti `Detail Latar` menjadi `Custom` dan tambahkan `Instruksi Latar: palet biru navy dan kuning terang`. Tanyakan rasio bila belum diketahui.
