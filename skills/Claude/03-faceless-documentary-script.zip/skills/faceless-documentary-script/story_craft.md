# Kerajinan Naskah: Sudut, Hook, Retensi, Struktur

## Lensa sudut (pilih yang paling didukung bukti; jangan semua "ada yang disembunyikan")
1. **Insentif ekonomi**: siapa untung dan bagaimana.
2. **Psikologi manusia**: bias, kebiasaan, persepsi.
3. **Desain & rekayasa**: alasan teknis di balik benda sehari-hari.
4. **Sains alam**: mekanisme sebab-akibat.
5. **Sejarah & kebetulan**: asal-usul yang tidak terduga.
6. **Budaya & kebiasaan**: mengapa suatu praktik bertahan.
Motif tersembunyi atau konspirasi hanya boleh dipakai bila terdokumentasi, bukan sebagai bumbu.

## Tipe hook (pilih satu; rotasi antar naskah; hook harus dijawab oleh isi video)
1. **Bantahan asumsi**: meluruskan salah paham umum.
2. **Skenario**: "Bayangkan..." lalu pukulan fakta.
3. **Angka janggal**: satu angka yang tidak cocok dengan intuisi.
4. **Pertanyaan sehari-hari**: hal biasa yang ternyata jarang dipikirkan.
5. **Di tengah kejadian (in medias res)**: mulai dari momen puncaknya, lalu mundur.
6. **Kontras dua dunia**: dua hal bersandingan yang seharusnya tidak berpasangan.
7. **Janji mekanisme**: ada alasan teknis yang jarang dibahas.
Pilih tipe yang cocok dengan gaya akun (lihat `context/`). Dilarang hook yang tidak terjawab atau melebih-lebihkan temuan.

## Retensi
- **Jangkar terbuka** di hook: satu pertanyaan yang jawabannya baru muncul belakangan.
- **Re-hook** di sekitar 40-60% durasi ("tapi ada yang lebih aneh...") untuk video 3 menit ke atas.
- **Mikro-payoff** setiap ±20-30 detik: satu temuan kecil yang memuaskan.
- **Irama**: selang-seling kalimat sangat pendek dan sedang. Jangan memakai kata seru atau frasa pemicu yang sama berulang kali ("Eits", "Faktanya...") dalam satu naskah.

## Struktur menurut durasi
| Durasi | Hook | Isi | Penutup |
|---|---|---|---|
| 30-45 dtk | ±5 dtk | 1 poin inti | 1 kalimat kesimpulan |
| 60 dtk | ±8 dtk | 2 poin + 1 analogi | kesimpulan singkat |
| 3 menit | ≤15 dtk | 3-4 poin, 1 re-hook | kesimpulan + implikasi |
| 5 menit | ≤15 dtk | 5-6 beat, 2 re-hook | kesimpulan + implikasi |

## Variasi dalam satu seri
Bila pengguna meminta beberapa naskah, ganti lensa, tipe hook, dan bentuk penutup di setiap naskah. Jangan menyalin kalimat contoh di mana pun, termasuk contoh di bawah.

## Contoh irama (hanya ilustrasi tempo, bukan sumber fakta)
Pernah sadar, kenapa lampu merah terasa jauh lebih lama saat kamu sedang buru-buru? Jam di dashboard tidak melambat. Yang berubah adalah apa yang kamu perhatikan. Ketika pikiran sibuk menunggu, kamu terus memeriksa waktu, dan setiap pemeriksaan membuat detik terasa lebih panjang. Sebaliknya, saat perhatianmu tersita hal lain, menit bisa lewat tanpa terasa. Jadi bukan lampunya yang lambat. Perhatianmu yang menjadi stopwatch.
