# Protokol Riset & Integritas Fakta

Dokumenter harus bisa dipertanggungjawabkan. Aturan ini berlaku di Mode Riset Penuh dan Mode Kilat.

## Aturan utama
1. **Cari, jangan mengarang.** Bila alat pencarian web tersedia, gunakan untuk setiap fakta penting, angka, tanggal, dan nama. Lakukan beberapa pencarian terpisah (minimal satu per pilar). Utamakan sumber primer atau kredibel: jurnal, lembaga resmi, arsip, penerbit buku, media mapan.
2. **Dilarang mengarang** judul buku, nama penulis, nomor halaman, URL, kutipan, atau statistik. Bila tidak menemukan sumbernya, katakan terus terang dan jangan memakai klaimnya sebagai fakta pasti.
3. **Tanpa alat pencarian**: beri label semua klaim "belum diverifikasi (dari pengetahuan model)", hindari angka presisi (pakai "sekitar", "kisaran"), dan minta pengguna memeriksa sumbernya sebelum video diproduksi.
4. **Sumber bertentangan**: sebutkan perbedaannya. Klaim yang diperdebatkan ditulis sebagai diperdebatkan, jangan disajikan sebagai fakta mutlak.
5. **Topik sensitif** (kesehatan, hukum, keuangan, politik): hindari klaim mutlak atau ajakan bertindak; sebut batas kepastian.

## Format Blueprint (Fase 1)
Empat pilar (lihat `SKILL.md`), dengan tambahan:
- **Data Spesifik**: tiap angka ditulis `angka, sumber (lembaga/penerbit, tahun), status` dengan status **Terverifikasi** atau **Perlu dicek**.
- **Sumber Referensi**: daftar sumber yang benar-benar ditemukan, dengan tautan bila ada.
- **Sengaja tidak dipakai**: klaim populer yang tidak bisa dibuktikan atau diperdebatkan, beserta alasannya singkat.

## Mode Kilat
Bahan dari pengguna dianggap sumber. Tetap lakukan cek cepat atas klaim kuncinya (angka, tanggal, nama). Bila ada yang janggal atau tidak cocok dengan sumber lain, tandai di "Klaim untuk dicek" setelah naskah. Jangan menambah fakta baru yang tidak ada di bahan pengguna tanpa memverifikasinya.
