# Faceless Documentary Scriptwriter (v2.0.0)

Paket **Single-Skill Plugin (Claude)** resmi untuk keahlian:
- **Skill ID**: `faceless-documentary-script`
- **Versi**: `v2.0.0`
- **Deskripsi**: Penulis naskah video dokumenter tanpa wajah gaya Intisari & Sudutpaham.

Arsip ini memiliki struktur plugin standar dengan direktori `skills/faceless-documentary-script/` dan berkas manifest provider yang valid.
