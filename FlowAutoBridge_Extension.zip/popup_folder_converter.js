// extension/popup_folder_converter.js
// Modul Mandiri Konversi Folder Proyek Lokal ke Draf CapCut Desktop (v2.7.0)

(function (global) {
  'use strict';

  let currentProjectBundle = null;

  /**
   * Mengurutkan daftar berkas gambar adegan berdasarkan nomor urut numerik
   */
  function sortSceneImageFiles(imageFiles) {
    return imageFiles.slice().sort((a, b) => {
      const getNum = (name) => {
        const m = name.match(/(\d+)/);
        return m ? parseInt(m[1], 10) : 9999;
      };
      return getNum(a.name) - getNum(b.name);
    });
  }

  /**
   * Memindai entri direktori dari FileSystemDirectoryHandle (File System Access API)
   * @param {FileSystemDirectoryHandle} dirHandle
   * @returns {Promise<Object>} Bundel proyek terstruktur
   */
  async function scanProjectFolderHandle(dirHandle) {
    if (!dirHandle) throw new Error('Handle folder tidak valid.');

    const folderName = dirHandle.name || 'Proyek_CapCut';
    let jsonFile = null;
    let audioFile = null;
    let coverFile = null;
    const imageFiles = [];

    for await (const entry of dirHandle.values()) {
      if (entry.kind === 'file') {
        const file = await entry.getFile();
        const lowerName = file.name.toLowerCase();

        // 1. Deteksi Storyboard JSON
        if (lowerName.endsWith('.json') && !lowerName.includes('meta')) {
          if (!jsonFile || lowerName.includes(folderName.toLowerCase())) {
            jsonFile = file;
          }
        }
        // 2. Deteksi Berkas Audio
        else if (lowerName.match(/\.(mp3|wav|m4a|ogg)$/i)) {
          if (!audioFile || lowerName.includes(folderName.toLowerCase())) {
            audioFile = file;
          }
        }
        // 3. Deteksi Cover Image
        else if (lowerName.startsWith('cover') || lowerName.includes('draft_cover')) {
          coverFile = file;
        }
        // 4. Deteksi Gambar Adegan
        else if (lowerName.match(/\.(png|jpg|jpeg|webp)$/i)) {
          imageFiles.push({ name: file.name, file });
        }
      }
    }

    return buildProjectBundleFromFiles(folderName, jsonFile, audioFile, coverFile, imageFiles);
  }

  /**
   * Memindai berkas dari fallback HTML5 FileList (webkitdirectory)
   * @param {FileList|Array<File>} files
   * @returns {Promise<Object>} Bundel proyek terstruktur
   */
  async function scanProjectFileList(files) {
    if (!files || files.length === 0) throw new Error('Tidak ada berkas yang dipilih.');

    let folderName = 'Proyek_CapCut';
    const firstRel = files[0].webkitRelativePath || '';
    if (firstRel.includes('/')) {
      folderName = firstRel.split('/')[0];
    }

    let jsonFile = null;
    let audioFile = null;
    let coverFile = null;
    const imageFiles = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const lowerName = file.name.toLowerCase();

      if (lowerName.endsWith('.json') && !lowerName.includes('meta')) {
        if (!jsonFile || lowerName.includes(folderName.toLowerCase())) jsonFile = file;
      } else if (lowerName.match(/\.(mp3|wav|m4a|ogg)$/i)) {
        if (!audioFile || lowerName.includes(folderName.toLowerCase())) audioFile = file;
      } else if (lowerName.startsWith('cover') || lowerName.includes('draft_cover')) {
        coverFile = file;
      } else if (lowerName.match(/\.(png|jpg|jpeg|webp)$/i)) {
        imageFiles.push({ name: file.name, file });
      }
    }

    return buildProjectBundleFromFiles(folderName, jsonFile, audioFile, coverFile, imageFiles);
  }

  /**
   * Menyusun objek bundel proyek terpadu dengan fallback adegan cerdas
   */
  async function buildProjectBundleFromFiles(folderName, jsonFile, audioFile, coverFile, rawImageFiles) {
    let parsedData = null;
    let projectTitle = folderName;
    let scenes = [];
    let aspectRatio = '9:16';

    // 1. Ekstraksi Data Naskah jika Storyboard JSON tersedia
    if (jsonFile) {
      try {
        const text = await jsonFile.text();
        parsedData = JSON.parse(text);
        projectTitle = parsedData.projectFolder || parsedData.title || folderName;
        aspectRatio = parsedData.aspectRatio || parsedData.aspect_ratio || '9:16';

        const rawScenes = Array.isArray(parsedData.scenes)
          ? parsedData.scenes
          : (Array.isArray(parsedData.adegan) ? parsedData.adegan : []);

        scenes = rawScenes.filter(sc => String(sc.id || '').toUpperCase() !== 'COVER');
      } catch (err) {
        console.warn('[PopupFolderConverter] Gagal parse JSON storyboard, membuat linimasa sintetis:', err);
      }
    }

    const sortedImages = sortSceneImageFiles(rawImageFiles);

    // 2. Jika berkas JSON tidak memiliki adegan, bangun linimasa sintetis dari gambar
    if (scenes.length === 0 && sortedImages.length > 0) {
      scenes = sortedImages.map((img, idx) => {
        const scNum = String(idx + 1).padStart(2, '0');
        const ext = img.name.split('.').pop() || 'png';
        return {
          id: `ADEGAN_${scNum}`,
          image_filename: img.name,
          image_ext: ext,
          duration: 3.5,
          narrative: `Adegan ${idx + 1}`
        };
      });
    } else if (scenes.length > 0 && sortedImages.length > 0) {
      // Selaraskan nama berkas gambar aktual dengan daftar adegan
      scenes.forEach((sc, idx) => {
        const matchedImg = sortedImages.find(img => {
          const baseName = img.name.replace(/\.[^/.]+$/, '').toLowerCase();
          const targetId = String(sc.id || '').toLowerCase();
          const numMatch = baseName.match(/(\d+)/);
          return baseName === targetId || (numMatch && parseInt(numMatch[1], 10) === idx + 1);
        });

        if (matchedImg) {
          sc.image_filename = matchedImg.name;
          sc.image_ext = matchedImg.name.split('.').pop() || 'png';
        } else if (sortedImages[idx]) {
          sc.image_filename = sortedImages[idx].name;
          sc.image_ext = sortedImages[idx].name.split('.').pop() || 'png';
        }
      });
    }

    // Jika coverFile tidak ada namun ada cover di dalam daftar gambar
    if (!coverFile) {
      const foundCover = rawImageFiles.find(img => img.name.toLowerCase().startsWith('cover'));
      if (foundCover) coverFile = foundCover.file;
    }

    // Siapkan daftar berkas gambar yang akan disalin (termasuk cover)
    const allImagesToCopy = sortedImages.slice();
    if (coverFile && !allImagesToCopy.some(img => img.name === coverFile.name)) {
      allImagesToCopy.push({ name: coverFile.name, file: coverFile });
    }

    return {
      folderName,
      title: projectTitle,
      projectFolder: folderName,
      jsonFile,
      audioFile,
      coverFile,
      scenes,
      aspectRatio,
      imageFiles: allImagesToCopy,
      totalImageCount: allImagesToCopy.length
    };
  }

  /**
   * Eksekusi konversi bundel proyek ke Draf CapCut Desktop
   * @param {Object} projectBundle
   * @param {Function} [statusCallback]
   * @returns {Promise<Object>}
   */
  async function executeFolderToCapCutConversion(projectBundle, statusCallback) {
    if (!projectBundle) throw new Error('Data bundel proyek belum siap.');
    if (!global.CapCutDraftWriter) throw new Error('Modul CapCutDraftWriter belum dimuat.');

    const log = (msg) => {
      if (typeof statusCallback === 'function') statusCallback(msg);
      console.log(`[PopupFolderConverter] ${msg}`);
    };

    log('Memeriksa direktori draf CapCut...');
    let capcutHandle = await global.CapCutDraftWriter.getStoredDirectoryHandle();
    if (capcutHandle) {
      const isGranted = await global.CapCutDraftWriter.verifyPermission(capcutHandle, true);
      if (!isGranted) {
        log('Meminta izin akses direktori CapCut...');
        capcutHandle = await global.CapCutDraftWriter.pairCapCutDirectory();
      }
    } else {
      log('Menghubungkan direktori draf CapCut (com.lveditor.draft)...');
      capcutHandle = await global.CapCutDraftWriter.pairCapCutDirectory();
    }

    if (!capcutHandle) {
      throw new Error('Direktori draf CapCut belum dipilih.');
    }

    log(`Menulis draf CapCut untuk '${projectBundle.title}'...`);
    const projectData = {
      title: projectBundle.title,
      projectFolder: projectBundle.folderName,
      scenes: projectBundle.scenes,
      aspectRatio: projectBundle.aspectRatio,
      audioFileName: projectBundle.audioFile ? projectBundle.audioFile.name : ''
    };

    // Jalankan perakitan draf CapCut mandiri dengan menyalin gambar adegan
    const result = await global.CapCutDraftWriter.writeCapCutDraft(
      capcutHandle,
      projectData,
      projectBundle.audioFile || null,
      projectBundle.coverFile || null,
      {
        imageFolderPath: 'DRAFT_DIR',
        imageFiles: projectBundle.imageFiles,
        audioFileName: projectBundle.audioFile ? projectBundle.audioFile.name : ''
      }
    );

    log('✓ Draf CapCut berhasil dibuat!');
    return result;
  }

  /**
   * Inisialisasi Event Listener dan Antarmuka Pengguna untuk Konverter Folder
   * @param {Object} uiElements
   */
  function initFolderConverterUI(uiElements) {
    const {
      btnSelectFolder,
      btnExecuteConvert,
      pathPreview,
      metaPreview,
      statusBar,
      statusText,
      fallbackPicker
    } = uiElements;

    if (!btnSelectFolder || !btnExecuteConvert) return;

    const setStatus = (msg, isVisible = true) => {
      if (!statusBar || !statusText) return;
      statusText.textContent = msg;
      statusBar.style.display = isVisible ? 'block' : 'none';
    };

    const updateBundlePreview = (bundle) => {
      currentProjectBundle = bundle;
      if (!bundle) {
        if (pathPreview) pathPreview.textContent = 'Belum ada folder proyek yang dipilih';
        if (metaPreview) metaPreview.style.display = 'none';
        btnExecuteConvert.disabled = true;
        return;
      }

      if (pathPreview) {
        pathPreview.textContent = bundle.folderName;
        pathPreview.style.color = '#38bdf8';
      }

      if (metaPreview) {
        const jsonInfo = bundle.jsonFile ? '✓ Naskah JSON' : '⚠️ Tanpa JSON';
        const audioInfo = bundle.audioFile ? `✓ Audio (${bundle.audioFile.name})` : '⚠️ Tanpa Audio';
        const imgInfo = `${bundle.totalImageCount} Gambar Adegan`;
        metaPreview.textContent = `${bundle.title} • ${jsonInfo} • ${audioInfo} • ${imgInfo}`;
        metaPreview.style.display = 'block';
      }

      // Aktifkan tombol konversi jika ada minimal 1 gambar atau 1 berkas audio
      btnExecuteConvert.disabled = !(bundle.totalImageCount > 0 || bundle.audioFile);
    };

    // 1. Handler Klik Tombol Pilih Folder Proyek
    btnSelectFolder.addEventListener('click', async () => {
      try {
        if (typeof window.showDirectoryPicker === 'function') {
          setStatus('Membuka penjelajah folder...');
          const dirHandle = await window.showDirectoryPicker({ mode: 'read' });
          if (!dirHandle) return;

          setStatus(`Memindai aset di folder '${dirHandle.name}'...`);
          const bundle = await scanProjectFolderHandle(dirHandle);
          updateBundlePreview(bundle);
          setStatus(`✓ Berhasil memuat ${bundle.totalImageCount} gambar & aset.`);
        } else if (fallbackPicker) {
          fallbackPicker.click();
        }
      } catch (err) {
        if (err.name !== 'AbortError') {
          console.error('[PopupFolderConverter] Error memilih folder:', err);
          if (global.PopupModal) {
            global.PopupModal.showAlert({
              title: 'Gagal Membaca Folder',
              message: `Tidak dapat memindai folder proyek: ${err.message || err}`
            });
          }
        }
        setStatus('', false);
      }
    });

    // 2. Handler Fallback File Input jika showDirectoryPicker tidak didukung
    if (fallbackPicker) {
      fallbackPicker.addEventListener('change', async (e) => {
        try {
          const files = e.target.files;
          if (!files || files.length === 0) return;

          setStatus('Memindai berkas folder terpilih...');
          const bundle = await scanProjectFileList(files);
          updateBundlePreview(bundle);
          setStatus(`✓ Berhasil memuat ${bundle.totalImageCount} gambar & aset.`);
        } catch (err) {
          console.error('[PopupFolderConverter] Error fallback folder:', err);
          setStatus('', false);
        }
      });
    }

    // 3. Handler Klik Tombol Eksekusi Konversi ke Draf CapCut
    btnExecuteConvert.addEventListener('click', async () => {
      if (!currentProjectBundle) return;

      try {
        btnExecuteConvert.disabled = true;
        btnSelectFolder.disabled = true;
        setStatus('Memulai perakitan draf CapCut...');

        const result = await executeFolderToCapCutConversion(currentProjectBundle, (msg) => {
          setStatus(msg);
        });

        setStatus('✓ Konversi selesai 100%!');

        if (global.PopupModal) {
          await global.PopupModal.showSuccess({
            title: 'Draf CapCut Berhasil Dibuat!',
            projectName: result.projectName || currentProjectBundle.title,
            message: `Folder proyek '${currentProjectBundle.title}' berhasil dikonversi menjadi Draf CapCut Desktop dengan linimasa video, narasi, dan trek suara lengkap.`
          });
        }
      } catch (err) {
        if (err.name !== 'AbortError') {
          console.error('[PopupFolderConverter] Error eksekusi konversi:', err);
          if (global.PopupModal) {
            global.PopupModal.showAlert({
              title: 'Konversi Draf Gagal',
              message: err.message || 'Terjadi kesalahan saat menulis draf CapCut.'
            });
          }
        }
        setStatus('⚠️ Proses konversi dibatalkan atau terjadi kesalahan.');
      } finally {
        btnExecuteConvert.disabled = false;
        btnSelectFolder.disabled = false;
      }
    });
  }

  // Ekspor Modul
  global.PopupFolderConverter = {
    scanProjectFolderEntries: scanProjectFolderHandle,
    scanProjectFolderHandle,
    scanProjectFileList,
    parseProjectFolderFiles: buildProjectBundleFromFiles,
    executeFolderToCapCutConversion,
    initFolderConverterUI
  };

})(typeof window !== 'undefined' ? window : this);
