/**
 * content_flow_scene_state.js (SRS-111 / FR-01 & FR-02)
 * Pengelola State Tunggal (Single Source of Truth) Siklus Hidup Adegan di Content Script.
 * Menyimpan status ke chrome.storage.local dengan kunci 'sceneRenderStates'.
 * State yang didukung: 'queued' | 'submitting' | 'rendering' | 'done' | 'held' | 'failed'
 */
(function() {
  'use strict';

  const STORAGE_KEY = 'sceneRenderStates';
  const VALID_STATES = new Set(['queued', 'submitting', 'rendering', 'done', 'held', 'failed']);

  function getChromeStorage() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
    return null;
  }

  /**
   * Mengambil seluruh state adegan yang tersimpan.
   */
  async function getAllStates() {
    const storage = getChromeStorage();
    if (!storage) return {};
    return new Promise((resolve) => {
      storage.get([STORAGE_KEY], (res) => {
        resolve(res && res[STORAGE_KEY] ? res[STORAGE_KEY] : {});
      });
    });
  }

  /**
   * Menginisialisasi antrean adegan baru menjadi state 'queued' bernomor urut.
   * @param {Array<Object>} scenes Daftar objek adegan
   */
  async function initQueueStates(scenes) {
    if (!Array.isArray(scenes) || scenes.length === 0) return {};
    const storage = getChromeStorage();
    if (!storage) return {};

    const states = {};
    const now = Date.now();

    scenes.forEach((sc, idx) => {
      if (!sc) return;
      const scId = String(sc.id || (idx === 0 ? 'COVER' : `ADEGAN_${String(idx).padStart(2, '0')}`)).trim();
      states[scId] = {
        state: 'queued',
        pos: idx + 1,
        since: now,
        attempt: 0,
        reason: ''
      };
    });

    return new Promise((resolve) => {
      storage.set({ [STORAGE_KEY]: states }, () => resolve(states));
    });
  }

  /**
   * Memperbarui status adegan secara aman dengan validasi transisi.
   * @param {string} sceneId ID adegan (misal: 'COVER', 'ADEGAN_01')
   * @param {string} state State tujuan
   * @param {string} reason Alasan status (opsional)
   * @param {number|null} attempt Nomor percobaan (opsional)
   */
  async function setSceneState(sceneId, state, reason = '', attempt = null) {
    if (!sceneId || !VALID_STATES.has(state)) return null;
    const storage = getChromeStorage();
    if (!storage) return null;

    const current = await getAllStates();
    const cleanId = String(sceneId).trim();
    const prev = current[cleanId] || { pos: 1, attempt: 0 };

    // Guard: Adegan yang sudah 'done' tidak boleh tertimpa kembali ke 'queued'
    if (prev.state === 'done' && state === 'queued') {
      return current;
    }

    const updatedEntry = {
      state: state,
      pos: prev.pos || 1,
      since: Date.now(),
      attempt: attempt !== null ? attempt : (prev.attempt || 0),
      reason: reason || prev.reason || ''
    };

    current[cleanId] = updatedEntry;

    return new Promise((resolve) => {
      storage.set({ [STORAGE_KEY]: current }, () => resolve(current));
    });
  }

  /**
   * Menghapus seluruh state tersimpan (saat reset antrean).
   */
  async function clearAllStates() {
    const storage = getChromeStorage();
    if (!storage) return;
    return new Promise((resolve) => {
      storage.remove([STORAGE_KEY], () => resolve());
    });
  }

  const api = {
    getAllStates,
    initQueueStates,
    setSceneState,
    clearAllStates,
    VALID_STATES
  };

  if (typeof window !== 'undefined') {
    window.FlowSceneState = api;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
