// ============================================================
// FlowAutoBridge — content_chatgpt.js
// Skrip konten khusus antarmuka ChatGPT (chatgpt.com / chat.openai.com)
// Mengintegrasikan ekstraksi Storyboard JSON dan Floating Action Button (FAB).
// ============================================================

(function() {
  const POPOVER_ID = 'fab-chatgpt-popover';
  const FAB_ID = 'fab-chatgpt-button';

  /**
   * Memeriksa apakah konteks ekstensi masih hidup (mencegah galat extension context invalidated)
   */
  function isExtensionContextAlive() {
    try {
      return Boolean(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  /**
   * Membuat 4 karakter acak untuk akhiran berkas JSON
   */
  function generateRandomHash4() {
    return Math.random().toString(36).substring(2, 6);
  }

  /**
   * Membatasi judul maksimal 4 kata
   */
  function limitTitleFourWords(rawTitle) {
    if (!rawTitle) return "storyboard";
    let clean = rawTitle.replace(/\(?part\s*\d+\)?/gi, '').replace(/[^\w\s]+/g, ' ').trim();
    let words = clean.split(/\s+/).filter(Boolean);
    if (words.length > 4) {
      const babMatch = clean.match(/\b(bab\s*\d+)\b/i);
      if (babMatch) {
        const babWords = babMatch[1].split(/\s+/);
        const otherWords = clean.replace(new RegExp(`\\b${babMatch[1]}\\b`, 'i'), '').trim().split(/\s+/).filter(Boolean);
        const remainingSlots = Math.max(1, 4 - babWords.length);
        words = [...otherWords.slice(0, remainingSlots), ...babWords];
      } else {
        words = words.slice(0, 4);
      }
    }
    return words.join(" ").trim() || "storyboard";
  }

  /**
   * Fallback unduhan via DOM link jika service worker tidak merespons
   */
  function fallbackDownloadViaDom(data, filename) {
    try {
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 500);
    } catch (e) {
      console.error('[FlowAutoBridge-ChatGPT] Fallback download gagal:', e);
    }
  }

  /**
   * Memicu pengunduhan berkas JSON storyboard
   */
  function triggerJsonDownload(data, filename) {
    if (isExtensionContextAlive()) {
      try {
        chrome.runtime.sendMessage({
          action: 'download_storyboard',
          data: data,
          filename: filename
        }, (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            fallbackDownloadViaDom(data, filename);
          }
        });
        return;
      } catch (_) {}
    }
    fallbackDownloadViaDom(data, filename);
  }

  /**
   * Mengambil semua elemen pesan asisten di DOM ChatGPT
   */
  function getAllAssistantMessages() {
    const selectors = [
      'article[data-testid^="conversation-turn"]',
      'div[data-message-author-role="assistant"]',
      '.agent-turn',
      'div[class*="agent-turn"]'
    ];

    for (const selector of selectors) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        return Array.from(elements);
      }
    }
    return [document.body];
  }

  /**
   * Eksekusi ekstraksi dari ChatGPT
   */
  function executeExtraction(onSuccess, onError) {
    const extractor = window.StoryboardJsonExtractor;
    if (!extractor) {
      if (onError) onError('Pustaka StoryboardJsonExtractor belum siap.');
      return;
    }

    const messages = getAllAssistantMessages();
    let foundStoryboard = null;

    // Cari dari pesan asisten paling terakhir ke atas
    for (let i = messages.length - 1; i >= 0; i--) {
      foundStoryboard = extractor.findStoryboardJsonInContainer(messages[i]);
      if (foundStoryboard && foundStoryboard.scenes && foundStoryboard.scenes.length > 0) {
        break;
      }
    }

    // Jika belum ditemukan di pesan terpisah, cari di seluruh body
    if (!foundStoryboard) {
      foundStoryboard = extractor.findStoryboardJsonInContainer(document.body);
    }

    if (!foundStoryboard || !foundStoryboard.scenes || foundStoryboard.scenes.length === 0) {
      if (onError) onError('Tidak ditemukan blok kode Storyboard JSON pada percakapan ini.');
      return;
    }

    // Simpan ke storage antrean
    if (isExtensionContextAlive()) {
      try {
        chrome.storage.local.set({
          storyboardQueue: foundStoryboard.scenes,
          activeIndex: 0
        });
      } catch (_) {}
    }

    // Proses pengunduhan berkas (Full atau Chunk 10)
    const proceedDownload = (splitMode) => {
      const scenes = foundStoryboard.scenes;
      const CHUNK_SIZE = 10;
      const baseFourWords = limitTitleFourWords(foundStoryboard.title);
      const safeTitle = baseFourWords
        .replace(/[^a-zA-Z0-9\s\-]+/g, '')
        .replace(/[\s\-]+/g, '_')
        .toLowerCase() || 'storyboard';

      const filenames = [];

      if (splitMode === 'full_json' || scenes.length <= CHUNK_SIZE) {
        const randHash = generateRandomHash4();
        const filename = `${safeTitle}_${randHash}.json`;
        triggerJsonDownload(foundStoryboard, filename);
        filenames.push(filename);
        saveFilenameHistory(filename);
      } else {
        const totalParts = Math.ceil(scenes.length / CHUNK_SIZE);
        for (let i = 0; i < scenes.length; i += CHUNK_SIZE) {
          const partNum = Math.floor(i / CHUNK_SIZE) + 1;
          const randHash = generateRandomHash4();
          const chunkScenes = scenes.slice(i, i + CHUNK_SIZE);
          const chunkData = {
            ...foundStoryboard,
            title: `${foundStoryboard.title} (Part ${partNum})`,
            scenes: chunkScenes,
            part: partNum,
            total_parts: totalParts
          };
          const chunkFilename = `${safeTitle}_part${partNum}_${randHash}.json`;
          triggerJsonDownload(chunkData, chunkFilename);
          filenames.push(chunkFilename);
          saveFilenameHistory(chunkFilename);
        }
      }

      if (onSuccess) {
        onSuccess({
          count: scenes.length,
          title: foundStoryboard.title,
          filenames: filenames,
          message: `Berhasil mengunduh ${filenames.length} file JSON (${scenes.length} adegan)!`
        });
      }
    };

    if (isExtensionContextAlive()) {
      try {
        chrome.storage.local.get(['splitMode'], (data) => {
          proceedDownload((data && data.splitMode) || 'full_json');
        });
        return;
      } catch (_) {}
    }

    proceedDownload('full_json');
  }

  /**
   * Menyimpan nama berkas ke riwayat unduhan
   */
  function saveFilenameHistory(filename) {
    if (!isExtensionContextAlive()) return;
    try {
      chrome.storage.local.get(['lastDownloadedJsonList'], (res) => {
        let list = (res && res.lastDownloadedJsonList) || [];
        list = list.filter(item => item !== filename);
        list.unshift(filename);
        if (list.length > 5) list = list.slice(0, 5);
        chrome.storage.local.set({ lastDownloadedJsonList: list });
      });
    } catch (_) {}
  }

  /**
   * Injeksi Floating Action Button (FAB) ke halaman ChatGPT
   */
  function injectChatGptFloatingWidget() {
    if (document.getElementById(FAB_ID)) return;

    // Inject Stylesheet
    const styleEl = document.createElement('style');
    styleEl.textContent = `
      #${FAB_ID} {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
        border: 2px solid rgba(255, 255, 255, 0.2);
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 999999;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      }
      #${FAB_ID}:hover {
        transform: scale(1.08);
        box-shadow: 0 6px 25px rgba(16, 185, 129, 0.6);
      }
      #${POPOVER_ID} {
        position: fixed;
        bottom: 84px;
        right: 24px;
        width: 290px;
        background: #0f172a;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        box-shadow: 0 10px 35px rgba(0, 0, 0, 0.5);
        color: #f8fafc;
        font-family: system-ui, -apple-system, sans-serif;
        padding: 14px;
        z-index: 999999;
        display: none;
        flex-direction: column;
        gap: 10px;
        box-sizing: border-box;
      }
      #${POPOVER_ID}.cg-open {
        display: flex;
        animation: cgPopIn 0.2s ease-out;
      }
      @keyframes cgPopIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .cg-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        border: none;
        border-radius: 10px;
        padding: 9px 12px;
        font-weight: 600;
        font-size: 12px;
        cursor: pointer;
        transition: all 0.15s ease;
      }
      .cg-btn-primary {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: #ffffff;
      }
      .cg-btn-primary:hover {
        opacity: 0.95;
        transform: translateY(-1px);
      }
      .cg-btn-secondary {
        background: #1e293b;
        color: #cbd5e1;
        border: 1px solid rgba(255, 255, 255, 0.08);
      }
      .cg-btn-secondary:hover {
        background: #334155;
        color: #ffffff;
      }
    `;
    document.head.appendChild(styleEl);

    // FAB Element
    const fab = document.createElement('button');
    fab.id = FAB_ID;
    fab.title = 'FlowAutoBridge: Ekstrak Storyboard JSON';
    fab.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
    `;

    // Popover Panel
    const popover = document.createElement('div');
    popover.id = POPOVER_ID;
    popover.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 8px;">
        <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; font-size: 13px; color: #34d399;">
          <span>⚡</span>
          <span>FlowAutoBridge ChatGPT</span>
        </div>
        <button id="cg-close-x" style="background: none; border: none; color: #94a3b8; font-size: 16px; cursor: pointer; padding: 0 4px;">&times;</button>
      </div>

      <button id="cg-btn-extract" class="cg-btn cg-btn-primary">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <span>Ekstrak & Simpan JSON</span>
      </button>

      <button id="cg-btn-toggle-mode" class="cg-btn cg-btn-secondary">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>
        <span id="cg-mode-label">Mode: Full 1 File JSON</span>
      </button>

      <div id="cg-toast" style="font-size: 11px; padding: 6px 8px; border-radius: 6px; display: none; line-height: 1.4;"></div>
    `;

    document.body.appendChild(fab);
    document.body.appendChild(popover);

    // Event Handlers
    const btnExtract = popover.querySelector('#cg-btn-extract');
    const btnToggle = popover.querySelector('#cg-btn-toggle-mode');
    const modeLabel = popover.querySelector('#cg-mode-label');
    const closeX = popover.querySelector('#cg-close-x');
    const toast = popover.querySelector('#cg-toast');

    function showToast(msg, isSuccess = true) {
      toast.textContent = msg;
      toast.style.display = 'block';
      toast.style.background = isSuccess ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)';
      toast.style.color = isSuccess ? '#34d399' : '#f87171';
      toast.style.border = isSuccess ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid rgba(239, 68, 68, 0.3)';
      setTimeout(() => {
        toast.style.display = 'none';
      }, 4000);
    }

    fab.addEventListener('click', (e) => {
      e.stopPropagation();
      popover.classList.toggle('cg-open');
    });

    closeX.addEventListener('click', (e) => {
      e.stopPropagation();
      popover.classList.remove('cg-open');
    });

    document.addEventListener('click', (e) => {
      if (!popover.contains(e.target) && e.target !== fab) {
        popover.classList.remove('cg-open');
      }
    });

    // Update Label Mode dari storage
    if (isExtensionContextAlive()) {
      try {
        chrome.storage.local.get(['splitMode'], (res) => {
          const mode = (res && res.splitMode) || 'full_json';
          modeLabel.textContent = mode === 'full_json' ? 'Mode: Full 1 File JSON' : 'Mode: Pecah 10 Adegan';
        });
      } catch (_) {}
    }

    btnToggle.addEventListener('click', () => {
      if (!isExtensionContextAlive()) return;
      try {
        chrome.storage.local.get(['splitMode'], (res) => {
          const current = (res && res.splitMode) || 'full_json';
          const next = current === 'full_json' ? 'split_10' : 'full_json';
          chrome.storage.local.set({ splitMode: next }, () => {
            modeLabel.textContent = next === 'full_json' ? 'Mode: Full 1 File JSON' : 'Mode: Pecah 10 Adegan';
            showToast(next === 'full_json' ? 'Mode: 1 File JSON Master' : 'Mode: Pecah Maks 10 Adegan/Part');
          });
        });
      } catch (_) {}
    });

    btnExtract.addEventListener('click', () => {
      const origText = btnExtract.innerHTML;
      btnExtract.innerHTML = '<span>⏳ Mengekstrak...</span>';
      btnExtract.style.pointerEvents = 'none';

      executeExtraction(
        (res) => {
          btnExtract.innerHTML = origText;
          btnExtract.style.pointerEvents = 'auto';
          showToast(res.message, true);
        },
        (errMsg) => {
          btnExtract.innerHTML = origText;
          btnExtract.style.pointerEvents = 'auto';
          showToast(errMsg, false);
        }
      );
    });
  }

  // Listener pesan dari Popup Extension
  if (isExtensionContextAlive()) {
    try {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'extract_table' || request.action === 'extract_storyboard_json') {
          executeExtraction(
            (res) => {
              sendResponse({
                success: true,
                count: res.count,
                title: res.title,
                filenames: res.filenames
              });
            },
            (errMsg) => {
              sendResponse({ success: false, error: errMsg });
            }
          );
          return true; // Asinkron
        }
      });
    } catch (_) {}
  }

  // Inisialisasi saat DOM siap
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectChatGptFloatingWidget);
  } else {
    injectChatGptFloatingWidget();
  }
})();
