// extension/content_flow.js - Client Swarm Google Flow
// FR-ISO-003: Proteksi Isolasi Top-Frame (Abaikan sub-iframe agar tidak memicu duplikasi worker atau premature unregister)
const isTopFrame = (typeof window !== 'undefined' && window === window.top);

let activeQueue = [], currentIndex = -1, observer = null;
let isSwarmActive = false, isLocalQueueActive = false, isLocalQueueProcessing = false;
let sessionClaimedImages = new Set();
let currentSwarmTask = null, heartbeatInterval = null;
let lastExecutedBroadcastId = isTopFrame ? (sessionStorage.getItem('flow_last_broadcast_id') || "") : "";

const DESKTOP_BRIDGE_URL = "http://127.0.0.1:8000/api/v1/bridge";

// Generate / restore persistent worker ID per tab session
let workerId = isTopFrame ? sessionStorage.getItem('flow_bridge_worker_id') : null;
if (isTopFrame && !workerId) {
  const randTag = Math.random().toString(36).substring(2, 6).toUpperCase();
  workerId = `WORKER-${randTag}`;
  sessionStorage.setItem('flow_bridge_worker_id', workerId);
}

function log(msg, level = 'INFO') {
  if (!isTopFrame) return;
  console.log(`[FlowAutoBridge:${workerId}] ${msg}`);
  try {
    fetch(`${DESKTOP_BRIDGE_URL}/log`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ worker_id: workerId, message: msg, level: level })
    }).catch(() => {});
  } catch (e) {}
}

// ── 1. MODUL ROBOTIK INTERAKSI DOM GOOGLE FLOW (Didelegasikan ke content_flow_dom.js) ──
// Fungsi-fungsi pembantu DOM: querySelectorAllDeep, focusEditor, getPromptText,
// fillPromptInput, findPromptTextarea, findGenerateButton, triggerGenerate, dll.
// dimuat secara modular via extension/content_flow_dom.js.

// ── 2. MODUL SINKRONISASI STATE (CLEAN DOM — TANPA OVERLAY MELAYANG) ──

function injectFlowStatusOverlay(statusText, isRunning = true, isSwarm = false, isStandby = false) {
  if (typeof removeLegacyOverlay === 'function') {
    removeLegacyOverlay();
  }
  if (typeof syncFlowState === 'function') {
    return syncFlowState(statusText, isRunning, isSwarm, isStandby, { workerId });
  }
}

async function fetchImageAsBase64(url) {
  const res = await fetch(url);
  const blob = await res.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// ── 3. SWARM CLUSTER WORKER PROTOCOL & LEASE HARDENING ──

async function checkDesktopBridgeOnline() {
  try {
    const res = await fetch(`${DESKTOP_BRIDGE_URL}/cluster-status`, { method: 'GET' });
    return res.ok;
  } catch (e) {
    return false;
  }
}

async function registerSwarmWorker() {
  try {
    const res = await fetch(`${DESKTOP_BRIDGE_URL}/register-worker`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        worker_id: workerId,
        profile_label: document.title || "Google Flow Tab",
        tab_url: window.location.href
      })
    });
    return res.ok;
  } catch (e) {
    return false;
  }
}

function startHeartbeatLoop() {
  if (heartbeatInterval) clearInterval(heartbeatInterval);
  heartbeatInterval = setInterval(async () => {
    try {
      const res = await fetch(`${DESKTOP_BRIDGE_URL}/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          worker_id: workerId,
          current_scene_id: currentSwarmTask ? currentSwarmTask.scene_id : null,
          claim_token: currentSwarmTask ? currentSwarmTask.claim_token : null
        })
      });
      if (res.ok) {
        const data = await res.json();
        const cmd = data.broadcast_command;
        const cmdId = data.broadcast_command_id;

        if (cmd && cmdId && cmdId !== lastExecutedBroadcastId) {
          lastExecutedBroadcastId = cmdId;
          try { sessionStorage.setItem('flow_last_broadcast_id', cmdId); } catch (e) {}
          log(`📢 Menerima sinyal siaran Desktop: ${cmd} (ID: ${cmdId})`);

          if (cmd === 'RELOAD') {
            injectFlowStatusOverlay('🔄 Perintah RELOAD diterima dari Desktop. Merefresh tab...', true, true);
            setTimeout(() => { window.location.reload(); }, 1000);
          } else if (cmd === 'STOP') {
            isSwarmActive = false;
            currentSwarmTask = null;
            if (observer) { try { observer.disconnect(); } catch (e) {} observer = null; }
            injectFlowStatusOverlay('🛑 Render Dihentikan oleh Pengguna dari Desktop.', false, false);
            log('🛑 Render dihentikan seketika oleh pengguna dari Desktop.');
          }
        }
      }
    } catch (e) {}
  }, 3500);
}

async function startSwarmWorkerLoop() {
  if (!isSwarmActive) return;

  injectFlowStatusOverlay('Meminta tugas berikutnya dari Desktop...', true, true);

  try {
    const claimRes = await fetch(`${DESKTOP_BRIDGE_URL}/claim-task`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ worker_id: workerId, lease_seconds: 90.0 })
    });

    if (!claimRes.ok) {
      injectFlowStatusOverlay('Menunggu antrean siap...', false, true);
      setTimeout(startSwarmWorkerLoop, 4000);
      return;
    }

    const claimData = await claimRes.json();
    if (claimData.status === "stopped") {
      isSwarmActive = false;
      currentSwarmTask = null;
      injectFlowStatusOverlay('🛑 Render dihentikan oleh pengguna.', false, false);
      return;
    }

    if (!claimData.has_task || !claimData.task) {
      injectFlowStatusOverlay('Tidak ada tugas pending. Standby...', true, true, true);
      currentSwarmTask = null;
      setTimeout(startSwarmWorkerLoop, 5000);
      return;
    }

    currentSwarmTask = claimData.task;
    const task = currentSwarmTask;
    log(`Mengklaim tugas: ${task.scene_id} (#${task.scene_index})`);
    injectFlowStatusOverlay(`1/4: Mengklaim ${task.scene_id} (#${task.scene_index})...`, true, true);

    // ── PRE-FLIGHT CHECK: Cek apakah hasil render untuk prompt ini sudah ada di galeri kanvas (v2.7.4) ──
    const expectedPrompt = task.prompt || task.image_prompt || task.prompt_flow || '';
    const taskSceneIdx = typeof task.scene_index === 'number' ? task.scene_index : 0;
    if (typeof inspectCanvasForPrompt === 'function') {
      const preFlight = await inspectCanvasForPrompt(expectedPrompt, task.aspect_ratio || '9:16', taskSceneIdx, sessionClaimedImages);
      if (!isSwarmActive || currentSwarmTask !== task) return;
      if (preFlight.status === 'completed' && preFlight.imgElement) {
        if (preFlight.imgElement.src) sessionClaimedImages.add(preFlight.imgElement.src);
        log(`✓ [Pre-Flight] Ditemukan hasil render sebelumnya yang cocok untuk ${task.scene_id}! Mengunggah langsung tanpa render ulang...`);
        injectFlowStatusOverlay(`✓ Mengambil hasil ${task.scene_id} dari kanvas...`, true, true);
        const ok = await uploadSwarmImageElement(preFlight.imgElement, task.scene_id, task);
        if (!ok) {
          await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ worker_id: workerId, scene_id: task.scene_id, reason: 'Asset upload failed' })
          });
        }
        setTimeout(startSwarmWorkerLoop, ok ? 2500 : 4000);
        return;
      } else if (preFlight.status === 'in_progress') {
        log(`⏳ [Pre-Flight] Terdeteksi kartu untuk ${task.scene_id} sedang dalam proses render. Menghubungkan ke monitor...`);
        injectFlowStatusOverlay(`⏳ Terdeteksi proses render ${task.scene_id}. Menunggu selesai...`, true, true);
        await monitorAndSubmitSwarmImage(task.scene_id, task);
        return;
      }
    }

    if (typeof dismissAnyOpenFlowViewer === 'function') dismissAnyOpenFlowViewer();
    let textarea = null;
    for (let attempt = 0; attempt < 10; attempt++) {
      textarea = findPromptTextarea();
      if (textarea) break;
      await new Promise(r => setTimeout(r, 500));
    }

    if (!textarea) {
      log('ERROR: Input prompt Google Flow tidak ditemukan!');
      injectFlowStatusOverlay(`⚠️ Input prompt tidak terdeteksi (${task.scene_id})`, false, true);
      await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ worker_id: workerId, scene_id: task.scene_id, reason: 'Textarea not found' })
      });
      setTimeout(startSwarmWorkerLoop, 4000);
      return;
    }

    injectFlowStatusOverlay(`2/4: Mengetik prompt ${task.scene_id}...`, true, true);
    fillPromptInput(textarea, task.prompt);
    await new Promise(r => setTimeout(r, 1200));

    let generateBtn = null;
    for (let attempt = 0; attempt < 6; attempt++) {
      generateBtn = findGenerateButton(textarea);
      if (generateBtn) break;
      await new Promise(r => setTimeout(r, 400));
    }

    injectFlowStatusOverlay(`3/4: Mengirim generate ${task.scene_id}...`, true, true);
    const isSubmitted = await triggerGenerate(textarea, generateBtn);
    if (!isSubmitted) {
      log(`⚠️ Submit gagal untuk ${task.scene_id}. Membersihkan input & melepaskan tugas...`, 'WARN');
      clearPromptInput(textarea);
      injectFlowStatusOverlay(`⚠️ Submit gagal di Flow (${task.scene_id}). Mengulang...`, false, true);
      await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ worker_id: workerId, scene_id: task.scene_id, reason: 'Submit trigger failed' })
      });
      setTimeout(startSwarmWorkerLoop, 3500);
      return;
    }
    log(`Instruksi render dikirim untuk ${task.scene_id}. Menunggu hasil...`);

    await monitorAndSubmitSwarmImage(task.scene_id, task);

  } catch (err) {
    log(`Error swarm worker loop: ${err}`);
    setTimeout(startSwarmWorkerLoop, 5000);
  }
}

// ── 3b. AUTO-DOWNLOAD GAMBAR KE FOLDER INTISARISHORTMOVIE (SRS-FAB-055 & v2.7.1) ──
async function triggerAutoDownloadFlowImage(imgElement, sceneId) {
  if (!imgElement) return false;
  try {
    const src = imgElement.src || '';
    if (!src) return false;

    // FR-WHT-002: Tolak unduhan jika elemen belum selesai dimuat atau masih skeleton loader
    if (imgElement.complete !== true || (imgElement.naturalWidth && imgElement.naturalWidth < 100)) {
      log(`⏳ [Anti-White Guard] Gambar ${sceneId} belum selesai dimuat di DOM. Menunda unduhan...`, 'WARN');
      return false;
    }

    let dataUrl = '';
    try {
      const canvas = document.createElement('canvas');
      const w = imgElement.naturalWidth || 1280;
      const h = imgElement.naturalHeight || 720;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(imgElement, 0, 0, w, h);

      // FR-WHT-004: Gatekeeper Sampling Piksel Putih
      if (typeof isCanvasBitmapBlankWhite === 'function' && isCanvasBitmapBlankWhite(canvas, ctx, w, h)) {
        log(`⚠️ [Anti-White Guard] Gambar ${sceneId} terdeteksi masih berupa kanvas putih polos / skeleton. Menunda unduhan...`, 'WARN');
        return false;
      }

      dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    } catch (_) {
      try {
        const resp = await fetch(src);
        const blob = await resp.blob();
        const bmp = await createImageBitmap(blob);
        const canvas = document.createElement('canvas');
        canvas.width = bmp.width;
        canvas.height = bmp.height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, bmp.width, bmp.height);
        ctx.drawImage(bmp, 0, 0);

        if (typeof isCanvasBitmapBlankWhite === 'function' && isCanvasBitmapBlankWhite(canvas, ctx, bmp.width, bmp.height)) {
          log(`⚠️ [Anti-White Guard] Bitmap ${sceneId} terdeteksi putih polos. Menunda unduhan...`, 'WARN');
          return false;
        }

        dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      } catch (_) {
        dataUrl = src;
      }
    }

    chrome.storage.local.get(['activeProjectFolder'], (res) => {
      const projFolder = res.activeProjectFolder || '';
      chrome.runtime.sendMessage({
        action: 'fab_download_flow_image',
        imageUrl: dataUrl,
        filename: `${sceneId}.jpg`,
        projectFolder: projFolder,
        subfolder: 'intisariShortMovie'
      }, () => {
        const _ignored = chrome.runtime.lastError;
        const targetPath = projFolder ? `Downloads/intisariShortMovie/${projFolder}/` : 'Downloads/intisariShortMovie/';
        log(`✓ [Auto-Download] ${sceneId}.jpg -> ${targetPath}`);
      });
    });
    return true;
  } catch (e) {
    log(`Peringatan auto-download: ${e.message || e}`, 'WARN');
    return false;
  }
}

// ── 4. VALIDASI SEMANTIK PROMPT & PENGAMBILAN ASET PRESISI ──
// Catatan: Fungsi evaluasi semantik DOM (extractUniqueKeywords, getCardSemanticText,
// isImageMatchingPrompt, scanFailedCards) dimuat dari content_flow_evaluator.js

async function uploadSwarmImageElement(imgElement, sceneId, task) {
  if (!imgElement || !imgElement.src) return false;
  if (imgElement.src) sessionClaimedImages.add(imgElement.src);
  triggerAutoDownloadFlowImage(imgElement, sceneId);
  const imageUrl = imgElement.src;
  const cardText = typeof getCardSemanticText === 'function' ? getCardSemanticText(imgElement) : '';
  log(`✓ Gambar ${sceneId} terverifikasi valid! (Preview kartu: "${cardText.substring(0, 60)}...")`);
  injectFlowStatusOverlay(`Mengunggah hasil ${sceneId} ke Desktop...`, true, true);

  try {
    const b64 = await fetchImageAsBase64(imageUrl);
    const submitRes = await fetch(`${DESKTOP_BRIDGE_URL}/submit-asset`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        worker_id: workerId,
        scene_id: sceneId,
        image_base64: b64,
        format: 'png',
        claim_token: task && task.claim_token ? task.claim_token : null
      })
    });

    if (submitRes.ok) {
      sessionStorage.removeItem('flow_unusual_retry_' + sceneId);
      log(`✓ Sukses mengirim ${sceneId} ke Desktop!`);
      injectFlowStatusOverlay(`✓ ${sceneId} tersimpan! Menuju tugas berikutnya...`, true, true);
      currentSwarmTask = null;
      return true;
    } else {
      log(`Gagal submit asset ${sceneId}`);
      return false;
    }
  } catch (err) {
    log(`Error saat fetch/submit gambar: ${err}`);
    return false;
  }
}

async function monitorAndSubmitSwarmImage(sceneId, task = null) {
  const initialSrcs = new Set(
    Array.from(document.querySelectorAll('img')).map(i => i.src).filter(s => !!s)
  );
  const initialFailed = scanFailedCards();
  const expectedPrompt = task ? (task.prompt || task.image_prompt || task.prompt_flow || '') : '';
  const keywords = extractUniqueKeywords(expectedPrompt);
  log(`Menunggu gambar untuk ${sceneId}. Kata kunci subjek: [${keywords.slice(0, 5).join(', ')}]`);

  let attempts = 0;
  const maxAttempts = 60; // 120 detik timeout
  let checking = false;

  const checkInterval = setInterval(async () => {
    if (checking) return;
    if (!isSwarmActive || currentSwarmTask !== task) {
      clearInterval(checkInterval);
      return;
    }
    checking = true;
    try {
      attempts++;
      injectFlowStatusOverlay(`4/4: Menunggu render ${sceneId} (${attempts * 2}s/120s)...`, true, true);

      if (attempts >= 2) {
        const currentFailed = scanFailedCards();

        // 1. Deteksi Kartu Gagal Kebijakan Baru (Safety Policy Violation)
        if (currentFailed.policyCount > initialFailed.policyCount) {
          clearInterval(checkInterval);
          log(`⚠️ Google Flow menolak prompt ${sceneId} (Safety Policy Violation). Melaporkan ke desktop...`);
          injectFlowStatusOverlay(`⚠️ Kebijakan Flow Terpicu (${sceneId}). Meminta sanitasi...`, false, true);
          try {
            await fetch(`${DESKTOP_BRIDGE_URL}/report-policy-error`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ worker_id: workerId, scene_id: sceneId })
            });
          } catch (e) {}
          setTimeout(startSwarmWorkerLoop, 2500);
          return;
        }

        // 2. Deteksi Kartu Aktivitas Tidak Biasa Baru (Unusual Activity - Auto Reload 1x)
        if (currentFailed.unusualCount > initialFailed.unusualCount) {
          clearInterval(checkInterval);
          const retryKey = 'flow_unusual_retry_' + sceneId;
          const retryCount = parseInt(sessionStorage.getItem(retryKey) || '0', 10);

          if (retryCount < 1) {
            sessionStorage.setItem(retryKey, '1');
            log(`⚠️ Aktivitas tidak biasa terdeteksi untuk ${sceneId}. Melepas tugas & merefresh tab...`, 'WARN');
            injectFlowStatusOverlay(`⚠️ Aktivitas tidak biasa terdeteksi. Merefresh tab & mengulang ${sceneId}...`, false, true);
            try {
              await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ worker_id: workerId, scene_id: sceneId, reason: 'Unusual Activity - Auto Reload' })
              });
            } catch (e) {}
            setTimeout(() => { window.location.reload(); }, 2000);
            return;
          } else {
            sessionStorage.removeItem(retryKey);
            log(`⚠️ ${sceneId} masih gagal setelah reload. Melepas tugas ke antrean...`, 'WARN');
            injectFlowStatusOverlay(`⚠️ ${sceneId} aktivitas tidak biasa berulang. Melepaskan tugas...`, false, true);
            try {
              await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ worker_id: workerId, scene_id: sceneId, reason: 'Unusual Activity - Max Reload Exceeded' })
              });
            } catch (e) {}
            setTimeout(startSwarmWorkerLoop, 4000);
            return;
          }
        }
      }

      const targetRatio = task.aspect_ratio || '9:16';
      const images = Array.from(document.querySelectorAll('img'));
      const candidates = images.filter(img => {
        const src = img.src || '';
        const width = img.naturalWidth || img.clientWidth || 0;
        const height = img.naturalHeight || img.clientHeight || 0;
        const isValidSrc = src.startsWith('http') || src.startsWith('blob:') || src.startsWith('data:');
        if (!isValidSrc || (width <= 120 && height <= 120)) return false;
        if (typeof isBlacklistedAssetUrl === 'function' && isBlacklistedAssetUrl(src)) return false;
        if (typeof isAspectRatioMatching === 'function' && !isAspectRatioMatching(width, height, targetRatio)) return false;
        return true;
      });

      for (const img of candidates) await hydrateFlowCardPrompt(img);
      if (!isSwarmActive || currentSwarmTask !== task) {
        clearInterval(checkInterval);
        return;
      }
      const matchingCandidates = candidates.filter(img => isImageMatchingPrompt(img, expectedPrompt));

      // Wajib gambar hasil render baru yang belum ada di initialSrcs (v2.7.1)
      let targetImg = matchingCandidates.find(img => !initialSrcs.has(img.src));

      if (targetImg) {
        if (targetImg.src) sessionClaimedImages.add(targetImg.src);
        clearInterval(checkInterval);
        if (typeof dismissAnyOpenFlowViewer === 'function') dismissAnyOpenFlowViewer();
        const ok = await uploadSwarmImageElement(targetImg, sceneId, task);
        if (ok) {
          setTimeout(startSwarmWorkerLoop, 2500);
        } else {
          await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ worker_id: workerId, scene_id: sceneId, reason: 'Asset upload failed' })
          });
          setTimeout(startSwarmWorkerLoop, 3500);
        }
        return;
      }

      if (attempts >= maxAttempts) {
        clearInterval(checkInterval);
        log(`Timeout render gambar untuk ${sceneId}: rasio=${targetRatio}, gambar=${images.length}, lolos ukuran/rasio=${candidates.length}, cocok prompt=${matchingCandidates.length}.`);
        injectFlowStatusOverlay(`⚠️ Timeout render ${sceneId}. Mengulang...`, false, true);
        const releaseRes = await fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ worker_id: workerId, scene_id: sceneId, reason: 'Render timeout' })
        });
        const released = await releaseRes.json();
        if (released.task_status === 'failed') {
          log(`⚠️ ${sceneId} gagal setelah batas retry. Periksa rasio dan metadata kartu sebelum mencoba ulang.`);
        }
        setTimeout(startSwarmWorkerLoop, 4000);
      }
    } catch (err) {
      log(`Gagal memeriksa hasil ${sceneId}: ${err}`, 'WARN');
    } finally {
      checking = false;
    }
  }, 2000);
}

// ── 5. PENANGANAN OTOMATISASI TERPADU & STANDALONE FALLBACK (SRS-FAB-LOCAL-WHITEGUARD-001) ──

async function getStoredLocalQueueInfo() {
  return new Promise(resolve => {
    chrome.storage.local.get(['storyboardQueue', 'activeIndex'], data => {
      const rawQueue = data.storyboardQueue || [];
      const queue = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);
      const activeIndex = typeof data.activeIndex === 'number' ? data.activeIndex : -1;
      const hasPending = queue.length > 0 && activeIndex < queue.length - 1;
      resolve({ queue, activeIndex, hasPending, total: queue.length });
    });
  });
}

async function handleStartAutomation() {
  if (window !== window.top) return { success: false, mode: 'iframe_ignored' };

  // FR-LOC-001: Prioritas Antrean Lokal Mandiri (Local-First Priority Hierarchy)
  // Periksa apakah ada antrean JSON yang diunggah pengguna di panel ekstensi
  const localQueueInfo = await getStoredLocalQueueInfo();

  if (localQueueInfo.hasPending) {
    log(`[Local-First] Ditemukan ${localQueueInfo.total} prompt di storyboardQueue lokal. Memulai Standalone Pipeline...`);
    isSwarmActive = false;
    isLocalQueueActive = true;
    injectFlowStatusOverlay(`Memulai naskah lokal (${localQueueInfo.total} adegan)...`, true, false);

    if (window.FlowSlidingWindowPipeline && window.FlowSlidingWindowPipeline.start) {
      window.FlowSlidingWindowPipeline.start();
    } else {
      startLocalQueueLoop();
    }
    return { success: true, mode: 'local' };
  }

  // Jika antrean lokal kosong, barulah periksa ketersediaan mode Swarm Cluster Desktop
  const isOnline = await checkDesktopBridgeOnline();
  if (isOnline) {
    log('Antrean lokal kosong. Memulai otomatisasi dalam Mode Swarm Cluster...');
    await registerSwarmWorker();
    startHeartbeatLoop();
    isSwarmActive = true;
    isLocalQueueActive = false;
    injectFlowStatusOverlay('Swarm Aktif. Mengklaim tugas dari Desktop...', true, true);
    startSwarmWorkerLoop();
    return { success: true, mode: 'swarm' };
  } else {
    log('Antrean lokal kosong dan Desktop offline. Standby...');
    isSwarmActive = false;
    isLocalQueueActive = false;
    injectFlowStatusOverlay('Antrean kosong. Unggah file JSON atau buka Storyboard di Desktop.', false, false);
    return { success: false, mode: 'idle' };
  }
}

function handlePauseAutomation() {
  isSwarmActive = false;
  isLocalQueueActive = false;
  if (window.FlowSlidingWindowPipeline && window.FlowSlidingWindowPipeline.pause) {
    window.FlowSlidingWindowPipeline.pause();
  }
  chrome.storage.local.set({
    automationRunning: false,
    flowExecutionState: { status: 'paused', text: 'Otomatisasi Dijeda.' }
  });
  log('Otomatisasi dijeda sementara oleh pengguna.');
  injectFlowStatusOverlay('Otomatisasi Dijeda.', false, false, false);
}

function handleStopAutomation() {
  isSwarmActive = false;
  isLocalQueueActive = false;
  sessionClaimedImages.clear();
  if (window.FlowSlidingWindowPipeline && window.FlowSlidingWindowPipeline.stop) {
    window.FlowSlidingWindowPipeline.stop();
  }
  chrome.storage.local.set({
    automationRunning: false,
    flowExecutionState: { status: 'idle', text: 'Otomatisasi Dihentikan. Siap mulai kembali.' }
  });
  if (currentSwarmTask && workerId) {
    try {
      fetch(`${DESKTOP_BRIDGE_URL}/release-task`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ worker_id: workerId, scene_id: currentSwarmTask.scene_id, reason: 'Pengguna menghentikan otomatisasi' }),
        keepalive: true
      }).catch(() => {});
    } catch (e) {}
  }
  currentSwarmTask = null;
  log('Otomatisasi dihentikan oleh pengguna.');
  injectFlowStatusOverlay('Otomatisasi Dihentikan. Siap mulai kembali.', false, false, true);
}

async function startLocalQueueLoop() {
  if (window.FlowSlidingWindowPipeline && window.FlowSlidingWindowPipeline.start) {
    window.FlowSlidingWindowPipeline.start();
  }
}

async function handleSendSingleScene(payload) {
  const sceneIndex = typeof payload.sceneIndex === 'number' ? payload.sceneIndex : 0;
  const sceneId = payload.sceneId || `ADEGAN_${String(sceneIndex + 1).padStart(2, '0')}`;
  const prompt = String(payload.prompt || '').trim();
  const targetRatio = payload.aspectRatio || (prompt.includes('16:9') ? '16:9' : '9:16');
  if (!prompt) return { success: false, error: 'Prompt adegan kosong.' };

  chrome.storage.local.set({ currentProcessingSceneId: sceneId });
  injectFlowStatusOverlay(`1/4: Menyiapkan kirim manual ${sceneId}...`, true, false);

  if (typeof dismissAnyOpenFlowViewer === 'function') dismissAnyOpenFlowViewer();
  let textarea = null;
  for (let attempt = 0; attempt < 8; attempt++) {
    textarea = findPromptTextarea();
    if (textarea) break;
    await new Promise(r => setTimeout(r, 400));
  }
  if (!textarea) {
    injectFlowStatusOverlay(`⚠️ Input prompt tidak terdeteksi (${sceneId})`, false, false, true);
    return { success: false, error: 'Kolom input prompt Flow tidak ditemukan.' };
  }

  injectFlowStatusOverlay(`2/4: Mengetik prompt ${sceneId}...`, true, false);
  fillPromptInput(textarea, prompt);
  await new Promise(r => setTimeout(r, 1000));

  let generateBtn = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    generateBtn = findGenerateButton(textarea);
    if (generateBtn) break;
    await new Promise(r => setTimeout(r, 350));
  }
  injectFlowStatusOverlay(`3/4: Mengirim generate ${sceneId}...`, true, false);
  const isSubmitted = await triggerGenerate(textarea, generateBtn);
  if (!isSubmitted) {
    injectFlowStatusOverlay(`⚠️ Submit gagal (${sceneId}). Coba klik lagi.`, false, false, true);
    return { success: false, error: 'Gagal menekan tombol Generate.' };
  }

  monitorFlowRenderCompletion(sceneId, sceneIndex, prompt, targetRatio, true);
  return { success: true, sceneId };
}

// ── 6. LISTENER & INISIALISASI TAB ──

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (window !== window.top) return false; // FR-ISO-003: Abaikan pesan jika berjalan di sub-iframe
  if (message.action === 'fab_check_scenes_on_screen') {
    try {
      const candidateImgs = Array.from(document.querySelectorAll('img')).filter((img) => {
        const src = img.src || '';
        const w = img.naturalWidth || img.clientWidth || 0;
        const h = img.naturalHeight || img.clientHeight || 0;
        const isCard = (img.className && (img.className.includes('object-cover') || img.className.includes('w-full'))) || (w >= 100 && h >= 100);
        return (src.startsWith('data:image') || src.startsWith('http') || src.startsWith('blob:')) && isCard;
      });

      const items = [];
      const seenUrls = new Set();
      const seenIds = new Set();

      candidateImgs.forEach((img) => {
        const url = img.src;
        if (seenUrls.has(url)) return;
        seenUrls.add(url);

        let sceneLabel = '';
        let p = img.parentElement;
        for (let i = 0; i < 8 && p; i++) {
          if (!sceneLabel) {
            const badges = p.querySelectorAll('div, span');
            for (const b of badges) {
              if (b.children && b.children.length > 2) continue;
              const txt = (b.innerText || b.textContent || '').trim().toUpperCase();
              if (txt.includes('COVER') || txt.includes('ADGN') || txt.includes('ADEGAN') || txt.includes('SCENE')) {
                sceneLabel = txt;
                break;
              }
            }
          }
          p = p.parentElement;
        }

        let sceneId = '';
        if (sceneLabel.includes('COVER')) {
          sceneId = 'COVER';
        } else {
          const match = sceneLabel.match(/(?:ADEGAN|ADGN|SCENE)[_\s-]?(\d+)/i);
          if (match && match[1]) sceneId = `ADEGAN_${String(match[1]).padStart(2, '0')}`;
        }
        if (!sceneId || seenIds.has(sceneId)) {
          sceneId = `ADEGAN_${String(items.length + 1).padStart(2, '0')}`;
        }
        seenIds.add(sceneId);

        items.push({ id: sceneId, filename: `${sceneId}.png`, url: url });
      });

      let pTitle = '';
      const headings = Array.from(document.querySelectorAll('h1, h2, h3, [class*="font-black"], [class*="font-bold"]'));
      for (const h of headings) {
        const t = (h.innerText || h.textContent || '').trim();
        if (t.length >= 3 && t.length <= 70 && !t.toLowerCase().includes('adegan') && !t.toLowerCase().includes('caption')) {
          pTitle = t.replace(/[\\/:*?"<>|]/g, '_').trim();
          break;
        }
      }

      sendResponse({ success: true, count: items.length, items: items, projectName: pTitle });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }

  if (message.action === 'start_automation' || message.action === 'resume_automation') {
    chrome.storage.local.set({ automationRunning: true });
    handleStartAutomation().then(result => sendResponse(result));
    return true;
  }
  if (message.action === 'send_single_scene') {
    handleSendSingleScene(message).then(result => sendResponse(result));
    return true;
  }
  if (message.action === 'pause_automation') {
    handlePauseAutomation();
    sendResponse({ success: true, status: 'paused' });
    return true;
  }
  if (message.action === 'stop_automation') {
    handleStopAutomation();
    sendResponse({ success: true, status: 'stopped' });
    return true;
  }
  if (message.action === 'reset_index') {
    chrome.storage.local.set({ activeIndex: -1 }, () => {
      injectFlowStatusOverlay('Antrean direset ke awal (Scene 1). Siap mulai.', false, isSwarmActive, true);
      sendResponse({ success: true });
    });
    return true;
  }
  if (message.action === 'get_status') {
    sendResponse({ workerId, isSwarmActive, isLocalQueueActive, currentSwarmTask });
    return true;
  }
});

window.addEventListener('pagehide', () => {
  if (window !== window.top || !workerId) return; // FR-ISO-004: Abaikan unregister jika event berasal dari sub-iframe
  try {
    fetch(`${DESKTOP_BRIDGE_URL}/unregister-worker`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ worker_id: workerId }),
      keepalive: true
    }).catch(() => {});
  } catch (e) {}
});

(async () => {
  if (window !== window.top) {
    return; // FR-ISO-003: Sub-iframe dilarang mendaftarkan worker atau mengaktifkan swarm loop
  }
  log(`Menginisialisasi ekstensi di tab Google Flow...`);

  // FR-LOC-001: Jika pengguna memiliki naskah lokal di ekstensi, prioritaskan mode lokal
  const localInfo = await getStoredLocalQueueInfo();
  if (localInfo.hasPending) {
    log(`[Startup] Antrean naskah lokal terdeteksi (${localInfo.total} adegan). Siap dijalankan mandiri.`);
    injectFlowStatusOverlay(`Naskah lokal siap (${localInfo.total} adegan). Klik Mulai Otomatisasi.`, false, false);
    chrome.storage.local.get(['automationRunning'], (data) => {
      if (data && data.automationRunning) {
        log('Melanjutkan otomatisasi antrean lokal dari sesi sebelumnya...');
        handleStartAutomation();
      }
    });
    return;
  }

  const isOnline = await checkDesktopBridgeOnline();
  if (isOnline) {
    log(`Desktop Bridge terdeteksi ONLINE di port 8000! Mendaftarkan Worker Swarm...`);
    await registerSwarmWorker();
    startHeartbeatLoop();
    isSwarmActive = true;
    injectFlowStatusOverlay(`Swarm Siap. Klik Mulai atau tunggu antrean...`, true, true);
    setTimeout(startSwarmWorkerLoop, 3000);
  } else {
    log(`Desktop Bridge offline. Menggunakan mode antrean lokal Chrome.`);
    injectFlowStatusOverlay('Mode Standalone (Server Offline)', false, false);
    chrome.storage.local.get(['automationRunning'], (data) => {
      if (data && data.automationRunning) {
        log('Melanjutkan otomatisasi antrean lokal dari sesi sebelumnya...');
        isLocalQueueActive = true;
        injectFlowStatusOverlay('Melanjutkan antrean lokal...', true, false);
        setTimeout(startLocalQueueLoop, 2000);
      }
    });

    const reconnectTimer = setInterval(async () => {
      const currentLocal = await getStoredLocalQueueInfo();
      if (currentLocal.hasPending) {
        // Jangan alihkan ke swarm jika user mengunggah naskah lokal
        return;
      }
      const nowOnline = await checkDesktopBridgeOnline();
      if (nowOnline) {
        clearInterval(reconnectTimer);
        log(`✓ Desktop Bridge kini terdeteksi ONLINE! Mengalihkan ke Swarm Mode...`);
        await registerSwarmWorker();
        startHeartbeatLoop();
        isSwarmActive = true;
        isLocalQueueActive = false;
        injectFlowStatusOverlay(`Swarm Siap. Terhubung ke Desktop!`, true, true);
        setTimeout(startSwarmWorkerLoop, 2500);
      }
    }, 3500);
  }
})();
