/**
 * popup_mode_ui_controller.js (SRS-112 / FR-03)
 * Pengendali Dinamis UI Bersih antara Mode Swarm (Worker Desktop) vs Mode Standalone (Studio Mandiri).
 */
(function (global) {
  'use strict';

  function computeModeState(workMode, currentTab = 'storyboard', localQueueLength = 0) {
    const isSwarm = workMode === 'swarm_worker';
    const nextTab = (isSwarm && currentTab === 'studio') ? 'storyboard' : (currentTab || 'storyboard');
    return {
      workMode: isSwarm ? 'swarm_worker' : 'autonomous_local',
      bodyClass: isSwarm ? 'mode-swarm' : 'mode-standalone',
      showCreatorCard: !isSwarm,
      showCapcutTab: !isSwarm,
      showExportBar: !isSwarm,
      showBatchImportBtn: !isSwarm,
      showSwarmHud: isSwarm,
      hasLingeringLocalQueue: Number(localQueueLength) > 0,
      nextTab
    };
  }

  function computeSwarmStandbyView(snapshot = {}) {
    const queueList = Array.isArray(snapshot.storyboardQueue) ? snapshot.storyboardQueue : [];
    const renderedCount = snapshot.renderedSceneUrls && typeof snapshot.renderedSceneUrls === 'object'
      ? Object.keys(snapshot.renderedSceneUrls).length
      : 0;
    const isRunning = Boolean(snapshot.automationRunning);
    const currentId = snapshot.currentProcessingSceneId ? String(snapshot.currentProcessingSceneId).trim() : '';
    const execText = (snapshot.flowExecutionState && snapshot.flowExecutionState.text) || '';

    if (isRunning) {
      return {
        status: 'active_task',
        badgeText: '🎨 RENDER SWARM AKTIF',
        headline: currentId ? `Sedang Memproses ${currentId}` : 'Sedang Memproses Tugas Desktop',
        detail: execText || 'Worker sedang menjalankan antrean render dari Aplikasi Desktop.',
        lingeringCount: 0
      };
    }

    const lingeringTotal = queueList.length + renderedCount;
    if (lingeringTotal > 0) {
      return {
        status: 'standby_needs_reset',
        badgeText: '⚠️ STANDBY · ADA SISA DATA STANDALONE',
        headline: 'Tersimpan Sisa Kanvas Mode Standalone',
        detail: `Ditemukan ${queueList.length} antrean & ${renderedCount} pratinjau lokal. Tekan "🗑️ Reset Kanvas & Antrean" di bawah agar Worker Swarm bersih dan siap menerima tugas Desktop.`,
        lingeringCount: lingeringTotal
      };
    }

    return {
      status: 'standby_clean',
      badgeText: '● WORKER STANDBY',
      headline: 'Worker Swarm dalam Keadaan Standby',
      detail: 'Kanvas lokal bersih. Menunggu antrean render otomatis dari Aplikasi Desktop IntisariShortMovie.',
      lingeringCount: 0
    };
  }

  function renderSwarmStandbyBox(boxEl, snapshot = {}) {
    if (!boxEl) return;
    const view = computeSwarmStandbyView(snapshot);
    boxEl.classList.remove('is-needs-reset', 'is-active');
    if (view.status === 'standby_needs_reset') boxEl.classList.add('is-needs-reset');
    if (view.status === 'active_task') boxEl.classList.add('is-active');

    const badgeCls = view.status === 'active_task' ? 'active' : (view.status === 'standby_needs_reset' ? 'warn' : 'clean');
    boxEl.innerHTML = `
      <span class="swarm-standby-badge ${badgeCls}">${view.badgeText}</span>
      <p class="swarm-standby-headline">${view.headline}</p>
      <p class="swarm-standby-detail">${view.detail}</p>
    `;
  }

  function applyBodyModeClass(bodyClass) {
    if (typeof document === 'undefined' || !document.body) return;
    document.body.classList.remove('mode-swarm', 'mode-standalone');
    document.body.classList.add(bodyClass);
  }

  function renderSwarmHud(hudEl, snapshot = {}, handlers = {}) {
    if (!hudEl) return;
    const queueList = Array.isArray(snapshot.storyboardQueue) ? snapshot.storyboardQueue : [];
    const execState = snapshot.flowExecutionState || {};
    const stepText = execState.text || (snapshot.automationRunning ? 'Aktif memproses tugas Swarm...' : 'Standby — menunggu tugas dari Aplikasi Desktop');
    const titleEl = typeof document !== 'undefined' ? document.getElementById('storyboard-scenes-title') : null;
    if (titleEl) {
      titleEl.textContent = snapshot.extensionWorkMode === 'swarm_worker'
        ? 'Antrean Render Worker Swarm'
        : 'Linimasa Adegan';
    }

    const warningHtml = queueList.length > 0 ? `
      <div class="swarm-hud-warning">
        <span>⚠️ Terdapat <strong>${queueList.length} adegan</strong> antrean Standalone lokal tersimpan. Sesuai aturan isolasi SRS-109, Worker Swarm tertahan sampai antrean lokal dikosongkan.</span>
        <button type="button" id="btn-swarm-clear-local-queue" class="swarm-hud-btn swarm-hud-btn-warn">🗑️ Kosongkan Antrean Lokal & Aktifkan Swarm</button>
      </div>
    ` : '';

    hudEl.innerHTML = `
      <div class="swarm-hud-header">
        <div class="swarm-hud-title-wrap">
          <span>🐝</span>
          <strong class="swarm-hud-title">Mode Swarm Desktop (Worker)</strong>
        </div>
        <span class="swarm-hud-pill">${snapshot.automationRunning ? 'AKTIF' : 'STANDBY'}</span>
      </div>
      <p class="swarm-hud-desc">
        Tab Google Flow ini bertindak sebagai pekerja render Aplikasi Desktop. Menu pembuatan naskah, katalog gaya, dan ekspor CapCut disembunyikan agar tampilan tetap bersih.
      </p>
      <div class="swarm-hud-metrics">
        <div class="swarm-hud-metric-box">
          <span class="swarm-hud-metric-label">Status Tugas Swarm</span>
          <span class="swarm-hud-metric-val">${stepText}</span>
        </div>
        <div class="swarm-hud-metric-box">
          <span class="swarm-hud-metric-label">Antrean Lokal</span>
          <span class="swarm-hud-metric-val">${queueList.length === 0 ? '✓ Bersih (Siap Klaim)' : `${queueList.length} Tersimpan`}</span>
        </div>
      </div>
      ${warningHtml}
      <div class="swarm-hud-actions">
        <button type="button" id="btn-swarm-refresh-flow" class="swarm-hud-btn">🔄 Refresh Tab Flow</button>
        <button type="button" id="btn-swarm-to-standalone" class="swarm-hud-btn">👤 Pindah ke Mode Standalone</button>
      </div>
    `;

    const btnToStandalone = hudEl.querySelector('#btn-swarm-to-standalone');
    if (btnToStandalone && typeof handlers.onSwitchToStandalone === 'function') {
      btnToStandalone.addEventListener('click', handlers.onSwitchToStandalone);
    }
    const btnClearQueue = hudEl.querySelector('#btn-swarm-clear-local-queue');
    if (btnClearQueue && typeof handlers.onClearLocalQueue === 'function') {
      btnClearQueue.addEventListener('click', handlers.onClearLocalQueue);
    }
    const btnRefresh = hudEl.querySelector('#btn-swarm-refresh-flow');
    if (btnRefresh && typeof handlers.onRefreshFlow === 'function') {
      btnRefresh.addEventListener('click', handlers.onRefreshFlow);
    }
  }

  function init(options = {}) {
    const { getCurrentTab, onSwitchTab, onUpdateStatus } = options;
    const hudEl = typeof document !== 'undefined' ? document.getElementById('swarm-worker-hud-card') : null;
    const standbyEl = typeof document !== 'undefined' ? document.getElementById('swarm-standby-status-box') : null;

    const refresh = () => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
      chrome.storage.local.get(
        ['extensionWorkMode', 'storyboardQueue', 'renderedSceneUrls', 'currentProcessingSceneId', 'flowExecutionState', 'automationRunning'],
        (res) => {
          const currentTab = typeof getCurrentTab === 'function' ? getCurrentTab() : 'storyboard';
          const qLen = Array.isArray(res.storyboardQueue) ? res.storyboardQueue.length : 0;
          const state = computeModeState(res.extensionWorkMode, currentTab, qLen);

          applyBodyModeClass(state.bodyClass);
          if (state.nextTab !== currentTab && typeof onSwitchTab === 'function') {
            onSwitchTab(state.nextTab);
          }

          renderSwarmStandbyBox(standbyEl, res);
          renderSwarmHud(hudEl, res, {
            onSwitchToStandalone: () => {
              chrome.storage.local.set({ extensionWorkMode: 'autonomous_local' }, () => {
                if (typeof onUpdateStatus === 'function') {
                  onUpdateStatus('✓ Beralih ke Mode Standalone (Studio Penuh).');
                }
              });
            },
            onClearLocalQueue: () => {
              chrome.storage.local.set({
                storyboardQueue: [],
                flowQueue: [],
                activeIndex: -1,
                renderedSceneUrls: {},
                sceneRenderStates: {},
                currentProcessingSceneId: null
              }, () => {
                if (typeof onUpdateStatus === 'function') {
                  onUpdateStatus('✓ Antrean lokal dikosongkan. Worker Swarm siap menerima tugas Desktop.');
                }
              });
            },
            onRefreshFlow: () => {
              if (chrome.tabs && chrome.tabs.query) {
                chrome.tabs.query({ url: '*://flow.google.com/*' }, (tabs) => {
                  if (tabs && tabs.length > 0) {
                    tabs.forEach((t) => chrome.tabs.reload(t.id));
                    if (typeof onUpdateStatus === 'function') {
                      onUpdateStatus('🔄 Me-reload tab Google Flow...');
                    }
                  }
                });
              }
            }
          });
        }
      );
    };

    refresh();

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes) => {
        if (changes.extensionWorkMode || changes.storyboardQueue || changes.renderedSceneUrls || changes.currentProcessingSceneId || changes.flowExecutionState || changes.automationRunning) {
          refresh();
        }
      });
    }
  }

  const api = { computeModeState, computeSwarmStandbyView, applyBodyModeClass, renderSwarmHud, renderSwarmStandbyBox, init };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.PopupModeUiController = api;
})(typeof window !== 'undefined' ? window : globalThis);
