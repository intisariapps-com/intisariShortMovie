// ==============================================================================
// 📁 FILE   : extension/storyboard_aligner.js
// 📝 FUNGSI : Mesin Penyelaras Naskah & Stempel Waktu (Dynamic Programming Alignment)
//             Menghasilkan linimasa adegan presisi mikrodetik dan subtitel per frasa.
// ==============================================================================

(function(global) {
  'use strict';

  /**
   * Mengonversi detik float ke format waktu SRT: HH:MM:SS,mmm
   */
  function secondsToSrtTime(seconds) {
    const totalMs = Math.max(0, Math.round(seconds * 1000));
    const ms = totalMs % 1000;
    const totalSec = Math.floor(totalMs / 1000);
    const sec = totalSec % 60;
    const totalMin = Math.floor(totalSec / 60);
    const min = totalMin % 60;
    const hr = Math.floor(totalMin / 60);

    const pad = (num, size = 2) => String(num).padStart(size, '0');
    return `${pad(hr)}:${pad(min)}:${pad(sec)},${pad(ms, 3)}`;
  }

  /**
   * Membersihkan teks kata untuk perbandingan heuristik (lowercase, tanpa tanda baca).
   */
  function cleanWord(str) {
    return (str || '').toLowerCase().replace(/[^a-z0-9]/gi, '');
  }

  /**
   * Menyelaraskan kata-kata Whisper dengan adegan-adegan storyboard.
   * Mengembalikan scenes dengan properti timing terkalibrasi presisi mikrodetik.
   * 
   * @param {Array<Object>} rawScenes - Array adegan dari JSON storyboard
   * @param {Array<Object>} whisperWords - Array kata [{word, start, end}] dari Groq Whisper
   * @param {number} totalAudioDuration - Total durasi audio dalam detik
   * @returns {{scenes: Array<Object>, coverOffset: number, totalDurationUs: number}}
   */
  function alignStoryboardWithWhisper(rawScenes, whisperWords, totalAudioDuration) {
    if (!Array.isArray(rawScenes) || rawScenes.length === 0) {
      throw new Error("Daftar adegan storyboard kosong.");
    }

    const scenes = JSON.parse(JSON.stringify(rawScenes));
    const words = Array.isArray(whisperWords) ? whisperWords : [];

    // 1. Deteksi apakah adegan pertama adalah COVER (Poster Thumbnail)
    const hasCoverFirst = String(scenes[0].id || '').toUpperCase() === 'COVER';
    let coverOffset = 0.0;
    let timelineScenes = scenes;

    if (hasCoverFirst) {
      const coverTiming = scenes[0].timing || {};
      coverOffset = typeof coverTiming.end === 'number' && coverTiming.end > 0 ? coverTiming.end : 0.0;
      // Jika adegan berikutnya (ADEGAN_01) mulai dari 0.0s pada audio, maka coverOffset = 0
      timelineScenes = scenes.slice(1);
    }

    // 2. Ekstrak kata-kata dari narasi per adegan
    const sceneTokens = timelineScenes.map((sc) => {
      const narrative = sc.narrative || sc.text || '';
      const tokens = narrative.split(/\s+/).map(cleanWord).filter(Boolean);
      return { scene: sc, tokens };
    });

    // 3. Jika data Whisper kosong, buat perkiraan proporsional berdasarkan jumlah kata / durasi adegan
    if (words.length === 0) {
      const prop = alignProportionally(timelineScenes, totalAudioDuration, coverOffset);
      if (hasCoverFirst) {
        const covDurS = parseFloat(scenes[0].duration) > 0 ? parseFloat(scenes[0].duration) : 3.0;
        scenes[0].start_us = 0;
        scenes[0].duration_us = Math.round(covDurS * 1000000);
      }
      return {
        scenes: scenes,
        timelineScenes: prop.scenes,
        allScenesWithCover: scenes,
        coverOffset,
        totalDurationUs: prop.totalDurationUs
      };
    }

    // 4. Pencocokan kata sekuensial (Greedy Dynamic Programming Pointer)
    let wordIdx = 0;
    let currentStart = 0.0;

    for (let s = 0; s < sceneTokens.length; s++) {
      const item = sceneTokens[s];
      const targetTokens = item.tokens;

      if (targetTokens.length === 0) {
        // Adegan hening/tanpa narasi: berikan durasi default 2.5s
        const dur = 2.5;
        const end = Math.min(totalAudioDuration, currentStart + dur);
        item.scene.timing = { start: currentStart, end: end, duration: end - currentStart };
        currentStart = end;
        continue;
      }

      // Cari awal kemunculan kata pertama
      const sceneStartWord = words[wordIdx];
      const sceneStartTime = sceneStartWord ? sceneStartWord.start : currentStart;

      // Geser pointer kata sebanyak panjang token adegan dengan pencocokan toleran
      let matchedCount = 0;
      let lastWordEnd = sceneStartTime + 1.0;

      while (wordIdx < words.length && matchedCount < targetTokens.length) {
        const w = words[wordIdx];
        lastWordEnd = w.end;
        wordIdx++;
        matchedCount++;
      }

      // Jika adegan terakhir, pastikan mencakup hingga akhir audio
      if (s === sceneTokens.length - 1) {
        lastWordEnd = Math.max(lastWordEnd, totalAudioDuration);
      }

      const sceneEndTime = Math.max(sceneStartTime + 0.5, lastWordEnd);
      item.scene.timing = {
        start: parseFloat(sceneStartTime.toFixed(3)),
        end: parseFloat(sceneEndTime.toFixed(3)),
        duration: parseFloat((sceneEndTime - sceneStartTime).toFixed(3))
      };
      currentStart = sceneEndTime;
    }

    // 5. Normalisasi Zero-Gap Contiguous Timeline & Konversi Mikrodetik
    let runningUs = 0;
    let maxDurationUs = 0;

    timelineScenes.forEach((sc, idx) => {
      let t = sc.timing || {};
      let startS = typeof t.start === 'number' ? Math.max(0, t.start - coverOffset) : (runningUs / 1000000);
      let endS = typeof t.end === 'number' ? Math.max(startS + 0.2, t.end - coverOffset) : (startS + 3.0);

      const startUs = Math.round(startS * 1000000);
      const durUs = Math.round((endS - startS) * 1000000);

      sc.start_us = startUs;
      sc.duration_us = durUs;

      runningUs = startUs + durUs;
      if (runningUs > maxDurationUs) maxDurationUs = runningUs;
    });

    return {
      scenes: timelineScenes,
      allScenesWithCover: scenes,
      coverOffset,
      totalDurationUs: maxDurationUs
    };
  }

  /**
   * Fallback pembagian durasi linimasa proporsional jika Whisper offline.
   */
  function alignProportionally(timelineScenes, totalAudioDuration, coverOffset = 0.0) {
    if (!totalAudioDuration || totalAudioDuration <= 0) {
      let curTime = 0.0;
      let maxUs = 0;
      timelineScenes.forEach((sc) => {
        const t = sc.timing || {};
        let durS = 3.5;
        if (typeof t.start === 'number' && typeof t.end === 'number' && t.end > t.start) {
          durS = parseFloat((t.end - t.start).toFixed(3));
        } else if (parseFloat(sc.duration) > 0) {
          durS = parseFloat(sc.duration);
        }
        const start = curTime;
        const end = parseFloat((start + durS).toFixed(3));
        sc.timing = { start, end, duration: durS };
        sc.start_us = Math.round(start * 1000000);
        sc.duration_us = Math.round(durS * 1000000);
        curTime = end;
        if (sc.start_us + sc.duration_us > maxUs) maxUs = sc.start_us + sc.duration_us;
      });
      return {
        scenes: timelineScenes,
        coverOffset,
        totalDurationUs: maxUs
      };
    }

    const totalWords = timelineScenes.reduce((acc, sc) => {
      const words = (sc.narrative || sc.text || '').split(/\s+/).filter(Boolean).length;
      return acc + Math.max(1, words);
    }, 0);

    const safeDuration = totalAudioDuration > 0 ? totalAudioDuration : (timelineScenes.length * 3.5);
    let curTime = 0.0;
    let maxUs = 0;

    timelineScenes.forEach((sc, i) => {
      const wordCount = Math.max(1, (sc.narrative || sc.text || '').split(/\s+/).filter(Boolean).length);
      const share = wordCount / totalWords;
      const dur = parseFloat((share * safeDuration).toFixed(3));
      const start = curTime;
      const end = i === timelineScenes.length - 1 ? safeDuration : parseFloat((start + dur).toFixed(3));

      sc.timing = { start, end, duration: end - start };
      sc.start_us = Math.round(start * 1000000);
      sc.duration_us = Math.round((end - start) * 1000000);

      curTime = end;
      if (sc.start_us + sc.duration_us > maxUs) maxUs = sc.start_us + sc.duration_us;
    });

    return {
      scenes: timelineScenes,
      coverOffset,
      totalDurationUs: maxUs
    };
  }

  /**
   * Memecah narasi adegan menjadi frasa-frasa pendek untuk teks subtitel vertikal.
   * @param {string} text - Narasi teks
   * @param {number} sceneStartS - Detik mulai adegan
   * @param {number} sceneDurationS - Durasi detik adegan
   * @returns {Array<{text: string, startS: number, endS: number, startUs: number, durUs: number}>}
   */
  function splitIntoSubtitlePhrases(text, sceneStartS, sceneDurationS) {
    if (!text || !text.trim() || text.trim() === '-') return [];

    const words = text.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) return [];

    // Pecah per 3-5 kata per baris frasa
    const CHUNK_SIZE = 4;
    const phrases = [];
    for (let i = 0; i < words.length; i += CHUNK_SIZE) {
      phrases.push(words.slice(i, i + CHUNK_SIZE).join(' '));
    }

    const totalPhrases = phrases.length;
    const phraseDuration = sceneDurationS / totalPhrases;

    return phrases.map((ph, idx) => {
      const s = sceneStartS + (idx * phraseDuration);
      const e = idx === totalPhrases - 1 ? (sceneStartS + sceneDurationS) : (s + phraseDuration);
      return {
        text: ph,
        startS: s,
        endS: e,
        startUs: Math.round(s * 1000000),
        durUs: Math.round((e - s) * 1000000)
      };
    });
  }

  /**
   * Menghasilkan isi teks berkas SubRip .SRT (UTF-8 LF) dari daftar adegan.
   * @param {Array<Object>} scenes
   * @param {number} [coverOffset=0.0]
   * @returns {string}
   */
  function generateSrtText(scenes, coverOffset = 0.0) {
    const lines = [];
    let cueIndex = 1;

    (scenes || []).forEach((sc) => {
      if (String(sc.id || '').toUpperCase() === 'COVER') return;
      const narrative = (sc.narrative || sc.text || '').trim();
      if (!narrative || narrative === '-') return;

      const t = sc.timing || {};
      const startS = Math.max(0.0, (typeof t.start === 'number' ? t.start : 0.0) - coverOffset);
      const endS = Math.max(startS + 0.2, (typeof t.end === 'number' ? t.end : startS + 3.0) - coverOffset);

      // Gunakan frasa terbagi jika narasi cukup panjang
      const phrases = splitIntoSubtitlePhrases(narrative, startS, endS - startS);
      if (phrases.length > 0) {
        phrases.forEach((ph) => {
          lines.push(String(cueIndex++));
          lines.push(`${secondsToSrtTime(ph.startS)} --> ${secondsToSrtTime(ph.endS)}`);
          lines.push(ph.text);
          lines.push('');
        });
      } else {
        lines.push(String(cueIndex++));
        lines.push(`${secondsToSrtTime(startS)} --> ${secondsToSrtTime(endS)}`);
        lines.push(narrative);
        lines.push('');
      }
    });

    return lines.join('\n');
  }

  // Registrasi global
  global.StoryboardAligner = {
    alignStoryboardWithWhisper,
    alignProportionally,
    splitIntoSubtitlePhrases,
    generateSrtText,
    secondsToSrtTime
  };

})(typeof window !== 'undefined' ? window : globalThis);

