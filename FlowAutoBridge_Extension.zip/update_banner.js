// ============================================================
// FlowAutoBridge — update_banner.js
// UI notifikasi update: FAB bulat + popover klik di kanan bawah
// ============================================================

(function () {
  'use strict';

  const FAB_ID      = 'fab-update-fab';
  const POPOVER_ID  = 'fab-update-popover';
  const STYLE_ID    = 'fab-update-style';
  const DISMISS_KEY = 'fab_update_dismissed';

  // ─── Inject CSS ─────────────────────────────────────────────────────────────
  function _injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      /* ── FAB Button ─────────────────────────────────────── */
      #fab-update-fab {
        position: fixed;
        bottom: 90px;
        right: 28px;
        z-index: 2147483647;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: linear-gradient(135deg, #2b6cb0, #6b46c1);
        box-shadow: 0 4px 18px rgba(107, 70, 193, 0.55), 0 2px 8px rgba(0,0,0,0.4);
        border: 2px solid rgba(255,255,255,0.15);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        transition: transform 0.2s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.2s;
        animation: fab-pop-in 0.45s cubic-bezier(0.34,1.56,0.64,1) both;
        pointer-events: all;
        user-select: none;
      }
      #fab-update-fab:hover {
        transform: scale(1.12);
        box-shadow: 0 6px 24px rgba(107, 70, 193, 0.7), 0 2px 8px rgba(0,0,0,0.4);
      }
      #fab-update-fab:active { transform: scale(0.95); }

      /* Titik merah notifikasi */
      #fab-update-fab .fab-dot {
        position: absolute;
        top: 2px;
        right: 2px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #fc8181;
        border: 2px solid #1a1a2e;
        animation: fab-pulse 2s ease-in-out infinite;
      }

      @keyframes fab-pop-in {
        from { transform: scale(0) rotate(-30deg); opacity: 0; }
        to   { transform: scale(1) rotate(0deg);   opacity: 1; }
      }
      @keyframes fab-pop-out {
        from { transform: scale(1); opacity: 1; }
        to   { transform: scale(0); opacity: 0; }
      }
      @keyframes fab-pulse {
        0%, 100% { box-shadow: 0 0 0 0 rgba(252,129,129,0.6); }
        50%       { box-shadow: 0 0 0 5px rgba(252,129,129,0); }
      }

      /* ── Popover Card ────────────────────────────────────── */
      #fab-update-popover {
        position: fixed;
        bottom: 150px;
        right: 28px;
        z-index: 2147483646;
        width: 280px;
        background: linear-gradient(145deg, #1a1a2e 0%, #16213e 70%, #0f3460 100%);
        border: 1px solid rgba(99,179,237,0.3);
        border-radius: 18px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.05);
        color: #e2e8f0;
        font-family: 'Google Sans', 'Segoe UI', sans-serif;
        font-size: 13px;
        overflow: hidden;
        pointer-events: all;
        transform-origin: bottom right;
        animation: popover-open 0.3s cubic-bezier(0.34,1.56,0.64,1) both;
      }
      #fab-update-popover.fab-closing {
        animation: popover-close 0.2s ease-in forwards;
      }
      @keyframes popover-open {
        from { transform: scale(0.7) translateY(16px); opacity: 0; }
        to   { transform: scale(1)   translateY(0);    opacity: 1; }
      }
      @keyframes popover-close {
        from { transform: scale(1)   translateY(0);    opacity: 1; }
        to   { transform: scale(0.7) translateY(16px); opacity: 0; }
      }

      /* Gradient stripe atas */
      #fab-update-popover::before {
        content: '';
        display: block;
        height: 3px;
        background: linear-gradient(90deg, #63b3ed, #9f7aea, #ed64a6);
      }

      .fab-pop-body {
        padding: 14px 14px 16px;
      }

      .fab-pop-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        margin-bottom: 10px;
        gap: 8px;
      }

      .fab-pop-title {
        font-weight: 700;
        font-size: 13px;
        color: #fff;
        line-height: 1.4;
        flex: 1;
      }

      .fab-pop-close {
        cursor: pointer;
        opacity: 0.45;
        font-size: 16px;
        background: none;
        border: none;
        color: #fff;
        padding: 0;
        line-height: 1;
        transition: opacity 0.2s;
        flex-shrink: 0;
        margin-top: 1px;
      }
      .fab-pop-close:hover { opacity: 1; }

      .fab-version-row {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-bottom: 10px;
      }

      .fab-badge {
        border-radius: 6px;
        padding: 2px 8px;
        font-size: 11px;
        font-weight: 700;
      }
      .fab-badge-old {
        background: rgba(255,255,255,0.1);
        color: #a0aec0;
      }
      .fab-badge-arrow { color: #63b3ed; font-size: 13px; }
      .fab-badge-new {
        background: linear-gradient(90deg, #2b6cb0, #6b46c1);
        color: #fff;
      }

      .fab-notes {
        font-size: 11.5px;
        color: #94a3b8;
        line-height: 1.55;
        margin-bottom: 13px;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }

      .fab-actions {
        display: flex;
        gap: 7px;
      }
      .fab-btn {
        flex: 1;
        padding: 8px 0;
        border-radius: 10px;
        border: none;
        cursor: pointer;
        font-size: 12px;
        font-weight: 600;
        font-family: inherit;
        transition: opacity 0.2s, transform 0.15s;
      }
      .fab-btn:hover { opacity: 0.82; transform: translateY(-1px); }
      .fab-btn:active { transform: scale(0.96); }
      .fab-btn-primary { background: linear-gradient(90deg, #3182ce, #805ad5); color: #fff; }
      .fab-btn-ghost {
        background: rgba(255,255,255,0.07);
        color: #94a3b8;
        border: 1px solid rgba(255,255,255,0.1);
      }
    `;
    document.head.appendChild(style);
  }

  // ─── State ──────────────────────────────────────────────────────────────────
  let _popoverOpen = false;
  let _latestVersion = '';
  let _currentVersion = '';
  let _notes = '';

  // ─── Render FAB button ───────────────────────────────────────────────────────
  function _renderFAB() {
    if (document.getElementById(FAB_ID)) return;
    _injectStyle();

    const fab = document.createElement('button');
    fab.id = FAB_ID;
    fab.title = 'Update FlowAutoBridge tersedia — klik untuk lihat detail';
    fab.innerHTML = `🔄<span class="fab-dot"></span>`;
    document.body.appendChild(fab);

    fab.addEventListener('click', (e) => {
      e.stopPropagation();
      _popoverOpen ? _closePopover() : _openPopover();
    });
  }

  // ─── Buka popover ───────────────────────────────────────────────────────────
  function _openPopover() {
    _closePopover(true); // hapus dulu jika ada
    _popoverOpen = true;

    const pop = document.createElement('div');
    pop.id = POPOVER_ID;
    pop.innerHTML = `
      <div class="fab-pop-body">
        <div class="fab-pop-header">
          <span class="fab-pop-title">✨ Update FlowAutoBridge Tersedia</span>
          <button class="fab-pop-close" id="fab-pop-close-btn">✕</button>
        </div>
        <div class="fab-version-row">
          <span class="fab-badge fab-badge-old">v${_currentVersion}</span>
          <span class="fab-badge-arrow">→</span>
          <span class="fab-badge fab-badge-new">v${_latestVersion}</span>
        </div>
        ${_notes ? `<div class="fab-notes">${_notes}</div>` : ''}
        <div class="fab-actions">
          <button class="fab-btn fab-btn-primary" id="fab-update-now-btn">Perbarui</button>
          <button class="fab-btn fab-btn-ghost" id="fab-later-btn">Nanti</button>
        </div>
      </div>
    `;
    document.body.appendChild(pop);

    document.getElementById('fab-pop-close-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      _closePopover();
    });
    document.getElementById('fab-update-now-btn').addEventListener('click', () => {
      window.open('https://github.com/intisariapps-com/intisariShortMovie/releases/latest', '_blank');
      _closePopover();
    });
    document.getElementById('fab-later-btn').addEventListener('click', () => {
      _closePopover();
      _dismiss();
    });
  }

  // ─── Tutup popover ──────────────────────────────────────────────────────────
  function _closePopover(immediate = false) {
    _popoverOpen = false;
    const pop = document.getElementById(POPOVER_ID);
    if (!pop) return;
    if (immediate) { pop.remove(); return; }
    pop.classList.add('fab-closing');
    pop.addEventListener('animationend', () => pop.remove(), { once: true });
  }

  // ─── Klik di luar → tutup popover ───────────────────────────────────────────
  document.addEventListener('click', (e) => {
    if (_popoverOpen && !e.target.closest(`#${POPOVER_ID}`) && !e.target.closest(`#${FAB_ID}`)) {
      _closePopover();
    }
  });

  // ─── Dismiss selama 24 jam ──────────────────────────────────────────────────
  function _dismiss() {
    chrome.storage.local.set({ [DISMISS_KEY]: Date.now() });
    // Hapus FAB juga setelah user pilih "Nanti"
    const fab = document.getElementById(FAB_ID);
    if (fab) {
      fab.style.animation = 'fab-pop-out 0.25s ease-in forwards';
      fab.addEventListener('animationend', () => fab.remove(), { once: true });
    }
  }

  // ─── Cek 24-jam dismiss ─────────────────────────────────────────────────────
  function _shouldShow(cb) {
    chrome.storage.local.get([DISMISS_KEY], (res) => {
      const elapsed = Date.now() - (res[DISMISS_KEY] || 0);
      cb(elapsed > 24 * 60 * 60 * 1000);
    });
  }

  // ─── Init: cek storage saat halaman dimuat ───────────────────────────────────
  chrome.storage.local.get(['fab_update_available', 'fab_latest_version', 'fab_current_version', 'fab_update_notes'], (res) => {
    if (res.fab_update_available && res.fab_latest_version) {
      _shouldShow((show) => {
        if (!show) return;
        _latestVersion  = res.fab_latest_version;
        _currentVersion = res.fab_current_version || '?';
        _notes          = res.fab_update_notes || '';
        _renderFAB();
      });
    }
  });

  // ─── Terima pesan real-time dari background.js ───────────────────────────────
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'fab_show_update_banner') {
      _shouldShow((show) => {
        if (!show) return;
        _latestVersion  = message.latestVersion;
        _currentVersion = message.currentVersion || '?';
        _notes          = message.notes || '';
        _renderFAB();
      });
    }
  });

})();
