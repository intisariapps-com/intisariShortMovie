// ==============================================================================
// 📁 FILE   : content_flow_dom.js (Lokasi: extension/content_flow_dom.js)
// 📝 FUNGSI : Modul robotik interaksi DOM Google Flow (Input prompt, Button submit,
//             Physical click, dan Keyboard enter).
// ==============================================================================

(function(root) {
  function log(msg, level = 'INFO') {
    console.log(`[FlowAutoBridge:DOM] ${msg}`);
  }

  function querySelectorAllDeep(selector, rootNode = document) {
    let results = [];
    try { results = Array.from(rootNode.querySelectorAll(selector)); } catch (e) {}
    try {
      const allElements = rootNode.querySelectorAll('*');
      for (const el of allElements) {
        if (el.shadowRoot) results = results.concat(querySelectorAllDeep(selector, el.shadowRoot));
      }
    } catch (e) {}
    return results;
  }

  function focusEditor(el) {
    if (!el) return;
    try {
      el.focus();
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) { try { el.focus(); } catch (err) {} }
  }

  function getPromptText(el) {
    if (!el) return '';
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return (el.value || '').trim();
    return (el.innerText || el.textContent || '').trim();
  }

  function fillPromptInput(element, text) {
    if (!element) return false;
    element.focus();
    try { element.click(); } catch (e) {}

    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
      try { element.select(); } catch (e) {}
    }

    // 1. execCommand approach
    let inserted = false;
    try {
      document.execCommand('selectAll', false, null);
      inserted = document.execCommand('insertText', false, text);
      log(`Hasil execCommand insertText: ${inserted}`);
    } catch (e) {
      log(`execCommand gagal: ${e.message}`, 'WARN');
      inserted = false;
    }

    // 2. Fallback prototype value setter
    const currentVal = element.value || element.innerText || '';
    if (!inserted || (!currentVal.includes(text.substring(0, 10)))) {
      log('Mencoba fallback prototype setter & innerText...');
      if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
        const prototype = element.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        const valueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        if (valueSetter) valueSetter.call(element, text);
        else element.value = text;
      } else if (element.isContentEditable) {
        element.innerText = text;
      } else {
        element.value = text;
      }
    }

    // 3. Dispatch synthetic events
    ['beforeinput', 'input', 'change'].forEach(eventType => {
      try {
        element.dispatchEvent(new InputEvent(eventType, { bubbles: true, cancelable: true, composed: true, inputType: 'insertText', data: text }));
      } catch (e) {
        element.dispatchEvent(new Event(eventType, { bubbles: true, cancelable: true, composed: true }));
      }
    });
    element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, composed: true, key: ' ', code: 'Space' }));
    element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, cancelable: true, composed: true, key: ' ', code: 'Space' }));

    try { focusEditor(element); } catch (e) {}
    const finalVal = element.value || element.innerText || '';
    log(`Status injeksi prompt: ${finalVal.length > 0 ? 'BERHASIL' : 'KOSONG'} ("${finalVal.substring(0, 35)}...")`);
    return true;
  }

  function findPromptTextarea() {
    const candidates = querySelectorAllDeep('input, textarea, [contenteditable="true"], [role="textbox"]');
    log(`Mendeteksi ${candidates.length} calon elemen input di halaman...`);

    const visibleCandidates = candidates.filter(el => {
      if (el.offsetParent === null && el.offsetWidth === 0 && el.offsetHeight === 0) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < 80 || rect.height < 15) return false;
      return rect.top > (window.innerHeight * 0.30);
    });

    log(`Ditemukan ${visibleCandidates.length} elemen input yang tampak di paruh bawah layar.`);

    const keywords = ['buat', 'ingin', 'prompt', 'describe', 'create', 'tulis', 'ketik', 'apa yang', 'image'];
    for (const el of visibleCandidates) {
      const placeholder = (el.getAttribute('placeholder') || '').toLowerCase();
      const aria = (el.getAttribute('aria-label') || '').toLowerCase();
      const testId = (el.getAttribute('data-testid') || '').toLowerCase();
      if (keywords.some(k => placeholder.includes(k) || aria.includes(k) || testId.includes(k))) {
        log(`✓ Elemen prompt cocok berdasarkan kata kunci: "${placeholder || aria}" (<${el.tagName}>)`);
        return el;
      }
    }

    if (visibleCandidates.length > 0) {
      visibleCandidates.sort((a, b) => {
        const rectA = a.getBoundingClientRect();
        const rectB = b.getBoundingClientRect();
        return (rectB.width * rectB.height) - (rectA.width * rectA.height);
      });
      const chosen = visibleCandidates[0];
      log(`✓ Elemen prompt dipilih berdasarkan luas area (<${chosen.tagName}>, ${Math.round(chosen.getBoundingClientRect().width)}x${Math.round(chosen.getBoundingClientRect().height)}px)`);
      return chosen;
    }

    const legacySelectors = ['textarea[placeholder*="buat" i]', 'textarea[placeholder*="prompt" i]', 'input[placeholder*="buat" i]', 'input[placeholder*="ingin" i]', 'div[contenteditable="true"]', 'textarea'];
    for (const sel of legacySelectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) {
        log(`⚠️ Menggunakan elemen fallback: <${el.tagName}>`);
        return el;
      }
    }

    log('❌ Tidak ada elemen input prompt yang terdeteksi di tab ini!', 'ERROR');
    return null;
  }

  function isModelOrUtilityButton(btn) {
    const text = (btn.innerText || btn.textContent || '').toLowerCase().trim();
    const aria = (btn.getAttribute('aria-label') || '').toLowerCase().trim();
    const title = (btn.getAttribute('title') || '').toLowerCase().trim();
    const cls = (btn.className || '').toString().toLowerCase().trim();
    const combined = `${text} ${aria} ${title} ${cls}`;
    const excludeWords = [
      'banana', 'nano', 'agen', 'agent', '1:1', '16:9', '9:16', 'aspect', 'model',
      'add', 'tambah', 'unggah', 'upload', 'close', 'clear', 'cancel', 'tutup', 'batal', 'hapus', 'reset', 'remove', 'delete',
      'style', 'gaya', 'camera', 'kamera'
    ];
    return excludeWords.some(w => combined.includes(w));
  }

  function findGenerateButton(promptElement) {
    if (!promptElement) return null;
    const pRect = promptElement.getBoundingClientRect();

    let container = promptElement.parentElement;
    let promptContainer = null;
    let allCandidateBtns = [];

    for (let depth = 0; depth < 5 && container; depth++) {
      const btns = Array.from(container.querySelectorAll('button, [role="button"]'));
      if (btns.length > 0) {
        allCandidateBtns = allCandidateBtns.concat(btns);
        if (!promptContainer && btns.length >= 2) promptContainer = container;
      }
      container = container.parentElement;
    }

    const uniqueBtns = Array.from(new Set(allCandidateBtns)).filter(btn => {
      if (btn === promptElement) return false;
      const rect = btn.getBoundingClientRect();
      if (rect.width < 16 || rect.height < 16 || btn.offsetParent === null) return false;
      if (rect.top < window.innerHeight * 0.50) return false;
      if (Math.abs(rect.top - pRect.top) > 130) return false;
      return true;
    });

    const nonUtilityBtns = uniqueBtns.filter(btn => !isModelOrUtilityButton(btn));

    // TIER 1: Tombol dengan metadata submit / arrow / kirim / east / forward
    const arrowKeywords = ['arrow', 'send', 'kirim', 'submit', 'east', 'forward', 'buat', 'generate'];
    const explicitSubmit = nonUtilityBtns.filter(btn => {
      const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
      const title = (btn.getAttribute('title') || '').toLowerCase();
      const text = (btn.innerText || btn.textContent || '').toLowerCase().trim();
      return arrowKeywords.some(k => aria.includes(k) || title.includes(k) || text.includes(k));
    });
    if (explicitSubmit.length > 0) {
      explicitSubmit.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
      const target = explicitSubmit[0];
      log(`✓ [TIER-1] Tombol submit ditemukan via metadata panah di X=${Math.round(target.getBoundingClientRect().right)} (<${target.tagName}>)`);
      return target;
    }

    // TIER 2: Tombol yang memuat elemen SVG di posisi PALING KANAN container
    const svgBtns = nonUtilityBtns.filter(btn => btn.querySelector('svg') !== null);
    if (svgBtns.length > 0) {
      svgBtns.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
      const target = svgBtns[0];
      log(`✓ [TIER-2] Tombol submit (SVG paling kanan) ditemukan pada X=${Math.round(target.getBoundingClientRect().right)} (<${target.tagName}>)`);
      return target;
    }

    // TIER 3: Geometri presisi di sudut kanan bawah container (tempat tombol submit Flow berada)
    if (promptContainer) {
      const cRect = promptContainer.getBoundingClientRect();
      const testPoints = [{ x: cRect.right - 25, y: cRect.bottom - 25 }, { x: cRect.right - 35, y: cRect.bottom - 28 }, { x: cRect.right - 50, y: cRect.bottom - 30 }];
      for (const pt of testPoints) {
        const elAtPoint = document.elementFromPoint(pt.x, pt.y);
        if (elAtPoint) {
          const btn = elAtPoint.closest('button, [role="button"]') || elAtPoint;
          if (btn && btn !== promptElement && !isModelOrUtilityButton(btn)) {
            log(`✓ [TIER-3] Tombol submit ditemukan via elementFromPoint di X=${Math.round(btn.getBoundingClientRect().right)}`);
            return btn;
          }
        }
      }
    }

    // TIER 4: Fallback tombol non-utility PALING KANAN
    if (nonUtilityBtns.length > 0) {
      nonUtilityBtns.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
      const target = nonUtilityBtns[0];
      log(`✓ [TIER-4] Tombol submit fallback paling kanan di X=${Math.round(target.getBoundingClientRect().right)} (<${target.tagName}>)`);
      return target;
    }

    log('⚠️ Tombol generate fisik tidak ditemukan, mengandalkan Enter keyboard!');
    return null;
  }

  function dispatchPhysicalClick(btn) {
    if (!btn) return;
    try {
      btn.removeAttribute('disabled');
      btn.setAttribute('aria-disabled', 'false');
      btn.classList.remove('disabled');
    } catch (e) {}

    const rect = btn.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    const pointerProps = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: cx, clientY: cy, screenX: cx, screenY: cy, pointerId: 1, pointerType: 'mouse', isPrimary: true, pressure: 0.5
    };

    ['pointerover', 'pointerenter', 'pointerdown'].forEach(type => {
      try { btn.dispatchEvent(new PointerEvent(type, pointerProps)); } catch (e) {}
    });

    const mouseProps = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: cx, clientY: cy, button: 0, buttons: 1
    };
    try { btn.dispatchEvent(new MouseEvent('mousedown', mouseProps)); } catch (e) {}
    try { btn.focus(); } catch (e) {}
    try { btn.dispatchEvent(new PointerEvent('pointerup', pointerProps)); } catch (e) {}
    ['mouseup', 'click'].forEach(type => {
      try { btn.dispatchEvent(new MouseEvent(type, { ...mouseProps, buttons: 0 })); } catch (e) {}
    });
    const innerSvg = btn.querySelector('svg');
    if (innerSvg) { try { innerSvg.dispatchEvent(new MouseEvent('click', { ...mouseProps, buttons: 0 })); } catch (e) {} }
    try { btn.click(); } catch (e) {}
    try {
      chrome.runtime.sendMessage({ type: 'CDP_CLICK', x: cx, y: cy }, (resp) => {
        if (resp && resp.success) log(`✓ CDP Click pada (${Math.round(cx)}, ${Math.round(cy)})`);
      });
    } catch (e) {}
  }

  function dispatchKeyboardEnter(promptElement) {
    if (!promptElement) return;
    focusEditor(promptElement);
    const keyOpts = { bubbles: true, cancelable: true, composed: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13, view: window };
    const active = document.activeElement || promptElement;
    ['keydown', 'keypress', 'keyup'].forEach(type => {
      try { active.dispatchEvent(new KeyboardEvent(type, keyOpts)); } catch (e) {}
      try { promptElement.dispatchEvent(new KeyboardEvent(type, keyOpts)); } catch (e) {}
    });
    try { chrome.runtime.sendMessage({ type: 'CDP_ENTER' }); } catch (e) {}
  }

  function clearPromptInput(element) {
    if (!element) return;
    try {
      focusEditor(element);
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        element.value = '';
      } else if (element.isContentEditable) {
        element.innerText = '';
      }
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      ['beforeinput', 'input', 'change'].forEach(type => {
        try { element.dispatchEvent(new Event(type, { bubbles: true })); } catch (e) {}
      });
    } catch (e) {}
  }

  async function triggerGenerate(promptElement, targetBtn) {
    try { window.focus(); } catch (e) {}
    try { focusEditor(promptElement); } catch (e) {}

    for (let attempt = 1; attempt <= 4; attempt++) {
      log(`Mengirim aksi submit Google Flow (Percobaan ${attempt}/4)...`);

      const btn = targetBtn || findGenerateButton(promptElement);
      if (btn && btn.offsetParent !== null) {
        dispatchPhysicalClick(btn);
      }

      dispatchKeyboardEnter(promptElement);
      await new Promise(r => setTimeout(r, 800));

      const textAfter = getPromptText(promptElement);
      if (textAfter.length <= 5) {
        log('✓ Verifikasi sukses: Input prompt berhasil ter-submit dan dibersihkan oleh Google Flow.');
        return true;
      }

      log(`⚠️ Input masih berisi teks ("${textAfter.substring(0, 25)}..."). Mengulang percobaan submit...`);
      await new Promise(r => setTimeout(r, 600));
    }

    const finalCheck = getPromptText(promptElement);
    const isOk = finalCheck.length <= 5;
    log(`Status akhir trigger generate: ${isOk ? 'BERHASIL' : 'GAGAL (Teks masih tertinggal di editor)'}`);
    return isOk;
  }

  // Daftarkan ke global root
  root.querySelectorAllDeep = querySelectorAllDeep;
  root.focusEditor = focusEditor;
  root.getPromptText = getPromptText;
  root.fillPromptInput = fillPromptInput;
  root.findPromptTextarea = findPromptTextarea;
  root.isModelOrUtilityButton = isModelOrUtilityButton;
  root.findGenerateButton = findGenerateButton;
  root.dispatchPhysicalClick = dispatchPhysicalClick;
  root.dispatchKeyboardEnter = dispatchKeyboardEnter;
  root.clearPromptInput = clearPromptInput;
  root.triggerGenerate = triggerGenerate;

})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
