// ==============================================================================
// 📁 FILE   : extension/popup_standalone_studio.js
// 📝 FUNGSI : Modular Controller untuk UI/UX Standalone Studio & CapCut Injector
//             (Mematuhi Batas 1.000 Baris & Prinsip Anti-Garis Patah)
// ==============================================================================

(function(global) {
  'use strict';

  let standaloneProject = null;
  let standaloneAudioFile = null;
  let standaloneAudioBlob = null;
  let updateStatusFn = null;

  /**
   * Helper untuk memperbarui status baris tunggal & log drawer.
   */
  function logStatus(msg) {
    if (typeof updateStatusFn === 'function') {
      updateStatusFn(msg);
    } else {
      console.log(`[StandaloneStudio] ${msg}`);
    }
  }

  /**
   * Membuka popup ekstensi dalam satu tab penuh peramban agar dialog
   * File System Access API (showDirectoryPicker) 100% stabil tanpa risiko auto-close.
   */
  function openInFullTab() {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.runtime) {
      chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') });
    } else {
      window.open(window.location.href, '_blank');
    }
  }

  /**
   * Memperbarui visual kartu koneksi CapCut Desktop dengan dukungan Multi-Tier Persistence (SRS-FAB-057).
   * Mendukung status Granted, Prompt (Tersimpan / Siap Aktifkan), dan Unpaired.
   */
  async function refreshCapCutStatus(uiElements) {
    const { capcutStatusBadge, capcutPathPreview, btnPairCapcut } = uiElements;
    if (!global.CapCutDraftWriter) return;

    // Baca cache nama folder dari chrome.storage.local untuk rendering instan
    let cachedFolderName = '';
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        const stored = await new Promise(r => chrome.storage.local.get(['capcutFolderName'], r));
        cachedFolderName = stored && stored.capcutFolderName ? stored.capcutFolderName : '';
      } catch (_) {}
    }

    try {
      const handle = await global.CapCutDraftWriter.getStoredDirectoryHandle();
      if (handle) {
        const folderName = handle.name || cachedFolderName || 'CapCut Drafts';
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ capcutFolderName: folderName });
        }

        // Cek izin secara PASIF (hanya queryPermission, aman dari error User Activation)
        const permStatus = await global.CapCutDraftWriter.queryDirectoryPermission(handle, true);

        if (permStatus === 'granted') {
          // Status 1: GRANTED (Izin aktif penuh)
          if (capcutStatusBadge) {
            capcutStatusBadge.textContent = '✓ Terhubung';
            capcutStatusBadge.className = 'badge badge-online';
          }
          if (capcutPathPreview) {
            capcutPathPreview.textContent = folderName;
            capcutPathPreview.title = 'Direktori draf CapCut aktif & siap digunakan';
            capcutPathPreview.style.color = '#34d399';
          }
          if (btnPairCapcut) {
            btnPairCapcut.dataset.mode = 'change';
            btnPairCapcut.innerHTML = `
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
              <span>Ganti Direktori Draf</span>
            `;
            btnPairCapcut.className = 'btn btn-secondary';
          }
          return;
        } else {
          // Status 2: PROMPT (Folder tersimpan di IndexedDB, perlu user gesture untuk aktivasi 1-klik)
          if (capcutStatusBadge) {
            capcutStatusBadge.textContent = '⚡ Tersimpan (Klik Aktifkan)';
            capcutStatusBadge.className = 'badge badge-active';
          }
          if (capcutPathPreview) {
            capcutPathPreview.textContent = `${folderName} (Tersimpan)`;
            capcutPathPreview.title = 'Folder tersimpan. Klik untuk mengaktifkan izin tanpa membuka File Explorer.';
            capcutPathPreview.style.color = '#38bdf8';
          }
          if (btnPairCapcut) {
            btnPairCapcut.dataset.mode = 'activate';
            btnPairCapcut.innerHTML = `
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
              <span>Aktifkan Izin '${folderName}'</span>
            `;
            btnPairCapcut.className = 'btn btn-primary';
          }
          return;
        }
      }
    } catch (_) {}

    // Status 3: UNPAIRED (Belum pernah dipasangkan)
    if (capcutStatusBadge) {
      capcutStatusBadge.textContent = 'Belum Terhubung';
      capcutStatusBadge.className = 'badge badge-warning';
    }
    if (capcutPathPreview) {
      capcutPathPreview.textContent = cachedFolderName ? `${cachedFolderName} (Perlu Dipilih Ulang)` : 'Pilih folder com.lveditor.draft di komputer Anda';
      capcutPathPreview.style.color = '#94a3b8';
    }
    if (btnPairCapcut) {
      btnPairCapcut.dataset.mode = 'pair';
      btnPairCapcut.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
        <span>Hubungkan Folder CapCut</span>
      `;
      btnPairCapcut.className = 'btn btn-primary';
    }
  }

  /**
   * Memperbarui visual field input Groq Whisper API Key.
   */
  async function refreshGroqKeyUI(uiElements) {
    const { groqApiKeyInput, groqKeyStatus } = uiElements;
    if (!global.GroqWhisperClient) return;

    const key = await global.GroqWhisperClient.getStoredApiKey();
    if (key) {
      if (groqApiKeyInput) groqApiKeyInput.value = key;
      if (groqKeyStatus) {
        groqKeyStatus.textContent = '✓ Tersimpan';
        groqKeyStatus.className = 'badge badge-online';
      }
    } else {
      if (groqKeyStatus) {
        groqKeyStatus.textContent = 'Belum Diisi';
        groqKeyStatus.className = 'badge badge-warning';
      }
    }
  }

  /**
   * Mengonversi DataURL kembali menjadi objek File untuk pemulihan audio lintas sesi (v2.6.3).
   */
  function dataUrlToFile(dataUrl, filename) {
    try {
      const arr = String(dataUrl || '').split(',');
      if (arr.length < 2) return null;
      const mimeMatch = arr[0].match(/:(.*?);/);
      const mime = mimeMatch ? mimeMatch[1] : 'audio/mpeg';
      const bstr = atob(arr[1]);
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      while (n--) u8arr[n] = bstr.charCodeAt(n);
      return new File([u8arr], filename || 'narasi_studio.mp3', { type: mime });
    } catch (_) {
      return null;
    }
  }

  /**
   * Menyamakan nama berkas audio mengikuti judul JSON / folder proyek (<projectFolder>.<ext>),
   * menyimpannya ke chrome.storage.local (tahan tutup-buka ekstensi), dan mengunduhnya otomatis
   * ke Downloads/intisariShortMovie/<projectFolder>/<projectFolder>.<ext> (v2.6.3).
   */
  function syncAndDownloadAudioToProjectFolder(rawAudioFile, projectFolder) {
    if (!rawAudioFile) return null;
    const origName = rawAudioFile.name || 'narasi.mp3';
    const extMatch = origName.match(/\.(mp3|wav|m4a|ogg|aac|flac)$/i);
    const audioExt = extMatch ? extMatch[1].toLowerCase() : 'mp3';
    const cleanFolder = (projectFolder || 'Proyek_ShortMovie').trim();
    const renamedFileName = `${cleanFolder}.${audioExt}`;

    let renamedFile = rawAudioFile;
    try {
      renamedFile = new File([rawAudioFile], renamedFileName, { type: rawAudioFile.type || 'audio/mpeg' });
    } catch (_) {
      renamedFile = rawAudioFile;
    }
    standaloneAudioFile = renamedFile;

    try {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result;
        if (!dataUrl) return;
        chrome.storage.local.set({
          activeProjectAudioDataUrl: dataUrl,
          activeProjectAudioFileName: renamedFileName,
          activeProjectAudioExt: audioExt
        });
        chrome.runtime.sendMessage({
          action: 'download_project_audio',
          dataUrl: dataUrl,
          filename: renamedFileName,
          projectFolder: cleanFolder,
          subfolder: 'intisariShortMovie'
        }, () => {
          const _ignored = chrome.runtime.lastError;
          logStatus(`✓ Audio disamakan & disimpan ke Downloads/intisariShortMovie/${cleanFolder}/${renamedFileName}`);
        });
      };
      reader.readAsDataURL(renamedFile);
    } catch (e) {
      console.warn('Gagal menyinkronkan audio ke folder proyek:', e);
    }
    return renamedFile;
  }

  /**
   * Menangani pemrosesan berkas yang diunggah / ditarik ke Dropzone.
   */
  async function processDroppedFiles(fileList, uiElements) {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;

    let jsonFile = null;
    let audioFile = null;

    for (const f of files) {
      const name = (f.name || '').toLowerCase();
      if (name.endsWith('.json') && !jsonFile) {
        jsonFile = f;
      } else if (global.AudioResampler && global.AudioResampler.isAudioFile(f) && !audioFile) {
        audioFile = f;
      }
    }

    if (jsonFile) {
      try {
        const text = await jsonFile.text();
        const parsed = JSON.parse(text);
        const rawScenes = Array.isArray(parsed.scenes) ? parsed.scenes : (Array.isArray(parsed) ? parsed : (parsed.storyboard || []));
        if (rawScenes.length === 0) {
          logStatus('Peringatan: Berkas JSON tidak memuat adegan.');
        } else {
          const title = parsed.title || parsed.project_title || jsonFile.name.replace(/\.json$/i, '');
          const rawTitle = title || 'Proyek';
          const cleanTitle = String(rawTitle).replace(/\(?part\s*\d+\)?/gi, '').replace(/[^\w\s\-]+/g, ' ').trim().split(/\s+/).slice(0, 5).join('_') || 'Proyek';
          
          // Pertahankan hash yang sudah ada jika mengimpor berkas bertag (misal: Proyek_txaw.json)
          let projectFolder = '';
          const existingHashMatch = cleanTitle.match(/^(.+)_([a-z0-9]{4})$/i) || jsonFile.name.replace(/\.json$/i, '').match(/^(.+)_([a-z0-9]{4})$/i);
          if (existingHashMatch) {
            projectFolder = `${existingHashMatch[1]}_${existingHashMatch[2].toLowerCase()}`;
          } else {
            const randHash = Math.random().toString(36).substring(2, 6);
            projectFolder = `${cleanTitle}_${randHash}`;
          }

          // Normalisasi COVER & ADEGAN_01..N untuk antrean Google Flow & CapCut (v2.6.5)
          const normalizedScenes = [];
          const topCoverPrompt = String(parsed.cover_prompt || parsed.thumbnail_prompt || '').trim();
          const hasCoverInArray = rawScenes.some(sc => String(sc.id || '').toUpperCase() === 'COVER');
          if (topCoverPrompt && !hasCoverInArray) {
            normalizedScenes.push({
              id: 'COVER',
              narrative: '',
              image_prompt: topCoverPrompt,
              prompt_flow: topCoverPrompt
            });
          }
          let realCounter = 0;
          rawScenes.forEach((sc) => {
            const rawId = String(sc.id || '').toUpperCase();
            const isCover = rawId === 'COVER';
            if (!isCover) realCounter++;
            const normId = isCover ? 'COVER' : `ADEGAN_${String(realCounter).padStart(2, '0')}`;
            const imgPrompt = String(sc.image_prompt || sc.prompt_flow || sc.prompt || '').trim();
            normalizedScenes.push({
              ...sc,
              id: normId,
              image_prompt: imgPrompt,
              prompt_flow: imgPrompt
            });
          });

          let alignedInit = { scenes: normalizedScenes, totalDurationUs: 0, coverOffset: 0.0 };
          if (global.StoryboardAligner) {
            try {
              alignedInit = global.StoryboardAligner.alignStoryboardWithWhisper(normalizedScenes, [], 0);
            } catch (_) {}
          }
          standaloneProject = {
            title,
            projectFolder,
            scenes: alignedInit.allScenesWithCover || alignedInit.scenes || normalizedScenes,
            totalDurationUs: alignedInit.totalDurationUs || 0,
            coverOffset: alignedInit.coverOffset || 0.0,
            audioFileName: ''
          };
          chrome.storage.local.set({ 
            activeProjectFolder: projectFolder, 
            latestActiveStoryboardTitle: title,
            storyboardQueue: standaloneProject.scenes,
            activeProjectTotalDurationUs: standaloneProject.totalDurationUs,
            activeIndex: -1,
            automationRunning: false,
            renderedSceneUrls: {},
            flowExecutionState: {
              text: `✓ ${standaloneProject.scenes.length} prompt dimuat dari ${jsonFile.name}. Siap mulai!`,
              status: 'idle',
              allCompleted: false
            }
          });
          logStatus(`✓ Naskah dimuat: ${title} [${projectFolder}] (${standaloneProject.scenes.length} adegan).`);

          // Auto-download salinan naskah JSON ke subfolder proyek baru (SRS-FAB-058 / v2.6.3)
          try {
            const jsonBlob = new Blob([text], { type: 'application/json' });
            const reader = new FileReader();
            reader.onloadend = () => {
              chrome.runtime.sendMessage({
                action: 'download_storyboard_json',
                dataUrl: reader.result,
                filename: `${projectFolder}.json`,
                projectFolder: projectFolder,
                subfolder: 'intisariShortMovie'
              }, () => {
                const _ignored = chrome.runtime.lastError;
                logStatus(`✓ Naskah JSON tersimpan ke Downloads/intisariShortMovie/${projectFolder}/${projectFolder}.json`);
              });
            };
            reader.readAsDataURL(jsonBlob);
          } catch (e) {
            console.warn("Gagal auto-download naskah JSON:", e);
          }

          // Jika audio sudah diunggah lebih dulu sebelum JSON, sinkronkan namanya mengikuti projectFolder JSON baru ini
          if (!audioFile && standaloneAudioFile) {
            syncAndDownloadAudioToProjectFolder(standaloneAudioFile, projectFolder);
            standaloneProject.audioFileName = standaloneAudioFile.name;
          }
        }
      } catch (e) {
        logStatus(`Gagal membaca JSON: ${e.message}`);
      }
    }

    if (audioFile) {
      let targetFolder = standaloneProject && standaloneProject.projectFolder ? standaloneProject.projectFolder : '';
      if (!targetFolder && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        try {
          const st = await new Promise(r => chrome.storage.local.get(['activeProjectFolder'], r));
          targetFolder = st && st.activeProjectFolder ? st.activeProjectFolder : '';
        } catch (_) {}
      }
      if (!targetFolder) targetFolder = audioFile.name.replace(/\.[^.]+$/, '');
      const syncedAudio = syncAndDownloadAudioToProjectFolder(audioFile, targetFolder);
      if (standaloneProject && syncedAudio) {
        standaloneProject.audioFileName = syncedAudio.name;
      }
      logStatus(`✓ Audio narasi disamakan & disimpan: ${syncedAudio ? syncedAudio.name : audioFile.name}`);
    }

    // Perbarui Tampilan Proyek Aktif
    const {
      standaloneProjectCard,
      standaloneProjectTitle,
      standaloneSceneCount,
      standaloneAudioInfo,
      standaloneAlignBadge
    } = uiElements;

    if (standaloneProject) {
      if (standaloneProjectCard) standaloneProjectCard.style.display = 'block';
      if (standaloneProjectTitle) standaloneProjectTitle.textContent = standaloneProject.title;
      if (standaloneSceneCount) standaloneSceneCount.textContent = `${standaloneProject.scenes.length} Adegan`;
      if (standaloneAudioInfo) {
        standaloneAudioInfo.textContent = standaloneAudioFile
          ? `${standaloneAudioFile.name}`
          : 'Belum Ada Audio (Estimasi 3.5s per adegan)';
      }

      // Auto-Resample & Alignment
      if (standaloneAudioFile && global.AudioResampler) {
        try {
          logStatus('Meresampling audio narasi ke 16kHz Mono...');
          if (standaloneAlignBadge) {
            standaloneAlignBadge.textContent = 'Menyelaraskan...';
            standaloneAlignBadge.className = 'badge badge-active';
          }

          const resampled = await global.AudioResampler.resampleAudioTo16kMono(standaloneAudioFile);
          standaloneAudioBlob = resampled.blob;
          if (standaloneAudioInfo) {
            standaloneAudioInfo.textContent = `${standaloneAudioFile.name} (${global.AudioResampler.formatDuration(resampled.duration)})`;
          }

          const apiKey = global.GroqWhisperClient ? await global.GroqWhisperClient.getStoredApiKey() : '';
          if (apiKey && global.GroqWhisperClient && global.StoryboardAligner) {
            logStatus('Mengirim audio ke Groq Whisper API (word-timestamps)...');
            const whisperResult = await global.GroqWhisperClient.transcribeAudio(standaloneAudioBlob, apiKey);
            logStatus('Menyelaraskan stempel waktu adegan & subtitel...');
            const aligned = global.StoryboardAligner.alignStoryboardWithWhisper(
              standaloneProject.scenes,
              whisperResult.words,
              whisperResult.duration || resampled.duration
            );
            standaloneProject.scenes = aligned.allScenesWithCover || aligned.scenes;
            standaloneProject.totalDurationUs = aligned.totalDurationUs;
            standaloneProject.coverOffset = aligned.coverOffset;
            chrome.storage.local.set({
              storyboardQueue: standaloneProject.scenes,
              activeProjectTotalDurationUs: standaloneProject.totalDurationUs
            });

            if (standaloneAlignBadge) {
              standaloneAlignBadge.textContent = '✓ Presisi Terkalibrasi';
              standaloneAlignBadge.className = 'badge badge-online';
            }
            logStatus('✓ Stempel waktu presisi mikrodetik terkalibrasi penuh!');
          } else if (global.StoryboardAligner) {
            const aligned = global.StoryboardAligner.alignStoryboardWithWhisper(
              standaloneProject.scenes,
              [],
              resampled.duration
            );
            standaloneProject.scenes = aligned.allScenesWithCover || aligned.scenes;
            standaloneProject.totalDurationUs = aligned.totalDurationUs;
            chrome.storage.local.set({
              storyboardQueue: standaloneProject.scenes,
              activeProjectTotalDurationUs: standaloneProject.totalDurationUs
            });
            if (standaloneAlignBadge) {
              standaloneAlignBadge.textContent = 'Proporsional';
              standaloneAlignBadge.className = 'badge badge-active';
            }
            logStatus('✓ Linimasa proporsional dibuat (Simpan Groq Key untuk sinkronisasi kata).');
          }
        } catch (err) {
          logStatus(`Penyelarasan audio: ${err.message || err}`);
          if (standaloneAlignBadge) {
            standaloneAlignBadge.textContent = 'Manual';
            standaloneAlignBadge.className = 'badge badge-offline';
          }
        }
      }
    }
  }

  /**
   * Mendeteksi OS pengguna dan mengembalikan konfigurasi path draf CapCut default (SRS-FAB-054).
   */
  function getCapCutDefaultDirectoryHint() {
    const isMac = (typeof navigator !== 'undefined' && navigator.userAgent)
      ? /macintosh|mac os x/i.test(navigator.userAgent)
      : false;

    if (isMac) {
      return {
        os: 'mac',
        label: '💡 Tips macOS (Finder):',
        path: '~/Movies/CapCut/User Data/Projects/com.lveditor.draft'
      };
    }
    return {
      os: 'win',
      label: '💡 Tips Windows (Address Bar Explorer):',
      path: '%LOCALAPPDATA%\\CapCut\\User Data\\Projects\\com.lveditor.draft'
    };
  }

  /**
   * Mengatur tampilan panduan path OS dan tombol salin ke papan klip.
   */
  function setupCapCutPathHint(uiElements) {
    const { capcutOsLabel, capcutOsHintPath, btnCopyCapcutPath } = uiElements;
    const hint = getCapCutDefaultDirectoryHint();

    if (capcutOsLabel) capcutOsLabel.textContent = hint.label;
    if (capcutOsHintPath) capcutOsHintPath.textContent = hint.path;

    if (btnCopyCapcutPath) {
      btnCopyCapcutPath.addEventListener('click', async () => {
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(hint.path);
            const prevText = btnCopyCapcutPath.textContent;
            btnCopyCapcutPath.textContent = '✓ Tersalin!';
            btnCopyCapcutPath.style.color = '#34d399';
            btnCopyCapcutPath.style.borderColor = '#34d399';
            logStatus(`Path CapCut disalin: ${hint.path}`);
            setTimeout(() => {
              btnCopyCapcutPath.textContent = prevText;
              btnCopyCapcutPath.style.color = '#38bdf8';
              btnCopyCapcutPath.style.borderColor = 'rgba(56, 189, 248, 0.4)';
            }, 2500);
          } else {
            logStatus(`Path CapCut: ${hint.path}`);
          }
        } catch (err) {
          logStatus(`Gagal menyalin path: ${err.message || err}`);
        }
      });
    }
  }

  /**
   * Menginspeksi struktur folder secara cerdas (Smart Directory Heuristic) (SRS-FAB-055).
   * Memvalidasi folder draf CapCut tanpa membatasi nama folder secara kaku.
   */
  async function inspectCapCutDirectoryStructure(dirHandle) {
    if (!dirHandle) return { isValid: false, message: 'Direktori tidak valid.' };

    try {
      // 1. Cek apakah pengguna memilih sub-folder proyek individual (seperti 1029)
      let isSingleProject = false;
      try {
        await dirHandle.getFileHandle('draft_info.json', { create: false });
        isSingleProject = true;
      } catch (_) {}

      try {
        await dirHandle.getFileHandle('draft_content.json', { create: false });
        isSingleProject = true;
      } catch (_) {}

      if (isSingleProject) {
        return {
          isValid: false,
          isSingleProject: true,
          message: `⚠️ Perhatian: Folder '${dirHandle.name}' adalah draf proyek individual. Harap pilih folder induk penyimpanan CapCut tempat proyek draf disimpan.`
        };
      }

      // 2. Cek apakah ada sub-folder 'com.lveditor.draft'
      let hasSubComDraft = false;
      try {
        const sub = await dirHandle.getDirectoryHandle('com.lveditor.draft', { create: false });
        if (sub) hasSubComDraft = true;
      } catch (_) {}

      // 3. Cek apakah ada root_meta_info.json
      let hasRootMeta = false;
      try {
        await dirHandle.getFileHandle('root_meta_info.json', { create: false });
        hasRootMeta = true;
      } catch (_) {}

      return {
        isValid: true,
        hasSubComDraft,
        hasRootMeta,
        message: `✓ Terhubung ke direktori draf CapCut ('${dirHandle.name}')`
      };
    } catch (_) {
      return {
        isValid: true,
        message: `✓ Terhubung ke direktori draf CapCut ('${dirHandle.name}')`
      };
    }
  }

  /**
   * Menginisialisasi seluruh event listener Standalone Studio.
   */
  /**
   * Memulihkan status naskah proyek & audio aktif dari chrome.storage.local saat startup (SRS-FAB-058 / v2.6.3).
   * Mencegah kartu proyek, berkas audio, dan tombol draf CapCut lenyap saat popup ditutup / reload.
   */
  function restoreActiveProjectFromStorage(uiElements) {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.get([
      'storyboardQueue',
      'latestActiveStoryboardTitle',
      'activeProjectFolder',
      'activeProjectTotalDurationUs',
      'activeProjectAudioDataUrl',
      'activeProjectAudioFileName',
      'activeProjectAudioExt'
    ], (data) => {
      const queue = data.storyboardQueue || [];
      const title = data.latestActiveStoryboardTitle || 'Proyek Aktif';
      const projectFolder = data.activeProjectFolder || '';

      if (!standaloneAudioFile && data.activeProjectAudioDataUrl) {
        const ext = data.activeProjectAudioExt || 'mp3';
        const audioName = projectFolder ? `${projectFolder}.${ext}` : (data.activeProjectAudioFileName || 'narasi_studio.mp3');
        const restoredAudio = dataUrlToFile(data.activeProjectAudioDataUrl, audioName);
        if (restoredAudio) standaloneAudioFile = restoredAudio;
      }

      if (queue && queue.length > 0) {
        let restoredScenes = queue;
        let restoredDurationUs = data.activeProjectTotalDurationUs || 0;
        let restoredCoverOffset = 0.0;
        const needsAlign = !restoredDurationUs || queue.some(sc => String(sc.id || '').toUpperCase() !== 'COVER' && !(sc.duration_us > 0));
        if (needsAlign && global.StoryboardAligner) {
          try {
            const aligned = global.StoryboardAligner.alignStoryboardWithWhisper(queue, [], 0);
            restoredScenes = aligned.allScenesWithCover || aligned.scenes || queue;
            restoredDurationUs = aligned.totalDurationUs || 0;
            restoredCoverOffset = aligned.coverOffset || 0.0;
          } catch (_) {}
        }
        const ext = data.activeProjectAudioExt || 'mp3';
        const audioFileName = standaloneAudioFile
          ? standaloneAudioFile.name
          : (data.activeProjectAudioFileName ? (projectFolder ? `${projectFolder}.${ext}` : data.activeProjectAudioFileName) : '');

        standaloneProject = {
          title,
          projectFolder,
          scenes: restoredScenes,
          totalDurationUs: restoredDurationUs,
          coverOffset: restoredCoverOffset,
          audioFileName
        };

        const {
          standaloneProjectCard,
          standaloneProjectTitle,
          standaloneSceneCount,
          standaloneAudioInfo
        } = uiElements;

        if (standaloneProjectCard) standaloneProjectCard.style.display = 'block';
        if (standaloneProjectTitle) standaloneProjectTitle.textContent = title;
        if (standaloneSceneCount) standaloneSceneCount.textContent = `${queue.length} Adegan (Tersimpan)`;
        if (standaloneAudioInfo) {
          standaloneAudioInfo.textContent = standaloneAudioFile
            ? `${standaloneAudioFile.name} (Tersimpan)`
            : (audioFileName ? `${audioFileName} (Tersimpan di Folder Proyek)` : 'Belum Ada Audio (Unggah file .mp3/.wav)');
        }
      }
    });
  }

  /**
   * Mengambil proyek aktif saat ini untuk digunakan lintas tab.
   */
  function getActiveProject() {
    return standaloneProject;
  }

  /**
   * Mengambil berkas audio aktif saat ini untuk digunakan lintas tab.
   */
  function getActiveAudioFile() {
    return standaloneAudioFile;
  }

  function initStandaloneStudio(uiElements, onUpdateStatus) {
    updateStatusFn = onUpdateStatus;
    const {
      btnPairCapcut,
      btnOpenFullTab,
      groqApiKeyInput,
      btnSaveGroqKey,
      btnTogglePassword,
      dropzoneBox,
      filePickerInput,
      btnBrowseFiles,
      btnInjectCapcut,
      btnStandaloneStartFlow
    } = uiElements;

    refreshCapCutStatus(uiElements);
    refreshGroqKeyUI(uiElements);
    setupCapCutPathHint(uiElements);
    restoreActiveProjectFromStorage(uiElements);

    // Inisialisasi Fitur Konversi Folder Proyek Lokal ke Draf CapCut (v2.7.0)
    if (global.PopupFolderConverter && typeof global.PopupFolderConverter.initFolderConverterUI === 'function') {
      global.PopupFolderConverter.initFolderConverterUI({
        btnSelectFolder: document.getElementById('btn-select-project-folder'),
        btnExecuteConvert: document.getElementById('btn-execute-convert-capcut'),
        pathPreview: document.getElementById('convert-folder-path-preview'),
        metaPreview: document.getElementById('convert-folder-meta-preview'),
        statusBar: document.getElementById('convert-status-bar'),
        statusText: document.getElementById('convert-status-text'),
        fallbackPicker: document.getElementById('fallback-folder-picker')
      });
    }

    // Tombol Pop-Out Tab Penuh
    if (btnOpenFullTab) {
      btnOpenFullTab.addEventListener('click', (e) => {
        e.preventDefault();
        openInFullTab();
      });
    }

    // Tombol Buka di Sisi Kanan Layar (Chrome Side Panel)
    const btnOpenSidePanel = document.getElementById('btn-open-side-panel');
    if (btnOpenSidePanel) {
      btnOpenSidePanel.addEventListener('click', (e) => {
        e.preventDefault();
        if (chrome.sidePanel && typeof chrome.sidePanel.open === 'function') {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs[0]) {
              chrome.sidePanel.open({ tabId: tabs[0].id }).then(() => {
                window.close();
              }).catch(() => {});
            }
          });
        }
      });
    }

    // Tombol Hubungkan / Aktifkan Izin / Ganti Folder CapCut
    if (btnPairCapcut) {
      btnPairCapcut.addEventListener('click', async () => {
        if (!global.CapCutDraftWriter) return;
        try {
          // Jika dalam mode aktivasi cepat (folder sudah tersimpan di IndexedDB)
          if (btnPairCapcut.dataset.mode === 'activate') {
            const handle = await global.CapCutDraftWriter.getStoredDirectoryHandle();
            if (handle) {
              logStatus(`Mengaktifkan izin folder '${handle.name}'...`);
              const granted = await global.CapCutDraftWriter.verifyPermission(handle, true);
              if (granted) {
                await refreshCapCutStatus(uiElements);
                logStatus(`✓ Akses direktori draf '${handle.name}' berhasil diaktifkan!`);
                return;
              }
            }
          }

          logStatus('Membuka pemilih direktori CapCut...');
          const handle = await global.CapCutDraftWriter.pairCapCutDirectory();
          await refreshCapCutStatus(uiElements);
          const inspection = await inspectCapCutDirectoryStructure(handle);
          logStatus(inspection.message);
        } catch (err) {
          if (err && err.name === 'AbortError') {
            logStatus('Pemilihan direktori dibatalkan.');
          } else {
            logStatus(`Pemasangan CapCut: ${err.message || err}`);
          }
        }
      });
    }

    // Toggle Intip Password Groq Key
    if (btnTogglePassword && groqApiKeyInput) {
      btnTogglePassword.addEventListener('click', () => {
        const isPassword = groqApiKeyInput.type === 'password';
        groqApiKeyInput.type = isPassword ? 'text' : 'password';
        btnTogglePassword.setAttribute('title', isPassword ? 'Sembunyikan Kunci' : 'Tampilkan Kunci');
        btnTogglePassword.textContent = isPassword ? '🔒' : '👁️';
      });
    }

    // Simpan Groq API Key
    if (btnSaveGroqKey && groqApiKeyInput) {
      btnSaveGroqKey.addEventListener('click', async () => {
        const val = (groqApiKeyInput.value || '').trim();
        if (!val) {
          logStatus('Masukkan kunci API Groq yang valid.');
          return;
        }
        if (global.GroqWhisperClient) {
          await global.GroqWhisperClient.setStoredApiKey(val);
          await refreshGroqKeyUI(uiElements);
    setupCapCutPathHint(uiElements);
          logStatus('✓ Kunci API Groq berhasil disimpan!');
        }
      });
    }

    // Dropzone Interaktif
    if (dropzoneBox) {
      dropzoneBox.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzoneBox.classList.add('dropzone-active');
      });
      dropzoneBox.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropzoneBox.classList.remove('dropzone-active');
      });
      dropzoneBox.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzoneBox.classList.remove('dropzone-active');
        if (e.dataTransfer && e.dataTransfer.files) {
          processDroppedFiles(e.dataTransfer.files, uiElements);
        }
      });
      dropzoneBox.addEventListener('click', () => {
        if (filePickerInput) filePickerInput.click();
      });
    }

    if (btnBrowseFiles) {
      btnBrowseFiles.addEventListener('click', (e) => {
        e.stopPropagation();
        if (filePickerInput) filePickerInput.click();
      });
    }

    if (filePickerInput) {
      filePickerInput.addEventListener('change', (e) => {
        if (e.target && e.target.files) {
          processDroppedFiles(e.target.files, uiElements);
        }
      });
    }

    // Tombol Injeksi Draf CapCut
    if (btnInjectCapcut) {
      btnInjectCapcut.addEventListener('click', async () => {
        if (!standaloneProject || !standaloneProject.scenes || standaloneProject.scenes.length === 0) {
          logStatus('Unggah naskah storyboard .json terlebih dahulu.');
          return;
        }
        if (!global.CapCutDraftWriter) {
          logStatus('Modul CapCutDraftWriter belum siap.');
          return;
        }

        try {
          btnInjectCapcut.disabled = true;
          btnInjectCapcut.innerHTML = `<span>⏳ Menginjeksi Draf...</span>`;
          logStatus('Menulis berkas draf CapCut...');

          let handle = await global.CapCutDraftWriter.getStoredDirectoryHandle();
          if (handle) {
            // Auto-reactivate izin secara transparan lewat user gesture tombol draf
            const isGranted = await global.CapCutDraftWriter.verifyPermission(handle, true);
            if (!isGranted) {
              logStatus('Izin folder draf belum diberikan. Membuka pemilih folder...');
              handle = await global.CapCutDraftWriter.pairCapCutDirectory();
            } else {
              await refreshCapCutStatus(uiElements);
            }
          } else {
            logStatus('Menghubungkan direktori draf CapCut...');
            handle = await global.CapCutDraftWriter.pairCapCutDirectory();
          }

          if (!standaloneAudioFile && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            try {
              const stAudio = await new Promise(r => chrome.storage.local.get(['activeProjectAudioDataUrl', 'activeProjectAudioFileName', 'activeProjectAudioExt'], r));
              if (stAudio && stAudio.activeProjectAudioDataUrl) {
                const ext = stAudio.activeProjectAudioExt || 'mp3';
                const fName = standaloneProject.projectFolder ? `${standaloneProject.projectFolder}.${ext}` : (stAudio.activeProjectAudioFileName || 'narasi_studio.mp3');
                standaloneAudioFile = dataUrlToFile(stAudio.activeProjectAudioDataUrl, fName);
              }
            } catch (_) {}
          }

          const res = await global.CapCutDraftWriter.writeCapCutDraft(
            handle,
            standaloneProject,
            standaloneAudioFile,
            null
          );

          logStatus(`✓ Draf '${res.projectName}' sukses diinjeksi ke CapCut!`);
          if (global.PopupModal && typeof global.PopupModal.showSuccess === 'function') {
            await global.PopupModal.showSuccess({
              title: 'Draf CapCut Berhasil Dibuat!',
              subtitle: 'Perakitan Linimasa Studio CapCut',
              badge: 'STUDIO CAPCUT',
              projectName: res.projectName,
              message: 'Seluruh gambar adegan, subtitel SRT, dan trek audio narasi telah siap. Buka aplikasi CapCut Desktop untuk mulai mengedit.',
              confirmText: '✓ Selesai & Tutup'
            });
          }
        } catch (err) {
          logStatus(`Gagal membuat draf CapCut: ${err.message || err}`);
        } finally {
          btnInjectCapcut.disabled = false;
          btnInjectCapcut.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>Buat Draf CapCut Langsung</span>
          `;
        }
      });
    }
  }

  // Registrasi global
  global.PopupStandaloneStudio = {
    init: initStandaloneStudio,
    openInFullTab,
    refreshCapCutStatus,
    refreshGroqKeyUI,
    processDroppedFiles,
    inspectCapCutDirectoryStructure,
    restoreActiveProjectFromStorage,
    getActiveProject,
    getActiveAudioFile,
    dataUrlToFile,
    syncAndDownloadAudioToProjectFolder
  };

})(typeof window !== 'undefined' ? window : globalThis);

