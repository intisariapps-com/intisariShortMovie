/**
 * FlowAutoBridge - Sliding Window Burst Prompt Pipeline & Multi-Task Validator (v2.8.0)
 * SRS-FAB-075: Pengiriman Konkuren 3-5 Prompt Sekaligus & Validasi Unduhan Presisi
 */

(function () {
  'use strict';

  function log(msg, level = 'INFO') {
    const pfx = (typeof workerId !== 'undefined' && workerId) ? `[FlowAutoBridge:${workerId}:Pipeline]` : '[FlowAutoBridge:Pipeline]';
    console.log(`${pfx} ${msg}`);
  }

  let isPipelineActive = false;
  let isDispatcherBusy = false;
  let validatorTimer = null;
  const inFlightPool = new Map(); // sceneId -> InFlightTask
  const claimedImageSrcs = new Set();
  const submittedSceneIds = new Set();

  function getConcurrencyLimit() {
    return new Promise(resolve => {
      chrome.storage.local.get(['flowConcurrencyLimit'], data => {
        const val = parseInt(data.flowConcurrencyLimit, 10);
        resolve(val === 1 || val === 3 || val === 5 ? val : 3);
      });
    });
  }

  /**
   * Menghentikan seluruh proses pipeline sliding window
   */
  function stopSlidingWindowPipeline() {
    isPipelineActive = false;
    isDispatcherBusy = false;
    if (validatorTimer) {
      clearInterval(validatorTimer);
      validatorTimer = null;
    }
    inFlightPool.clear();
    submittedSceneIds.clear();
    log('Pipeline Sliding Window dihentikan.');
  }

  /**
   * Menjeda pipeline sliding window
   */
  function pauseSlidingWindowPipeline() {
    isPipelineActive = false;
    isDispatcherBusy = false;
    if (validatorTimer) {
      clearInterval(validatorTimer);
      validatorTimer = null;
    }
    log('Pipeline Sliding Window dijeda.');
  }

  /**
   * Memulai atau melanjutkan pipeline sliding window
   */
  async function startSlidingWindowPipeline() {
    if (isPipelineActive) return;
    isPipelineActive = true;

    const limit = await getConcurrencyLimit();
    log(`Memulai Sliding Window Pipeline dengan batas konkurensi: ${limit} prompt in-flight.`);
    if (typeof injectFlowStatusOverlay === 'function') {
      injectFlowStatusOverlay(`Mode Turbo Aktif (${limit} Prompt Sekaligus)...`, true, false);
    }

    // Inisialisasi daftar adegan yang sudah selesai dari storage
    const storageData = await new Promise(res => chrome.storage.local.get(['storyboardQueue', 'activeIndex'], res));
    const rawQueue = storageData.storyboardQueue || [];
    const queue = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);
    const activeIdx = typeof storageData.activeIndex === 'number' ? storageData.activeIndex : -1;

    // Tandai adegan yang sudah lewat sebagai submitted agar tidak diulang
    for (let i = 0; i <= activeIdx && i < queue.length; i++) {
      if (queue[i] && queue[i].id) submittedSceneIds.add(queue[i].id);
    }

    // Mulai Dispatcher Loop & Multi-Task Validator
    dispatchNextPipelineTasks();
    startMultiTaskValidator();
  }

  /**
   * Dispatcher: Mengirim prompt berikutnya ke textarea hingga in-flight pool terisi penuh
   */
  async function dispatchNextPipelineTasks() {
    if (!isPipelineActive || isDispatcherBusy) return;
    isDispatcherBusy = true;

    try {
      const concurrencyLimit = await getConcurrencyLimit();
      const storageData = await new Promise(res => chrome.storage.local.get(['storyboardQueue'], res));
      const rawQueue = storageData.storyboardQueue || [];
      const queue = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);

      if (queue.length === 0) {
        isDispatcherBusy = false;
        return;
      }

      // Cari tugas yang belum dikirim dan belum selesai
      while (isPipelineActive && inFlightPool.size < concurrencyLimit) {
        let candidateTask = null;
        let candidateIdx = -1;

        for (let i = 0; i < queue.length; i++) {
          const sc = queue[i];
          const sId = sc.id || `ADEGAN_${String(i + 1).padStart(2, '0')}`;
          if (!submittedSceneIds.has(sId) && !inFlightPool.has(sId)) {
            candidateTask = sc;
            candidateIdx = i;
            break;
          }
        }

        // Jika tidak ada lagi tugas tersisa untuk dikirim, keluar loop dispatch
        if (!candidateTask) break;

        const sceneId = candidateTask.id || `ADEGAN_${String(candidateIdx + 1).padStart(2, '0')}`;
        const prompt = (candidateTask.image_prompt || candidateTask.prompt_flow || candidateTask.prompt || '').trim();
        const targetRatio = candidateTask.aspect_ratio || (prompt.includes('16:9') ? '16:9' : '9:16');

        if (!prompt) {
          submittedSceneIds.add(sceneId);
          continue;
        }

        log(`[Pipeline] Menyiapkan submit untuk ${sceneId} (Slot: ${inFlightPool.size + 1}/${concurrencyLimit})...`);
        if (typeof injectFlowStatusOverlay === 'function') {
          injectFlowStatusOverlay(`[Slot ${inFlightPool.size + 1}/${concurrencyLimit}] Mengetik prompt ${sceneId}...`, true, false);
        }

        // Temukan Textarea Google Flow
        let textarea = null;
        for (let att = 0; att < 8; att++) {
          if (typeof findPromptTextarea === 'function') textarea = findPromptTextarea();
          if (textarea) break;
          await new Promise(r => setTimeout(r, 400));
        }

        if (!textarea) {
          log(`⚠️ Textarea prompt tidak ditemukan saat submit ${sceneId}`, 'WARN');
          break;
        }

        // Isi prompt
        if (typeof fillPromptInput === 'function') {
          fillPromptInput(textarea, prompt);
        }
        // Jeda stabilisasi teks
        await new Promise(r => setTimeout(r, 1200));

        // Temukan tombol generate
        let generateBtn = null;
        for (let att = 0; att < 6; att++) {
          if (typeof findGenerateButton === 'function') generateBtn = findGenerateButton(textarea);
          if (generateBtn) break;
          await new Promise(r => setTimeout(r, 300));
        }

        // Trigger Submit
        let isSubmitted = false;
        if (typeof triggerGenerate === 'function') {
          isSubmitted = await triggerGenerate(textarea, generateBtn);
        }

        if (isSubmitted) {
          submittedSceneIds.add(sceneId);
          inFlightPool.set(sceneId, {
            sceneId,
            sceneIndex: candidateIdx,
            prompt,
            targetRatio,
            submittedAt: Date.now(),
            attempts: 0
          });
          log(`✓ Prompt ${sceneId} berhasil terkirim ke antrean Flow! (Aktif di pool: ${inFlightPool.size})`);
          chrome.storage.local.set({ currentProcessingSceneId: sceneId });

          // Staggered Delay antar submit untuk mencegah race condition textarea
          await new Promise(r => setTimeout(r, 1800));
        } else {
          log(`⚠️ Gagal submit untuk ${sceneId}. Menunggu giliran berikutnya...`, 'WARN');
          break;
        }
      }
    } catch (e) {
      log(`Error di dispatcher pipeline: ${e}`, 'ERROR');
    } finally {
      isDispatcherBusy = false;
    }
  }

  /**
   * Multi-Task Validator: Memantau kanvas secara asinkron dan mencocokkan hasil render ke sceneId yang tepat
   */
  function startMultiTaskValidator() {
    if (validatorTimer) clearInterval(validatorTimer);

    validatorTimer = setInterval(async () => {
      if (!isPipelineActive) {
        clearInterval(validatorTimer);
        validatorTimer = null;
        return;
      }

      try {
        const storageData = await new Promise(res => chrome.storage.local.get(['storyboardQueue'], res));
        const rawQueue = storageData.storyboardQueue || [];
        const queue = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);

        // Cek apakah seluruh antrean sudah tuntas
        const allSubmitted = queue.length > 0 && submittedSceneIds.size >= queue.length;
        if (allSubmitted && inFlightPool.size === 0) {
          log('🎉 Seluruh antrean storyboard berhasil diselesaikan di mode pipeline!');
          if (typeof injectFlowStatusOverlay === 'function') {
            injectFlowStatusOverlay('✓ Semua antrean selesai!', false, false, false, { allCompleted: true });
          }
          chrome.storage.local.set({
            automationRunning: false,
            flowExecutionState: { status: 'done', text: '✓ Semua antrean selesai!' }
          });
          stopSlidingWindowPipeline();
          return;
        }

        if (inFlightPool.size === 0) {
          // Jika pool kosong tetapi masih ada antrean, picu dispatcher
          dispatchNextPipelineTasks();
          return;
        }

        // Update Overlay Status Multi-Task
        const activeIds = Array.from(inFlightPool.keys()).join(', ');
        if (typeof injectFlowStatusOverlay === 'function') {
          injectFlowStatusOverlay(`Merender ${inFlightPool.size} adegan serentak: [${activeIds}]...`, true, false);
        }

        // Pindai gambar kandidat di kanvas (FR-WHT-002: Hanya gambar yang terverifikasi selesai dan bukan placeholder putih)
        const images = Array.from(document.querySelectorAll('img'));
        const candidates = images.filter(img => {
          if (typeof isFlowImageFullyRendered === 'function') {
            return isFlowImageFullyRendered(img);
          }
          const src = img.src || '';
          const nw = img.naturalWidth || 0;
          const nh = img.naturalHeight || 0;
          const isValidSrc = src.startsWith('http') || src.startsWith('blob:') || src.startsWith('data:');
          if (!isValidSrc || nw < 256 || nh < 256 || img.complete !== true) return false;
          if (typeof isBlacklistedAssetUrl === 'function' && isBlacklistedAssetUrl(src)) return false;
          return true;
        });

        // Hydrate prompt kartu jika tersedia
        for (const img of candidates) {
          if (typeof hydrateFlowCardPrompt === 'function') {
            await hydrateFlowCardPrompt(img);
          }
        }

        // Lakukan pencocokan (Disambiguation Matching) terhadap tugas in-flight
        for (const img of candidates) {
          if (claimedImageSrcs.has(img.src)) continue;

          for (const [sId, task] of inFlightPool.entries()) {
            let isMatch = false;
            if (typeof isImageMatchingPrompt === 'function') {
              isMatch = isImageMatchingPrompt(img, task.prompt);
            }

            if (isMatch) {
              claimedImageSrcs.add(img.src);
              if (typeof sessionClaimedImages !== 'undefined' && sessionClaimedImages.add) {
                sessionClaimedImages.add(img.src);
              }

              log(`✓ [Pipeline Match] Gambar baru cocok 100% dengan ${sId}! Memulai unduhan...`);
              if (typeof dismissAnyOpenFlowViewer === 'function') dismissAnyOpenFlowViewer();

              // Trigger download otomatis
              if (typeof triggerAutoDownloadFlowImage === 'function') {
                await triggerAutoDownloadFlowImage(img, sId);
              }

              // Hapus dari in-flight pool (membebaskan slot!)
              inFlightPool.delete(sId);

              // Update activeIndex di storage untuk tracking kemajuan
              await new Promise(res => {
                chrome.storage.local.get(['activeIndex'], st => {
                  const cur = typeof st.activeIndex === 'number' ? st.activeIndex : -1;
                  const nextAct = Math.max(cur, task.sceneIndex);
                  chrome.storage.local.set({ activeIndex: nextAct }, res);
                });
              });

              if (typeof injectFlowStatusOverlay === 'function') {
                injectFlowStatusOverlay(`✓ ${sId} selesai! Slot bebas, memuat adegan baru...`, true, false);
              }

              // Segera picu dispatcher untuk mengisi slot yang kosong
              setTimeout(dispatchNextPipelineTasks, 500);
              break;
            }
          }
        }

        // Pemeriksaan Timeout Independen per tugas in-flight (120 detik)
        const now = Date.now();
        for (const [sId, task] of inFlightPool.entries()) {
          if (now - task.submittedAt > 120000) {
            log(`⚠️ [Pipeline Timeout] ${sId} melampaui batas 120 detik. Mengeluarkan dari pool...`, 'WARN');
            inFlightPool.delete(sId);
            setTimeout(dispatchNextPipelineTasks, 1000);
          }
        }

      } catch (err) {
        log(`Error di multi-task validator: ${err}`, 'WARN');
      }
    }, 1800);
  }

  // Publikasikan API ke objek window global
  window.FlowSlidingWindowPipeline = {
    start: startSlidingWindowPipeline,
    pause: pauseSlidingWindowPipeline,
    stop: stopSlidingWindowPipeline,
    getInFlightCount: () => inFlightPool.size
  };

})();

