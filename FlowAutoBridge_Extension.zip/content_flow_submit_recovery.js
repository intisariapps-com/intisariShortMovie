/**
 * content_flow_submit_recovery.js (SRS-111 / FR-04)
 * Resolver & Watchdog Cerdas untuk Pemulihan Submit 'uncertain' Google Flow.
 * Mencegah kemacetan pipeline tanpa risiko duplikasi prompt (anti-duplicate guard).
 */
(function() {
  'use strict';

  const RECOVERY_STORAGE_KEY = 'flow_submit_recovery';
  const MAX_RECOVERY_ATTEMPTS = 2;

  function getChromeStorage() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
    return null;
  }

  function log(msg, level = 'INFO') {
    const prefix = '[FlowAutoBridge:SubmitRecovery]';
    if (level === 'WARN') console.warn(`${prefix} ${msg}`);
    else if (level === 'ERROR') console.error(`${prefix} ${msg}`);
    else console.log(`${prefix} ${msg}`);
  }

  /**
   * Memeriksa apakah kartu dengan watermark tag adegan sc_tag_<id> sudah ada di DOM Google Flow.
   * @param {string} sceneId ID adegan (misal 'ADEGAN_14')
   * @param {string} prompt Teks prompt lengkap
   * @returns {boolean} True jika kartu ber-tag sudah ada di kanvas
   */
  function checkCardExistsOnCanvas(sceneId, prompt) {
    if (typeof document === 'undefined') return false;

    // Ambil tag deterministik sc_tag_<id> dari prompt atau sceneId
    let tag = '';
    if (typeof window !== 'undefined' && window.FlowEvaluator && typeof window.FlowEvaluator.extractScenePromptTag === 'function') {
      tag = window.FlowEvaluator.extractScenePromptTag(prompt);
    }
    if (!tag && typeof window !== 'undefined' && window.FlowEvaluator && typeof window.FlowEvaluator.formatScenePromptTag === 'function') {
      tag = window.FlowEvaluator.formatScenePromptTag(sceneId);
    }
    if (!tag) {
      const match = String(sceneId).match(/\d+/);
      tag = match ? `sc_tag_${String(parseInt(match[0], 10)).padStart(2, '0')}` : 'sc_tag_cover';
    }

    const cleanTag = String(tag).trim().toLowerCase();

    // 1. Pindai seluruh kartu di kanvas
    const candidateNodes = document.querySelectorAll('img, [role="img"], div, p, span');
    for (const node of candidateNodes) {
      const alt = (node.getAttribute && (node.getAttribute('alt') || node.getAttribute('aria-label') || '')) || '';
      const text = (node.textContent || '');
      if (alt.toLowerCase().includes(cleanTag) || text.toLowerCase().includes(cleanTag)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Menyelesaikan masalah saat submit prompt menghasilkan status 'uncertain'.
   * @param {string} sceneId ID adegan yang macet
   * @param {string} prompt Teks prompt adegan
   * @param {Object} options Opsi tambahan
   * @returns {Promise<{action: 'confirm_rendering'|'trigger_reload'|'block_failed', message: string}>}
   */
  async function resolveUncertainSubmit(sceneId, prompt, options = {}) {
    const storage = getChromeStorage();
    const cleanId = String(sceneId).trim();

    log(`Menganalisis resolusi submit uncertain untuk ${cleanId}...`, 'WARN');

    // Langkah 1 (FR-04.1): Cek apakah kartu watermark sc_tag sudah tercipta di kanvas
    const cardExists = checkCardExistsOnCanvas(cleanId, prompt);
    if (cardExists) {
      log(`✓ Kartu ber-tag ${cleanId} telah terkonfirmasi di kanvas! Melanjutkan tanpa reload.`);
      if (typeof window !== 'undefined' && window.FlowSceneState) {
        await window.FlowSceneState.setSceneState(cleanId, 'rendering');
      }
      return {
        action: 'confirm_rendering',
        message: `Kartu ${cleanId} terdeteksi di kanvas; konfirmasi rendering sukses.`
      };
    }

    // Langkah 2 (FR-04.2): Kartu belum ada. Cek riwayat reload recovery
    if (!storage) {
      return { action: 'block_failed', message: 'Storage lokal tidak tersedia.' };
    }

    const storedData = await new Promise((resolve) => {
      storage.get([RECOVERY_STORAGE_KEY], (res) => resolve(res && res[RECOVERY_STORAGE_KEY] ? res[RECOVERY_STORAGE_KEY] : null));
    });

    const isSameScene = storedData && storedData.sceneId === cleanId;
    const currentAttempts = isSameScene ? (storedData.attempt || 0) : 0;

    if (currentAttempts < MAX_RECOVERY_ATTEMPTS) {
      const nextAttempt = currentAttempts + 1;
      log(`🔄 Memicu reload tab terkontrol untuk memulihkan sesi Flow (${cleanId}, attempt ${nextAttempt}/${MAX_RECOVERY_ATTEMPTS})...`, 'WARN');

      if (typeof window !== 'undefined' && window.FlowSceneState) {
        await window.FlowSceneState.setSceneState(cleanId, 'held', `Submit tertahan; reload attempt ${nextAttempt}/${MAX_RECOVERY_ATTEMPTS}`, nextAttempt);
      }

      await new Promise((resolve) => {
        storage.set({
          [RECOVERY_STORAGE_KEY]: {
            sceneId: cleanId,
            attempt: nextAttempt,
            prompt: prompt,
            timestamp: Date.now()
          }
        }, resolve);
      });

      // Beri jeda 800ms agar storage selesai tersimpan lalu refresh tab
      setTimeout(() => {
        if (typeof window !== 'undefined' && window.location) {
          window.location.reload();
        }
      }, 800);

      return {
        action: 'trigger_reload',
        attempt: nextAttempt,
        message: `Tab dimuat ulang untuk pemulihan (attempt ${nextAttempt}/${MAX_RECOVERY_ATTEMPTS}).`
      };
    }

    // Langkah 3 (FR-04.4): Batas reload terlampaui
    log(`⚠️ Submit ${cleanId} gagal definitif setelah ${MAX_RECOVERY_ATTEMPTS}x reload. Menahan antrean.`, 'ERROR');
    if (typeof window !== 'undefined' && window.FlowSceneState) {
      await window.FlowSceneState.setSceneState(cleanId, 'failed', `Gagal submit setelah ${MAX_RECOVERY_ATTEMPTS}x percobaan otomatis.`);
    }

    return {
      action: 'block_failed',
      attempt: currentAttempts,
      message: `Pengiriman ${cleanId} tertahan: kolom gagal dikosongkan setelah ${MAX_RECOVERY_ATTEMPTS}x reload otomatis.`
    };
  }

  /**
   * Watchdog pasca-reload: Memeriksa apakah halaman dimuat ulang oleh submit recovery.
   */
  async function checkAndResumeSubmitRecovery() {
    const storage = getChromeStorage();
    if (!storage) return;

    try {
      const data = await new Promise((resolve) => {
        storage.get([RECOVERY_STORAGE_KEY], (res) => resolve(res && res[RECOVERY_STORAGE_KEY] ? res[RECOVERY_STORAGE_KEY] : null));
      });

      if (!data || !data.sceneId) return;

      const elapsed = Date.now() - (data.timestamp || 0);
      if (elapsed > 90000) {
        storage.remove([RECOVERY_STORAGE_KEY]);
        return;
      }

      log(`🔄 [Post-Reload Watchdog] Terdeteksi pemulihan sesi untuk adegan ${data.sceneId} (attempt ${data.attempt}).`);

      // Cek apakah kartu sudah tercipta
      const cardExists = checkCardExistsOnCanvas(data.sceneId, data.prompt || '');
      if (cardExists) {
        log(`✓ [Post-Reload] Kartu ${data.sceneId} sudah ada di kanvas pasca-reload. Tandai rendering.`);
        if (typeof window !== 'undefined' && window.FlowSceneState) {
          await window.FlowSceneState.setSceneState(data.sceneId, 'rendering');
        }
        storage.remove([RECOVERY_STORAGE_KEY]);
      } else {
        log(`ℹ️ [Post-Reload] Kartu ${data.sceneId} belum ada. Menyiapkan antrean untuk pengiriman ulang...`);
      }

      // Beri jeda 3 detik untuk stabilitas DOM lalu bersihkan recovery key
      setTimeout(() => {
        storage.remove([RECOVERY_STORAGE_KEY]);
      }, 3500);
    } catch (_) {}
  }

  // Daftarkan watchdog listener saat DOM siap
  if (typeof document !== 'undefined' && document.addEventListener) {
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      checkAndResumeSubmitRecovery();
    } else {
      document.addEventListener('DOMContentLoaded', checkAndResumeSubmitRecovery);
    }
  }

  const api = {
    checkCardExistsOnCanvas,
    resolveUncertainSubmit,
    checkAndResumeSubmitRecovery,
    MAX_RECOVERY_ATTEMPTS
  };

  if (typeof window !== 'undefined') {
    window.FlowSubmitRecovery = api;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
