// ============================================================
// FlowAutoBridge — background.js
// Service worker utama ekstensi.
// Menangani: download storyboard, download gambar, cek update.
// ============================================================

const VERSION_URL = 'https://raw.githubusercontent.com/intisariapps-com/intisariShortMovie/main/version_extension.json';
const CHECK_ALARM_NAME = 'fab_update_check';
const CHECK_INTERVAL_MINUTES = 360; // 6 jam sekali

// ─── Inisialisasi alarm & context menu saat ekstensi pertama dipasang / startup ───
chrome.runtime.onInstalled.addListener(() => {
  _scheduleUpdateCheck();
  _checkForUpdate(); // Langsung cek saat pertama pasang
  _initContextMenus();
});

chrome.runtime.onStartup.addListener(() => {
  _scheduleUpdateCheck();
  _initContextMenus();
});

// Listener Toolbar Action Click: Toggle In-Page Persistent Slide Panel (Chrome 109+ Universal)
if (chrome.action && chrome.action.onClicked) {
  chrome.action.onClicked.addListener((tab) => {
    _handleActionClick(tab);
  });
}

function _handleActionClick(tab) {
  if (!tab || !tab.id) return;
  if (tab.url && tab.url.includes('flow.google.com')) {
    chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_SLIDE_PANEL' }, () => {
      if (chrome.runtime.lastError) {
        // Tab mungkin belum selesai loading script, abaikan hening
      }
    });
  } else {
    // Jika sedang di tab lain, cari tab flow yang ada atau buka tab flow baru
    chrome.tabs.query({ url: '*://flow.google.com/*' }, (flowTabs) => {
      if (flowTabs && flowTabs.length > 0) {
        const targetTab = flowTabs[0];
        chrome.tabs.update(targetTab.id, { active: true }, () => {
          chrome.tabs.sendMessage(targetTab.id, { action: 'OPEN_SLIDE_PANEL' }, () => {
            if (chrome.runtime.lastError) {}
          });
        });
      } else {
        chrome.tabs.create({ url: 'https://flow.google.com' });
      }
    });
  }
}

// ─── Tangani alarm yang jatuh tempo ──────────────────────────────────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CHECK_ALARM_NAME) {
    _checkForUpdate();
  }
});

// ─── Fungsi: daftarkan alarm periodik ────────────────────────────────────────
function _scheduleUpdateCheck() {
  chrome.alarms.get(CHECK_ALARM_NAME, (existing) => {
    if (!existing) {
      chrome.alarms.create(CHECK_ALARM_NAME, {
        delayInMinutes: 1,               // Tunda 1 menit setelah startup
        periodInMinutes: CHECK_INTERVAL_MINUTES
      });
    }
  });
}

// ─── Fungsi: fetch version.json & bandingkan dengan versi terpasang ──────────
async function _checkForUpdate() {
  try {
    const res = await fetch(VERSION_URL, { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();

    const latestExt = data.extension_version;
    const notes     = data.extension_notes || '';
    const currentExt = chrome.runtime.getManifest().version;

    if (!latestExt) return; // Tidak ada field extension_version, abaikan

    if (_isNewer(latestExt, currentExt)) {
      // Simpan ke storage agar content script bisa ambil
      await chrome.storage.local.set({
        fab_update_available: true,
        fab_latest_version: latestExt,
        fab_update_notes: notes,
        fab_current_version: currentExt
      });

      // Broadcast ke semua tab Gemini yang sedang terbuka
      const tabs = await chrome.tabs.query({ url: 'https://gemini.google.com/*' });
      for (const tab of tabs) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'fab_show_update_banner',
          latestVersion: latestExt,
          currentVersion: currentExt,
          notes: notes
        }).catch(() => {}); // Abaikan jika tab belum siap
      }
    } else {
      // Versi sudah terkini, hapus flag
      await chrome.storage.local.remove(['fab_update_available', 'fab_latest_version', 'fab_update_notes']);
    }
  } catch (err) {
    console.warn('FlowAutoBridge: Gagal cek update —', err.message);
  }
}

// ─── Utilitas: bandingkan semver (major.minor.patch) ─────────────────────────
function _isNewer(latest, current) {
  const parse = (v) => v.split('.').map(Number);
  const [la, lb, lc] = parse(latest);
  const [ca, cb, cc] = parse(current);
  if (la !== ca) return la > ca;
  if (lb !== cb) return lb > cb;
  return lc > cc;
}

// ─── Pelacak Unduhan Internal Ekstensi (Proteksi Subfolder Proyek v2.6.3 & FAB-SRS-070) ───
const downloadMapByUrl = new Map();
const pendingExtensionDownloads = new Map();
const pendingExtensionQueue = [];

function _enqueueExtensionDownloadPath(fullPath, url = null) {
  if (url) {
    downloadMapByUrl.set(url, fullPath);
  }
  pendingExtensionQueue.push({ fullPath, url, ts: Date.now() });
  while (pendingExtensionQueue.length > 500) pendingExtensionQueue.shift();
}

// ─── Mendengarkan pesan dari content scripts ──────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // 1. Download file storyboard JSON (bisa berupa nama dinamis)
  if (message.action === 'download_storyboard') {
    const jsonStr = JSON.stringify(message.data, null, 2);
    const dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonStr);
    let targetFilename = message.filename || 'storyboard.json';
    if (!targetFilename.toLowerCase().endsWith('.json')) {
      targetFilename += '.json';
    }
    const baseName = targetFilename.replace(/\.json$/i, '');
    const projectFolder = message.projectFolder || baseName;
    const fullPath = `intisariShortMovie/${projectFolder}/${targetFilename}`;
    _enqueueExtensionDownloadPath(fullPath, dataUrl);

    chrome.downloads.download({
      url: dataUrl,
      filename: fullPath,
      saveAs: false
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error(`FlowAutoBridge: Gagal mengunduh ${fullPath}`, chrome.runtime.lastError);
        if (sendResponse) sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        console.log(`FlowAutoBridge: ${fullPath} diunduh dengan ID ${downloadId}`);
        if (sendResponse) sendResponse({ success: true, downloadId: downloadId });
      }
    });
    return true; // Menjaga channel komunikasi asinkron tetap terbuka
  }

  // 1b. Download salinan naskah storyboard JSON ke subfolder proyek intisariShortMovie (SRS-FAB-058 / v2.6.3)
  if (message.action === 'download_storyboard_json') {
    const dataUrl = message.dataUrl;
    let targetFilename = message.filename || 'storyboard.json';
    if (!targetFilename.toLowerCase().endsWith('.json')) targetFilename += '.json';
    const projectFolder = message.projectFolder || '';
    const rawSubfolder = message.subfolder || 'intisariShortMovie';

    let fullPath = rawSubfolder;
    if (projectFolder && !rawSubfolder.includes(projectFolder)) {
      fullPath = `${rawSubfolder}/${projectFolder}/${targetFilename}`;
    } else {
      fullPath = `${rawSubfolder}/${targetFilename}`;
    }

    _enqueueExtensionDownloadPath(fullPath, dataUrl);
    chrome.downloads.download({
      url: dataUrl,
      filename: fullPath,
      saveAs: false,
      conflictAction: 'overwrite'
    }, (downloadId) => {
      if (typeof downloadId === 'number') pendingExtensionDownloads.set(downloadId, fullPath);
      if (chrome.runtime.lastError) {
        console.error(`FlowAutoBridge: Gagal menyimpan naskah JSON ${fullPath}:`, chrome.runtime.lastError);
        if (sendResponse) sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        console.log(`FlowAutoBridge: Berhasil menyimpan naskah JSON ${fullPath} (ID: ${downloadId})`);
        if (sendResponse) sendResponse({ success: true, downloadId, path: fullPath });
      }
    });
    return true;
  }

  // 1c. Download salinan berkas audio narasi ke subfolder proyek intisariShortMovie (v2.6.3)
  if (message.action === 'download_project_audio') {
    const dataUrl = message.dataUrl;
    const projectFolder = message.projectFolder || 'Proyek';
    const rawSubfolder = message.subfolder || 'intisariShortMovie';
    const targetFilename = message.filename || `${projectFolder}.mp3`;
    const fullPath = projectFolder && !rawSubfolder.includes(projectFolder)
      ? `${rawSubfolder}/${projectFolder}/${targetFilename}`
      : `${rawSubfolder}/${targetFilename}`;

    _enqueueExtensionDownloadPath(fullPath, dataUrl);
    chrome.downloads.download({
      url: dataUrl,
      filename: fullPath,
      saveAs: false,
      conflictAction: 'overwrite'
    }, (downloadId) => {
      if (typeof downloadId === 'number') pendingExtensionDownloads.set(downloadId, fullPath);
      if (chrome.runtime.lastError) {
        console.error(`FlowAutoBridge: Gagal menyimpan audio proyek ${fullPath}:`, chrome.runtime.lastError);
        if (sendResponse) sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        console.log(`FlowAutoBridge: Berhasil menyimpan audio proyek ${fullPath} (ID: ${downloadId})`);
        if (sendResponse) sendResponse({ success: true, downloadId, path: fullPath, projectFolder });
      }
    });
    return true;
  }

  // 2. Download file gambar Google Flow permanen ke folder intisariShortMovie (SRS-FAB-055 & v2.6.3)
  if (message.action === 'fab_download_flow_image') {
    const dataUrl = message.imageUrl || message.dataUrl;
    let targetFilename = message.filename || 'ADEGAN_01.jpg';
    const rawSubfolder = message.subfolder || 'intisariShortMovie';

    if (!targetFilename.toLowerCase().endsWith('.jpg') && !targetFilename.toLowerCase().endsWith('.jpeg') && !targetFilename.toLowerCase().endsWith('.png')) {
      targetFilename += '.jpg';
    }

    chrome.storage.local.get(['activeProjectFolder', 'latestActiveStoryboardTitle', 'renderedSceneUrls'], (res) => {
      let projectFolder = message.projectFolder || res.activeProjectFolder;
      if (!projectFolder && res.latestActiveStoryboardTitle) {
        projectFolder = _generateCleanProjectFolderName(res.latestActiveStoryboardTitle);
        chrome.storage.local.set({ activeProjectFolder: projectFolder });
      }

      let fullPath = rawSubfolder;
      if (projectFolder && !rawSubfolder.includes(projectFolder)) {
        fullPath = `${rawSubfolder}/${projectFolder}/${targetFilename}`;
      } else {
        fullPath = `${rawSubfolder}/${targetFilename}`;
      }

      const sceneKey = targetFilename.replace(/\.(png|jpg|jpeg|webp)$/i, '').toUpperCase();
      const map = (res && res.renderedSceneUrls && typeof res.renderedSceneUrls === 'object') ? { ...res.renderedSceneUrls } : {};
      map[sceneKey] = dataUrl || fullPath;
      chrome.storage.local.set({ renderedSceneUrls: map });

      _enqueueExtensionDownloadPath(fullPath, dataUrl);
      chrome.downloads.download({
        url: dataUrl,
        filename: fullPath,
        saveAs: false,
        conflictAction: 'overwrite'
      }, (downloadId) => {
        if (typeof downloadId === 'number') pendingExtensionDownloads.set(downloadId, fullPath);
        if (chrome.runtime.lastError) {
          console.error(`FlowAutoBridge: Gagal mengunduh gambar ${fullPath}:`, chrome.runtime.lastError);
          if (sendResponse) sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          console.log(`FlowAutoBridge: Berhasil mengunduh ${fullPath} (ID: ${downloadId})`);
          if (sendResponse) sendResponse({ success: true, downloadId: downloadId, path: fullPath, projectFolder: projectFolder });
        }
      });
    });
    return true; // Menjaga channel komunikasi asinkron tetap terbuka
  }

  // 3. Permintaan manual cek update dari popup
  if (message.action === 'fab_force_check_update') {
    _checkForUpdate().then(() => sendResponse({ ok: true }));
    return true;
  }

  // 4. Sinkronisasi judul storyboard aktif dari content script
  if (message.action === 'sync_storyboard_title') {
    if (message.title) {
      const fn = message.filename || _generateCleanStoryboardFilename(message.title);
      const updates = {
        latestActiveStoryboardTitle: message.title,
        lastGeneratedStoryboardFilename: fn
      };
      if (message.projectFolder) {
        updates.activeProjectFolder = message.projectFolder;
      }
      chrome.storage.local.set(updates);
      if (sendResponse) sendResponse({ success: true, filename: fn });
    }
    return true;
  }

  // 5. Permintaan buka setelan unduhan Chrome (Universal Shortcut SRS-53)
  if (message.action === 'open_download_settings') {
    openChromeDownloadSettings();
    if (sendResponse) sendResponse({ success: true });
    return true;
  }
});

// ─── Aksesibilitas Universal Setelan Unduhan Chrome (SRS-53) ───────────────
function openChromeDownloadSettings() {
  const downloadUrl = 'chrome://settings/downloads';
  chrome.tabs.query({}, (tabs) => {
    const existing = (tabs || []).find(t => t.url && t.url.startsWith('chrome://settings/downloads'));
    if (existing) {
      chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId) {
        chrome.windows.update(existing.windowId, { focused: true });
      }
    } else {
      chrome.tabs.create({ url: downloadUrl });
    }
  });
}

function _initContextMenus() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'fab_open_download_settings',
      title: 'FlowAutoBridge: ⚙️ Buka Setelan Unduhan Chrome',
      contexts: ['all']
    }, () => {
      const _ignored = chrome.runtime.lastError;
    });
    chrome.contextMenus.create({
      id: 'fab_open_side_panel',
      title: 'FlowAutoBridge: ⚡ Buka Panel Samping (Slide Panel)',
      contexts: ['all']
    }, () => {
      const _ignored = chrome.runtime.lastError;
    });
  });
}

// Listener klik kanan context menu
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
  chrome.contextMenus.onClicked.addListener((info) => {
    if (info.menuItemId === 'fab_open_download_settings') {
      openChromeDownloadSettings();
    } else if (info.menuItemId === 'fab_open_side_panel') {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
          _handleActionClick(tabs[0]);
        }
      });
    }
  });
}

// Listener keyboard shortcut (Alt+Shift+D)
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener((command) => {
    if (command === 'open_download_settings') {
      openChromeDownloadSettings();
    }
  });
}

// ─── Helper: Penamaan berkas storyboard bersih berbasis judul ────────────────
function _generateCleanStoryboardFilename(title) {
  const rawStr = String(title || "storyboard").trim();
  const existingHashMatch = rawStr.match(/^(.+)[_\s]([a-z0-9]{4})$/i);
  if (existingHashMatch) {
    let cleanBase = existingHashMatch[1]
      .replace(/\(?part\s*\d+\)?/gi, '')
      .replace(/[^\w\s\-]+/g, ' ')
      .trim();
    let words = cleanBase.split(/\s+/).filter(Boolean);
    if (words.length > 4) words = words.slice(0, 4);
    const safeTitle = words.join('_').toLowerCase() || 'storyboard';
    return `${safeTitle}_${existingHashMatch[2].toLowerCase()}.json`;
  }

  let clean = rawStr
    .replace(/\(?part\s*\d+\)?/gi, '')
    .replace(/[^\w\s\-]+/g, ' ')
    .trim();
  let words = clean.split(/\s+/).filter(Boolean);
  if (words.length > 4) {
    const babMatch = clean.match(/\b(bab\s*\d+)\b/i);
    if (babMatch) {
      const babWords = babMatch[1].split(/\s+/);
      const otherWords = clean.replace(new RegExp(`\\b${babMatch[1]}\\b`, 'i'), '').trim().split(/\s+/).filter(Boolean);
      const remainingSlots = Math.max(1, 4 - babWords.length);
      words = [...otherWords.slice(0, remainingSlots), ...babWords];
    } else {
      words = words.slice(0, 4);
    }
  }
  const safeTitle = words.join('_').toLowerCase() || 'storyboard';
  const randHash = Math.random().toString(36).substring(2, 6);
  return `${safeTitle}_${randHash}.json`;
}

// ─── Helper: Penamaan folder proyek terisolasi dengan 4 karakter acak (FAB-SRS-072) ────────
function _generateCleanProjectFolderName(title) {
  const rawStr = String(title || "Proyek").trim();
  const existingHashMatch = rawStr.match(/^(.+)[_\s]([a-z0-9]{4})$/i);
  if (existingHashMatch) {
    let cleanBase = existingHashMatch[1]
      .replace(/\(?part\s*\d+\)?/gi, '')
      .replace(/[^\w\s\-]+/g, ' ')
      .trim();
    let words = cleanBase.split(/\s+/).filter(Boolean);
    if (words.length > 6) words = words.slice(0, 6);
    const base = words.join('_') || 'Proyek';
    return `${base}_${existingHashMatch[2].toLowerCase()}`;
  }

  let clean = rawStr
    .replace(/\(?part\s*\d+\)?/gi, '')
    .replace(/[^\w\s\-]+/g, ' ')
    .trim();
  let words = clean.split(/\s+/).filter(Boolean);
  if (words.length > 6) words = words.slice(0, 6);
  const baseTitle = words.join('_') || 'Proyek';
  const randHash = Math.random().toString(36).substring(2, 6);
  return `${baseTitle}_${randHash}`;
}

// ─── Otomatis ganti nama file unduhan (JSON naskah, Audio, & Gambar kanvas Flow) di level Chrome API ───
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  // 1. Prioritaskan pencocokan URL unik dari downloadMapByUrl (FAB-SRS-070 Anti-Race Condition)
  if (item.url && downloadMapByUrl.has(item.url)) {
    const matchedPath = downloadMapByUrl.get(item.url);
    downloadMapByUrl.delete(item.url);
    suggest({ filename: matchedPath, conflictAction: 'overwrite' });
    return;
  }

  // 1b. Prioritaskan path eksplisit dari unduhan internal ekstensi (download_storyboard_json, download_project_audio, fab_download_flow_image)
  if (pendingExtensionDownloads.has(item.id)) {
    const explicitPath = pendingExtensionDownloads.get(item.id);
    pendingExtensionDownloads.delete(item.id);
    suggest({ filename: explicitPath, conflictAction: 'overwrite' });
    return;
  }

  if (item.byExtensionId === chrome.runtime.id && pendingExtensionQueue.length > 0) {
    const now = Date.now();
    while (pendingExtensionQueue.length > 0 && now - pendingExtensionQueue[0].ts > 60000) {
      pendingExtensionQueue.shift();
    }
    if (pendingExtensionQueue.length > 0) {
      const entry = pendingExtensionQueue.shift();
      if (entry.url) downloadMapByUrl.delete(entry.url);
      suggest({ filename: entry.fullPath, conflictAction: 'overwrite' });
      return;
    }
  }

  const rawName = (item.filename || '').toLowerCase();
  const isGenericJson = /^download(?:\s*\(\d+\))?\.json$/i.test(rawName) || rawName === 'download.json';
  const isGenericImage = /^download(?:\s*\(\d+\))?\.(?:jpg|jpeg|png|webp)$/i.test(rawName);

  if (isGenericJson) {
    chrome.storage.local.get(['activeProjectFolder', 'latestActiveStoryboardTitle', 'lastGeneratedStoryboardFilename'], (res) => {
      let projectFolder = res.activeProjectFolder;
      if (!projectFolder && res.latestActiveStoryboardTitle) {
        projectFolder = _generateCleanProjectFolderName(res.latestActiveStoryboardTitle);
        chrome.storage.local.set({ activeProjectFolder: projectFolder });
      }
      if (projectFolder) {
        const unifiedPath = `intisariShortMovie/${projectFolder}/${projectFolder}.json`;
        console.log(`[FlowAutoBridge] Mengarahkan JSON ke folder proyek '${unifiedPath}'`);
        suggest({ filename: unifiedPath, conflictAction: 'overwrite' });
        return;
      }
      let targetName = res.lastGeneratedStoryboardFilename;
      if (!targetName && res.latestActiveStoryboardTitle) {
        targetName = _generateCleanStoryboardFilename(res.latestActiveStoryboardTitle);
      }
      if (targetName) {
        console.log(`[FlowAutoBridge] Mengubah nama unduhan JSON '${item.filename}' -> '${targetName}'`);
        suggest({ filename: targetName, conflictAction: 'uniquify' });
        return;
      }
      suggest();
    });
    return true; // Menyatakan panggilan suggest secara asinkron
  }

  if (isGenericImage) {
    chrome.storage.local.get(['activeProjectFolder', 'currentProcessingSceneId', 'latestActiveStoryboardTitle'], (res) => {
      let projectFolder = res.activeProjectFolder;
      if (!projectFolder && res.latestActiveStoryboardTitle) {
        projectFolder = _generateCleanProjectFolderName(res.latestActiveStoryboardTitle);
        chrome.storage.local.set({ activeProjectFolder: projectFolder });
      }
      if (!projectFolder) projectFolder = 'Proyek';

      const extMatch = rawName.match(/\.(jpg|jpeg|png|webp)$/i);
      const ext = (extMatch && extMatch[1].toLowerCase() === 'webp') ? 'jpg' : (extMatch ? extMatch[1].toLowerCase() : 'jpg');
      const sceneId = res.currentProcessingSceneId || 'ADEGAN_01';
      const targetFilename = `intisariShortMovie/${projectFolder}/${sceneId}.${ext}`;

      console.log(`[FlowAutoBridge] Mengubah rute gambar '${item.filename}' -> '${targetFilename}'`);
      suggest({ filename: targetFilename, conflictAction: 'uniquify' });
    });
    return true;
  }

  suggest();
});

// ─── Penangan Hardware-Level Trusted Input via Chrome DevTools Protocol (CDP) ───
function _attachAndSend(tabId, command, params, callback) {
  chrome.debugger.attach({ tabId }, '1.3', () => {
    const _ignored = chrome.runtime.lastError; // Bersihkan error jika sudah terpasang
    chrome.debugger.sendCommand({ tabId }, command, params, (res) => {
      const _cmdErr = chrome.runtime.lastError;
      if (callback) callback(res);
    });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CDP_CLICK' && sender.tab) {
    const tabId = sender.tab.id;
    const x = Math.round(message.x);
    const y = Math.round(message.y);

    _attachAndSend(tabId, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x: x,
      y: y,
      button: 'left',
      clickCount: 1
    }, () => {
      setTimeout(() => {
        _attachAndSend(tabId, 'Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          x: x,
          y: y,
          button: 'left',
          clickCount: 1
        }, () => {
          sendResponse({ success: true });
        });
      }, 60);
    });
    return true;
  }

  if (message.type === 'CDP_ENTER' && sender.tab) {
    const tabId = sender.tab.id;
    _attachAndSend(tabId, 'Input.dispatchKeyEvent', {
      type: 'keyDown',
      windowsVirtualKeyCode: 13,
      unmodifiedText: '\r',
      text: '\r',
      code: 'Enter',
      key: 'Enter'
    }, () => {
      setTimeout(() => {
        _attachAndSend(tabId, 'Input.dispatchKeyEvent', {
          type: 'keyUp',
          windowsVirtualKeyCode: 13,
          code: 'Enter',
          key: 'Enter'
        }, () => {
          sendResponse({ success: true });
        });
      }, 50);
    });
    return true;
  }
});

// ─── Polling Broadcast Perintah Desktop Bridge (Reload Seluruh Tab Google Flow) ───
let lastHandledBroadcastId = "";

setInterval(async () => {
  try {
    const res = await fetch("http://127.0.0.1:8000/api/v1/bridge/broadcast-command", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    if (data.has_command && data.command && data.command_id !== lastHandledBroadcastId) {
      lastHandledBroadcastId = data.command_id;
      console.log(`[FlowAutoBridge:Background] Menerima sinyal siaran Desktop: ${data.command} (ID: ${data.command_id})`);

      if (data.command === "RELOAD") {
        // Query semua tab Google Flow di seluruh jendela browser yang sedang terbuka
        chrome.tabs.query({}, (allTabs) => {
          const flowTabs = (allTabs || []).filter(t => t.url && t.url.includes("flow.google.com"));
          console.log(`[FlowAutoBridge:Background] Me-reload ${flowTabs.length} tab Google Flow secara otomatis...`);
          for (const tab of flowTabs) {
            try {
              chrome.tabs.reload(tab.id);
            } catch (e) {
              console.warn(`[FlowAutoBridge:Background] Gagal reload tab ${tab.id}:`, e);
            }
          }
        });
      }
    }
  } catch (e) {
    // Desktop Bridge offline / tidak merespons, abaikan secara hening
  }
}, 1500);


