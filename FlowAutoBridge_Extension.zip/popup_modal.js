// ==============================================================================
// 📁 FILE   : extension/popup_modal.js
// 📝 FUNGSI : Standar Sistem Dialog & Modal Kustom Profesional (Dark Glassmorphism)
//             Menggantikan 100% dialog bawaan browser (window.alert & window.confirm)
// ==============================================================================

(function(global) {
  'use strict';

  let modalBackdropEl = null;
  let activeResolver = null;
  let keydownHandler = null;

  /**
   * Menginjeksi stylesheet dan elemen kontainer modal ke dalam DOM secara malas (lazy-init).
   */
  function ensureModalDOM() {
    if (typeof document === 'undefined') return null;
    if (modalBackdropEl && document.body.contains(modalBackdropEl)) {
      return modalBackdropEl;
    }

    if (!document.getElementById('fab-pro-modal-styles')) {
      const style = document.createElement('style');
      style.id = 'fab-pro-modal-styles';
      style.textContent = `
        .fab-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 99999;
          background: rgba(2, 6, 23, 0.80);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 14px;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.18s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .fab-modal-backdrop.is-open {
          opacity: 1;
          pointer-events: auto;
        }
        .fab-modal-card {
          width: 100%;
          max-width: 340px;
          background: linear-gradient(165deg, rgba(30, 41, 59, 0.98) 0%, rgba(15, 23, 42, 0.99) 100%);
          border: 1px solid rgba(56, 189, 248, 0.28);
          border-radius: 14px;
          padding: 16px;
          box-shadow: 0 22px 48px rgba(0, 0, 0, 0.72), inset 0 1px 0 rgba(255, 255, 255, 0.08);
          transform: scale(0.93) translateY(8px);
          transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          position: relative;
          overflow: hidden;
          color: #f8fafc;
        }
        .fab-modal-backdrop.is-open .fab-modal-card {
          transform: scale(1) translateY(0);
        }
        .fab-modal-card::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: linear-gradient(90deg, #38bdf8, #6366f1, #a855f7);
        }
        .fab-modal-card.variant-success {
          border-color: rgba(16, 185, 129, 0.40);
          box-shadow: 0 22px 48px rgba(0, 0, 0, 0.75), 0 0 28px rgba(16, 185, 129, 0.14);
        }
        .fab-modal-card.variant-success::before {
          background: linear-gradient(90deg, #10b981, #38bdf8, #6366f1);
        }
        .fab-modal-card.variant-warning {
          border-color: rgba(245, 158, 11, 0.40);
          box-shadow: 0 22px 48px rgba(0, 0, 0, 0.75), 0 0 24px rgba(245, 158, 11, 0.12);
        }
        .fab-modal-card.variant-warning::before {
          background: linear-gradient(90deg, #f59e0b, #38bdf8);
        }
        .fab-modal-card.variant-danger {
          border-color: rgba(244, 63, 94, 0.45);
          box-shadow: 0 22px 48px rgba(0, 0, 0, 0.75), 0 0 24px rgba(244, 63, 94, 0.15);
        }
        .fab-modal-card.variant-danger::before {
          background: linear-gradient(90deg, #f43f5e, #ef4444);
        }
        .fab-modal-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 11px;
        }
        .fab-modal-header-left {
          display: flex;
          align-items: center;
          gap: 10px;
          min-width: 0;
        }
        .fab-modal-orb {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 17px;
          flex-shrink: 0;
          background: rgba(56, 189, 248, 0.14);
          border: 1px solid rgba(56, 189, 248, 0.32);
        }
        .variant-success .fab-modal-orb {
          background: rgba(16, 185, 129, 0.15);
          border-color: rgba(16, 185, 129, 0.40);
        }
        .variant-warning .fab-modal-orb {
          background: rgba(245, 158, 11, 0.15);
          border-color: rgba(245, 158, 11, 0.40);
        }
        .variant-danger .fab-modal-orb {
          background: rgba(244, 63, 94, 0.15);
          border-color: rgba(244, 63, 94, 0.40);
        }
        .fab-modal-title {
          font-size: 13.5px;
          font-weight: 700;
          color: #f8fafc;
          line-height: 1.25;
        }
        .fab-modal-subtitle {
          font-size: 10px;
          color: #94a3b8;
          margin-top: 1px;
        }
        .fab-modal-badge {
          font-size: 9px;
          font-weight: 700;
          padding: 3px 7px;
          border-radius: 999px;
          letter-spacing: 0.4px;
          text-transform: uppercase;
          flex-shrink: 0;
          background: rgba(56, 189, 248, 0.14);
          color: #38bdf8;
          border: 1px solid rgba(56, 189, 248, 0.3);
        }
        .variant-success .fab-modal-badge {
          background: rgba(16, 185, 129, 0.15);
          color: #34d399;
          border-color: rgba(16, 185, 129, 0.35);
        }
        .variant-warning .fab-modal-badge {
          background: rgba(245, 158, 11, 0.15);
          color: #fbbf24;
          border-color: rgba(245, 158, 11, 0.35);
        }
        .variant-danger .fab-modal-badge {
          background: rgba(244, 63, 94, 0.15);
          color: #fb7185;
          border-color: rgba(244, 63, 94, 0.35);
        }
        .fab-modal-project-pill {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          background: rgba(2, 6, 23, 0.65);
          border: 1px solid rgba(56, 189, 248, 0.25);
          border-radius: 8px;
          padding: 7px 10px;
          margin-bottom: 10px;
        }
        .fab-modal-project-name {
          font-family: monospace;
          font-size: 11px;
          font-weight: 700;
          color: #38bdf8;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .fab-modal-copy-btn {
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.3);
          color: #bae6fd;
          border-radius: 5px;
          font-size: 9.5px;
          font-weight: 600;
          padding: 2px 7px;
          cursor: pointer;
          flex-shrink: 0;
        }
        .fab-modal-copy-btn:hover {
          background: rgba(56, 189, 248, 0.22);
          color: #ffffff;
        }
        .fab-modal-message {
          font-size: 11.5px;
          line-height: 1.5;
          color: #cbd5e1;
          margin-bottom: 14px;
        }
        .fab-modal-actions {
          display: flex;
          gap: 8px;
          justify-content: flex-end;
        }
        .fab-modal-btn {
          flex: 1;
          padding: 8px 12px;
          border-radius: 8px;
          font-size: 11.5px;
          font-weight: 700;
          cursor: pointer;
          border: 1px solid transparent;
          transition: all 0.15s ease;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
        }
        .fab-modal-btn-cancel {
          background: rgba(30, 41, 59, 0.85);
          border-color: rgba(148, 163, 184, 0.25);
          color: #cbd5e1;
        }
        .fab-modal-btn-cancel:hover {
          background: rgba(51, 65, 85, 0.95);
          color: #ffffff;
        }
        .fab-modal-btn-confirm {
          background: linear-gradient(135deg, #2563eb, #6366f1);
          color: #ffffff;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.35);
        }
        .variant-success .fab-modal-btn-confirm {
          background: linear-gradient(135deg, #059669, #2563eb);
          box-shadow: 0 4px 14px rgba(16, 185, 129, 0.35);
        }
        .variant-warning .fab-modal-btn-confirm {
          background: linear-gradient(135deg, #d97706, #2563eb);
          box-shadow: 0 4px 14px rgba(245, 158, 11, 0.30);
        }
        .variant-danger .fab-modal-btn-confirm {
          background: linear-gradient(135deg, #e11d48, #dc2626);
          box-shadow: 0 4px 14px rgba(225, 29, 72, 0.38);
        }
        .fab-modal-btn-confirm:hover {
          filter: brightness(1.08);
          transform: translateY(-1px);
        }
      `;
      document.head.appendChild(style);
    }

    modalBackdropEl = document.createElement('div');
    modalBackdropEl.id = 'fab-pro-modal-backdrop';
    modalBackdropEl.className = 'fab-modal-backdrop';
    modalBackdropEl.setAttribute('role', 'dialog');
    modalBackdropEl.setAttribute('aria-modal', 'true');
    document.body.appendChild(modalBackdropEl);
    return modalBackdropEl;
  }

  /**
   * Menutup modal yang sedang aktif dan menyelesaikan Promise pemanggil.
   */
  function closeActiveModal(resultValue) {
    if (keydownHandler && typeof window !== 'undefined') {
      window.removeEventListener('keydown', keydownHandler);
      keydownHandler = null;
    }
    if (modalBackdropEl) {
      modalBackdropEl.classList.remove('is-open');
    }
    if (activeResolver) {
      const resolve = activeResolver;
      activeResolver = null;
      resolve(resultValue);
    }
  }

  /**
   * Menampilkan dialog modal profesional (Intisari Dark Glassmorphism).
   */
  function openModal(config = {}) {
    const backdrop = ensureModalDOM();
    if (!backdrop) return Promise.resolve(true);

    if (activeResolver) {
      closeActiveModal(false);
    }

    const variant = config.variant || 'info';
    const icon = config.icon || (variant === 'success' ? '🎉' : (variant === 'danger' ? '🗑️' : (variant === 'warning' ? '↻' : '⚡')));
    const title = config.title || 'FlowAutoBridge';
    const subtitle = config.subtitle || 'FlowAutoBridge Studio';
    const badge = config.badge || (variant === 'success' ? 'SUKSES' : 'INFO');
    const projectName = config.projectName || '';
    const message = config.message || '';
    const showCancel = !!config.showCancel;
    const confirmText = config.confirmText || '✓ Mengerti';
    const cancelText = config.cancelText || 'Batal';

    backdrop.innerHTML = `
      <div class="fab-modal-card variant-${variant}">
        <div class="fab-modal-header">
          <div class="fab-modal-header-left">
            <div class="fab-modal-orb">${icon}</div>
            <div>
              <div class="fab-modal-title">${title}</div>
              <div class="fab-modal-subtitle">${subtitle}</div>
            </div>
          </div>
          <span class="fab-modal-badge">${badge}</span>
        </div>
        ${projectName ? `
          <div class="fab-modal-project-pill">
            <span class="fab-modal-project-name" title="${projectName}">📁 ${projectName}</span>
            <button type="button" class="fab-modal-copy-btn" id="fab-modal-copy-project">📋 Salin</button>
          </div>
        ` : ''}
        <div class="fab-modal-message">${message}</div>
        <div class="fab-modal-actions">
          ${showCancel ? `<button type="button" class="fab-modal-btn fab-modal-btn-cancel" id="fab-modal-cancel-btn">${cancelText}</button>` : ''}
          <button type="button" class="fab-modal-btn fab-modal-btn-confirm" id="fab-modal-confirm-btn">${confirmText}</button>
        </div>
      </div>
    `;

    return new Promise((resolve) => {
      activeResolver = resolve;

      const confirmBtn = backdrop.querySelector('#fab-modal-confirm-btn');
      const cancelBtn = backdrop.querySelector('#fab-modal-cancel-btn');
      const copyBtn = backdrop.querySelector('#fab-modal-copy-project');

      if (confirmBtn) {
        confirmBtn.addEventListener('click', () => closeActiveModal(true));
      }
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => closeActiveModal(false));
      }
      if (copyBtn && projectName && navigator.clipboard) {
        copyBtn.addEventListener('click', async () => {
          try {
            await navigator.clipboard.writeText(projectName);
            copyBtn.textContent = '✓ Tersalin';
            setTimeout(() => { copyBtn.textContent = '📋 Salin'; }, 1800);
          } catch (_) {}
        });
      }

      backdrop.onclick = (e) => {
        if (e.target === backdrop) {
          closeActiveModal(showCancel ? false : true);
        }
      };

      keydownHandler = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          closeActiveModal(showCancel ? false : true);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          closeActiveModal(true);
        }
      };
      window.addEventListener('keydown', keydownHandler);

      requestAnimationFrame(() => {
        backdrop.classList.add('is-open');
        if (confirmBtn) confirmBtn.focus();
      });
    });
  }

  function showSuccess(options = {}) {
    return openModal({
      variant: 'success',
      icon: options.icon || '🎉',
      title: options.title || 'Draf CapCut Berhasil Dibuat!',
      subtitle: options.subtitle || 'Injeksi Linimasa CapCut Desktop',
      badge: options.badge || 'SUKSES 100%',
      projectName: options.projectName || '',
      message: options.message || 'Buka aplikasi CapCut Desktop untuk melihat dan mengedit linimasa video Anda.',
      showCancel: false,
      confirmText: options.confirmText || '✓ Mengerti & Tutup'
    });
  }

  function showAlert(options = {}) {
    const opts = typeof options === 'string' ? { message: options } : options;
    return openModal({
      variant: opts.variant || 'info',
      icon: opts.icon || '⚡',
      title: opts.title || 'Informasi FlowAutoBridge',
      subtitle: opts.subtitle || 'Notifikasi Sistem',
      badge: opts.badge || 'INFO',
      projectName: opts.projectName || '',
      message: opts.message || '',
      showCancel: false,
      confirmText: opts.confirmText || '✓ Mengerti'
    });
  }

  function showConfirm(options = {}) {
    const opts = typeof options === 'string' ? { message: options } : options;
    return openModal({
      variant: opts.variant || 'warning',
      icon: opts.icon || '↻',
      title: opts.title || 'Konfirmasi Tindakan',
      subtitle: opts.subtitle || 'Manajemen Antrean Flow',
      badge: opts.badge || 'KONFIRMASI',
      projectName: opts.projectName || '',
      message: opts.message || 'Apakah Anda yakin ingin melanjutkan tindakan ini?',
      showCancel: true,
      confirmText: opts.confirmText || 'Ya, Lanjutkan',
      cancelText: opts.cancelText || 'Batal'
    });
  }

  global.PopupModal = {
    showSuccess,
    showAlert,
    showConfirm,
    closeActiveModal
  };

})(typeof window !== 'undefined' ? window : globalThis);

