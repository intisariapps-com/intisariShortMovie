/**
 * FlowAutoBridge - Canvas Downloader & Storyboard JSON Synchronizer (v2.7.9)
 * SRS-FAB-074: Ekstraksi Prompt Master JSON Kanvas ImageFlow Melalui Main World & Failsafe Storage.
 * Menjamin pembacaan React Props secara utuh (anti-empty prompt) dan modularisasi UI popup.
 */

(function () {
  'use strict';

  // Helper Blacklist Aset UI Google (FAB-SRS-071 & docs/srs/blacklist_aset_ui_flow_dan_bukti_ekstraksi.md)
  const BLOCKED_ASSETS = [
    'ssl.gstatic.com/gb/images/ring/',
    'googleusercontent.com/ogw/',
    'gstatic.com/aitestkitchen/website/flow/icons/',
    'gstatic.com/aitestkitchen/website/flow/banners/',
    'gstatic.com/images/icons/',
    'www.gstatic.com',
    'fonts.gstatic.com',
    '/ring/',
    '/ogw/'
  ];

  function isBlacklistedAssetUrl(url) {
    if (!url || typeof url !== 'string') return true;
    const lower = url.toLowerCase();
    return BLOCKED_ASSETS.some(b => lower.includes(b));
  }

  /**
   * Fungsi pemindai yang diinjeksi langsung ke browser tab dengan world: 'MAIN'.
   * Berjalan di runtime native halaman sehingga memiliki akses penuh ke __reactProps / __reactFiber.
   */
  function scanImageFlowCanvasMainWorld() {
    try {
      const BLOCKED_ASSETS_INNER = [
        'ssl.gstatic.com/gb/images/ring/',
        'googleusercontent.com/ogw/',
        'gstatic.com/aitestkitchen/website/flow/icons/',
        'gstatic.com/aitestkitchen/website/flow/banners/',
        'gstatic.com/images/icons/',
        'www.gstatic.com',
        'fonts.gstatic.com',
        '/ring/',
        '/ogw/'
      ];

      function isBlocked(url) {
        if (!url || typeof url !== 'string') return true;
        const low = url.toLowerCase();
        return BLOCKED_ASSETS_INNER.some(b => low.includes(b));
      }

      // 1. Deteksi apakah ini kanvas ImageFlow sah
      const hasBlueHeading = !!document.querySelector('h1[class*="text-blue-400"], h1.text-blue-400');
      const allBadges = Array.from(document.querySelectorAll('div, span')).filter((b) => {
        if (b.children && b.children.length > 2) return false;
        const txt = (b.innerText || b.textContent || '').trim().toUpperCase();
        return txt.includes('COVER / INTRO') || txt === 'COVER' || /^(?:ADEGAN|ADGN|SCENE)[_\s-]?\d+$/i.test(txt);
      });
      const totalCardsCount = allBadges.length;
      const isImageFlowCanvas = hasBlueHeading || totalCardsCount > 0;

      // 2. Deteksi gambar kandidat adegan
      const candidateImgs = Array.from(document.querySelectorAll('img')).filter((img) => {
        const src = img.src || '';
        if (!src || isBlocked(src)) return false;
        if (img.closest && img.closest('.gb_')) return false;

        const w = img.naturalWidth || img.clientWidth || 0;
        const h = img.naturalHeight || img.clientHeight || 0;
        const isCard = (img.className && (img.className.includes('object-cover') || img.className.includes('w-full'))) || (w >= 100 && h >= 100);
        return (src.startsWith('data:image') || src.startsWith('http') || src.startsWith('blob:')) && isCard;
      });

      const rawItems = [];
      const seenUrls = new Set();
      const seenIds = new Set();

      candidateImgs.forEach((img) => {
        const url = img.src;
        if (seenUrls.has(url)) return;

        // Cari elemen kartu terdekat (anti pergeseran pointer 8 tingkat)
        const cardEl = (img.closest && img.closest('[class*="rounded-2xl"], [class*="bg-[#1a1a1a]"]')) ||
                       img.parentElement?.parentElement ||
                       img.parentElement;

        let sceneLabel = '';
        if (cardEl) {
          const badges = cardEl.querySelectorAll('div, span');
          for (const b of badges) {
            if (b.children && b.children.length > 2) continue;
            const txt = (b.innerText || b.textContent || '').trim().toUpperCase();
            if (txt.includes('COVER') || txt.includes('ADGN') || txt.includes('ADEGAN') || txt.includes('SCENE')) {
              sceneLabel = txt;
              break;
            }
          }
        }

        if (!sceneLabel) return;

        let sceneId = '';
        if (sceneLabel.includes('COVER')) {
          sceneId = 'COVER';
        } else {
          const match = sceneLabel.match(/(?:ADEGAN|ADGN|SCENE)[_\s-]?(\d+)/i);
          if (match && match[1]) sceneId = `ADEGAN_${String(match[1]).padStart(2, '0')}`;
        }

        if (!sceneId || seenIds.has(sceneId)) return;

        seenUrls.add(url);
        seenIds.add(sceneId);

        // Ekstraksi data dari React Props (Main World Direct Access - SRS-FAB-074)
        let cardData = null;
        let cur = cardEl;
        for (let k = 0; k < 4 && cur && !cardData; k++) {
          const fKey = Object.keys(cur).find(key => key.startsWith('__reactFiber') || key.startsWith('__reactProps'));
          if (fKey && cur[fKey]) {
            const mProps = cur[fKey].memoizedProps || cur[fKey];
            if (mProps && mProps.scene && mProps.scene.data) {
              cardData = mProps.scene.data;
            }
          }
          cur = cur.parentElement;
        }

        let cardNarrative = (cardData && cardData.narrative) || '';
        let cardPrompt = (cardData && (cardData.prompt_flow || cardData.image_prompt)) || '';
        let cardVideoPrompt = (cardData && cardData.video_prompt) || '';
        let cardDuration = (cardData && cardData.duration) || 5;

        // Fallback DOM jika React props tidak ditemukan
        if (!cardNarrative && cardEl) {
          const narrEl = cardEl.querySelector('textarea, [class*="font-serif"], [class*="italic"]');
          if (narrEl) {
            cardNarrative = (narrEl.value || narrEl.innerText || narrEl.textContent || '').replace(/^["']|["']$/g, '').trim();
          }
        }

        if (!cardPrompt && cardEl) {
          const promptEls = cardEl.querySelectorAll('textarea');
          for (const pe of promptEls) {
            const val = (pe.value || pe.innerText || '').trim();
            if (val && val !== cardNarrative) {
              cardPrompt = val;
              break;
            }
          }
        }

        rawItems.push({
          id: sceneId,
          filename: `${sceneId}.png`,
          url: url,
          narrative: cardNarrative,
          prompt: cardPrompt,
          data: cardData || {
            id: sceneId,
            narrative: cardNarrative,
            prompt_flow: cardPrompt,
            image_prompt: cardPrompt,
            video_prompt: cardVideoPrompt,
            duration: cardDuration
          }
        });
      });

      // Natural numeric sorting: COVER selalu pertama, diikuti ADEGAN_01..64
      const sortedItems = [...rawItems].sort((a, b) => {
        const idA = String(a.id || '').toUpperCase();
        const idB = String(b.id || '').toUpperCase();
        const isCoverA = idA.includes('COVER');
        const isCoverB = idB.includes('COVER');
        if (isCoverA && !isCoverB) return -1;
        if (!isCoverA && isCoverB) return 1;
        if (isCoverA && isCoverB) return 0;
        const numA = parseInt((idA.match(/\d+/) || [999999])[0], 10);
        const numB = parseInt((idB.match(/\d+/) || [999999])[0], 10);
        if (numA !== numB) return numA - numB;
        return idA.localeCompare(idB);
      });

      // Ekstraksi Judul Proyek Cerdas & Blacklist Kata Reservasi Navigasi UI
      let pTitle = '';
      const INVALID_KW = [
        'pembuat alat', 'tool builder', 'google flow', 'ai test kitchen',
        'alat ini dibuat', 'laporkan konten', 'adegan', 'caption', 'daftar karakter',
        'daftar', 'proyek aktif', 'active project', 'manajemen proyek', 'konfigurasi mesin',
        'negative prompt', 'model visual', 'model video', 'rasio aspek'
      ];

      function isInvalidTitle(text) {
        if (!text || typeof text !== 'string') return true;
        const low = text.trim().toLowerCase();
        return low.length < 3 || low.length > 80 || INVALID_KW.some(kw => low.includes(kw));
      }

      // Prioritas 1: Heading biru ImageFlow atau judul metadata
      const primaryHeading = document.querySelector('h1[class*="text-blue-400"], h1.text-blue-400, span.text-blue-400[title], h1.text-2xl');
      if (primaryHeading) {
        const t = (primaryHeading.getAttribute('title') || primaryHeading.innerText || primaryHeading.textContent || '').trim();
        if (!isInvalidTitle(t)) {
          pTitle = t.replace(/[\\/:*?"<>|]/g, '_').trim();
        }
      }

      // Prioritas 2: Elemen heading lain yang lolos sensor
      if (!pTitle) {
        const headings = Array.from(document.querySelectorAll('h1, h2, h3, [class*="font-black"], [class*="font-bold"]'));
        for (const h of headings) {
          const t = (h.getAttribute('title') || h.innerText || h.textContent || '').trim();
          if (!isInvalidTitle(t)) {
            pTitle = t.replace(/[\\/:*?"<>|]/g, '_').trim();
            break;
          }
        }
      }

      // Ekstraksi Caption Sosial Media jika tersedia
      let pCaption = '';
      const captionEl = document.querySelector('[class*="text-white/80"][class*="italic"], [class*="text-white/90"][class*="italic"]');
      if (captionEl) {
        pCaption = (captionEl.innerText || captionEl.textContent || '').trim();
      }

      // Deteksi Aspek Rasio (9:16 vs 16:9) dari teks prompt kartu
      let detectedRatio = '9:16';
      for (const it of sortedItems) {
        const p = `${it.prompt || ''} ${it.data?.image_prompt || ''} ${it.data?.prompt_flow || ''}`;
        if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) { detectedRatio = '9:16'; break; }
        if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) { detectedRatio = '16:9'; break; }
      }

      const projectJson = {
        title: pTitle || 'Proyek_Storyboard',
        caption: pCaption || '',
        aspect_ratio: detectedRatio,
        video_ratio: detectedRatio,
        total_scenes: sortedItems.length,
        scenes: sortedItems.map((it, idx) => {
          if (it.data) {
            return {
              ...it.data,
              id: it.id,
              narrative: it.data.narrative || it.narrative || (it.id === 'COVER' ? (pTitle || 'Intro') : `Adegan ${idx}`)
            };
          }
          const isCov = String(it.id).toUpperCase().includes('COVER');
          return {
            id: it.id,
            narrative: it.narrative || (isCov ? (pTitle || 'Intro') : `Adegan ${idx}`),
            prompt_flow: it.prompt || '',
            image_prompt: it.prompt || '',
            video_prompt: '',
            duration: 5
          };
        })
      };

      return {
        success: true,
        isImageFlowCanvas: isImageFlowCanvas,
        totalCards: totalCardsCount,
        count: sortedItems.length,
        items: sortedItems,
        projectName: pTitle,
        projectJson: projectJson
      };
    } catch (e) {
      return { success: false, error: e.message, items: [], count: 0, totalCards: 0 };
    }
  }

  /**
   * Rekonsiliasi Failsafe Storage (Layer 2)
   * Mengisi prompt atau narasi yang kosong dari antrean storyboard asli di chrome.storage.local
   */
  async function reconcileWithStorageFailsafe(projectJson, items) {
    if (!projectJson || !projectJson.scenes) return projectJson;

    try {
      const stored = await new Promise(res => {
        chrome.storage.local.get(['storyboardQueue', 'latestActiveStoryboardTitle', 'activeAspectRatio'], res);
      });

      const queue = stored && Array.isArray(stored.storyboardQueue) ? stored.storyboardQueue : [];
      if (queue.length === 0) {
        if (!projectJson.aspect_ratio) {
          projectJson.aspect_ratio = stored?.activeAspectRatio || '9:16';
          projectJson.video_ratio = projectJson.aspect_ratio;
        }
        return projectJson;
      }

      const queueMap = new Map();
      queue.forEach((sq, idx) => {
        if (sq.id) queueMap.set(String(sq.id).toUpperCase(), sq);
        queueMap.set(`INDEX_${idx}`, sq);
      });

      let updated = false;
      const patchedScenes = projectJson.scenes.map((s, idx) => {
        const sId = String(s.id || '').toUpperCase();
        const matched = queueMap.get(sId) || queueMap.get(`INDEX_${idx}`);
        if (!matched) return s;

        const needsPrompt = !s.image_prompt && !s.prompt_flow;
        const needsNarrative = !s.narrative || s.narrative.startsWith('Adegan ');

        if (needsPrompt || needsNarrative) {
          updated = true;
          const merged = {
            ...s,
            narrative: needsNarrative ? (matched.narrative || s.narrative) : s.narrative,
            prompt_flow: s.prompt_flow || matched.prompt_flow || matched.image_prompt || '',
            image_prompt: s.image_prompt || matched.image_prompt || matched.prompt_flow || '',
            video_prompt: s.video_prompt || matched.video_prompt || '',
            duration: s.duration || matched.duration || 5
          };
          if (matched.headline) merged.headline = matched.headline;
          if (matched.editorial_text) merged.editorial_text = matched.editorial_text;
          return merged;
        }
        return s;
      });

      if (updated || stored.activeAspectRatio) {
        projectJson.scenes = patchedScenes;
        if ((!projectJson.title || projectJson.title === 'Proyek_Storyboard') && stored.latestActiveStoryboardTitle) {
          projectJson.title = stored.latestActiveStoryboardTitle;
        }
        projectJson.aspect_ratio = stored.activeAspectRatio || projectJson.aspect_ratio || '9:16';
        projectJson.video_ratio = projectJson.aspect_ratio;
      }
    } catch (e) {
      console.warn('Rekonsiliasi failsafe storage dilewati:', e);
    }
    return projectJson;
  }

  /**
   * Memindai seluruh frame dengan injeksi world: 'MAIN'
   */
  function scanScenesAcrossAllFrames(tabId, callback) {
    if (!tabId) {
      if (callback) callback({ success: false, items: [], count: 0, totalCards: 0 });
      return;
    }

    if (chrome.scripting && chrome.scripting.executeScript) {
      chrome.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        world: 'MAIN', // Mengakses React Props langsung di halaman (SRS-FAB-074)
        func: scanImageFlowCanvasMainWorld
      }, async (results) => {
        if (chrome.runtime.lastError || !results || results.length === 0) {
          // Fallback ke pesan content script biasa jika executeScript gagal
          chrome.tabs.sendMessage(tabId, { action: 'fab_check_scenes_on_screen' }, async (res) => {
            if (res && res.projectJson) {
              res.projectJson = await reconcileWithStorageFailsafe(res.projectJson, res.items);
            }
            if (callback) callback(res || { success: false, items: [], count: 0, totalCards: 0 });
          });
          return;
        }

        // Arbitrase Pemilihan Frame: Prioritaskan frame kanvas ImageFlow yang memiliki kartu/judul
        let best = null;
        for (const r of results) {
          if (r && r.result && r.result.success) {
            const res = r.result;
            if (res.isImageFlowCanvas) {
              if (!best || !best.isImageFlowCanvas || res.count > best.count || res.totalCards > (best.totalCards || 0)) {
                best = res;
              }
            } else if (!best && res.count > 0) {
              best = res;
            }
          }
        }

        const finalResult = best || { success: false, items: [], count: 0, totalCards: 0 };
        if (finalResult.projectJson) {
          finalResult.projectJson = await reconcileWithStorageFailsafe(finalResult.projectJson, finalResult.items);
        }

        if (callback) callback(finalResult);
      });
    } else {
      chrome.tabs.sendMessage(tabId, { action: 'fab_check_scenes_on_screen' }, async (res) => {
        if (res && res.projectJson) {
          res.projectJson = await reconcileWithStorageFailsafe(res.projectJson, res.items);
        }
        if (callback) callback(res || { success: false, items: [], count: 0, totalCards: 0 });
      });
    }
  }

  /**
   * Eksekusi pengunduhan berkas master JSON dan seluruh gambar adegan
   */
  async function executeDownloadItems(items, detectedTitle, projectJsonData, cachedScanResult, updateStatus) {
    const cleanTitle = String(detectedTitle || 'Proyek')
      .replace(/\(?part\s*\d+\)?/gi, '')
      .replace(/[\\/:*?"<>|]+/g, ' ')
      .replace(/[^\w\s\-]+/g, ' ')
      .trim()
      .split(/\s+/)
      .slice(0, 5)
      .join('_') || 'Proyek';

    // Prioritas 1: Ambil activeProjectFolder yang sudah aktif dari chrome.storage.local (agar tetap 1 sesi eksperimen yang sama)
    const stored = await new Promise(res => {
      chrome.storage.local.get(['activeProjectFolder', 'latestActiveStoryboardTitle'], res);
    });

    let projectFolder = '';
    const storedFolder = stored && stored.activeProjectFolder ? String(stored.activeProjectFolder).trim() : '';

    if (storedFolder && (storedFolder.toLowerCase().startsWith(cleanTitle.toLowerCase()) || cleanTitle.toLowerCase().startsWith(storedFolder.toLowerCase().split('_').slice(0, 2).join('_')))) {
      projectFolder = storedFolder;
    } else if (storedFolder && !detectedTitle) {
      projectFolder = storedFolder;
    } else if (/_[a-z0-9]{4}$/i.test(cleanTitle)) {
      projectFolder = cleanTitle;
    } else {
      // Buat folder baru dengan 4 karakter acak unik untuk isolasi eksperimen multi-run (SRS-FAB-056)
      const randHash = Math.random().toString(36).substring(2, 6);
      projectFolder = `${cleanTitle}_${randHash}`;
    }

    chrome.storage.local.set({ activeProjectFolder: projectFolder });

    if (updateStatus) {
      updateStatus(`Mengunduh berkas JSON & ${items.length} gambar ke Downloads/intisariShortMovie/${projectFolder}/...`);
    }

    // 1. Unduh Berkas Storyboard JSON Gabungan (SRS-FAB-073/074)
    let masterJson = projectJsonData || (cachedScanResult && cachedScanResult.projectJson);
    if (masterJson) {
      masterJson = await reconcileWithStorageFailsafe(masterJson, items);
      try {
        const jsonStr = typeof masterJson === 'string' ? masterJson : JSON.stringify(masterJson, null, 2);
        const jsonBytes = new TextEncoder().encode(jsonStr);
        const base64Json = btoa(Array.from(jsonBytes, b => String.fromCharCode(b)).join(''));
        const jsonUri = `data:application/json;charset=utf-8;base64,${base64Json}`;

        chrome.runtime.sendMessage({
          action: 'download_storyboard_json',
          dataUrl: jsonUri,
          filename: `${projectFolder}.json`,
          projectFolder: projectFolder,
          subfolder: 'intisariShortMovie'
        });
      } catch (je) {
        console.warn('Gagal menyiapkan unduhan JSON master:', je);
      }
    }

    // 2. Unduh Seluruh Gambar Adegan
    let count = 0;
    for (const it of items) {
      chrome.runtime.sendMessage({
        action: 'fab_download_flow_image',
        imageUrl: it.url,
        filename: `${it.id}.png`,
        projectFolder: projectFolder,
        subfolder: 'intisariShortMovie'
      });
      count++;
      await new Promise(r => setTimeout(r, 80));
    }

    return { count, projectFolder };
  }

  // Publikasikan API ke objek global window
  window.FlowCanvasDownloader = {
    scanScenesAcrossAllFrames,
    executeDownloadItems,
    reconcileWithStorageFailsafe
  };

})();

