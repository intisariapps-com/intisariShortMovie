// ==============================================================================
// 📁 FILE   : extension/groq_whisper_client.js
// 📝 FUNGSI : Klien Fetch Langsung ke Groq Whisper Cloud API (SRS-FAB-STANDALONE-001)
//             Menghasilkan stempel waktu kata (word timestamps) ultra cepat (< 2s).
// ==============================================================================

(function(global) {
  'use strict';

  const GROQ_API_ENDPOINT = 'https://api.groq.com/openai/v1/audio/transcriptions';
  const STORAGE_KEY_GROQ = 'groq_api_key_standalone';

  /**
   * Mengambil API key yang tersimpan di chrome.storage.local.
   * @returns {Promise<string>}
   */
  async function getStoredApiKey() {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([STORAGE_KEY_GROQ], (res) => {
          resolve((res && res[STORAGE_KEY_GROQ]) || '');
        });
      } else {
        resolve(localStorage.getItem(STORAGE_KEY_GROQ) || '');
      }
    });
  }

  /**
   * Menyimpan API key ke chrome.storage.local.
   * @param {string} apiKey
   * @returns {Promise<void>}
   */
  async function setStoredApiKey(apiKey) {
    const cleanKey = (apiKey || '').trim();
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [STORAGE_KEY_GROQ]: cleanKey }, () => resolve());
      } else {
        localStorage.setItem(STORAGE_KEY_GROQ, cleanKey);
        resolve();
      }
    });
  }

  /**
   * Mengirim audio (Blob WAV 16kHz atau MP3) ke Groq Whisper API untuk transkripsi kata presisi.
   * @param {Blob|File} audioBlob - Audio file atau blob hasil resample 16kHz
   * @param {string} [apiKeyOverride] - Kunci API opsional (jika tidak disediakan, baca dari storage)
   * @returns {Promise<{text: string, duration: number, words: Array<{word: string, start: number, end: number}>}>}
   */
  async function transcribeAudio(audioBlob, apiKeyOverride) {
    const apiKey = (apiKeyOverride || await getStoredApiKey() || '').trim();
    if (!apiKey) {
      throw new Error('Kunci API Groq belum diisi. Masukkan Groq API Key terlebih dahulu.');
    }

    if (!audioBlob) {
      throw new Error('Berkas audio tidak tersedia untuk ditranskripsi.');
    }

    const formData = new FormData();
    // Gunakan nama file .wav jika blob, atau nama file aslinya
    const fileName = audioBlob.name || 'audio_resampled_16k.wav';
    formData.append('file', audioBlob, fileName);
    formData.append('model', 'whisper-large-v3');
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'word');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90000); // 90s timeout

    let res;
    try {
      res = await fetch(GROQ_API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`
        },
        body: formData,
        signal: controller.signal
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        throw new Error('Koneksi ke Groq Whisper API melebihi batas waktu (Timeout 90s).');
      }
      throw new Error(`Gagal menghubungi Groq API: ${err.message || err}`);
    } finally {
      clearTimeout(timeoutId);
    }

    if (!res.ok) {
      let errMsg = `HTTP ${res.status}`;
      try {
        const errJson = await res.json();
        if (errJson && errJson.error && errJson.error.message) {
          errMsg = errJson.error.message;
        }
      } catch (_) {
        try {
          errMsg = await res.text();
        } catch (_) {}
      }

      if (res.status === 401) {
        throw new Error('Kunci API Groq tidak valid atau kedaluwarsa. Periksa kembali kunci Anda.');
      } else if (res.status === 413) {
        throw new Error('Ukuran berkas audio terlalu besar (maksimal 25MB untuk Groq API).');
      } else if (res.status === 429) {
        throw new Error('Batas panggilan Groq API tercapai (Rate Limit / Quota Exceeded). Coba beberapa saat lagi.');
      }
      throw new Error(`Groq Whisper API Gagal: ${errMsg}`);
    }

    const data = await res.json();
    return {
      text: data.text || '',
      duration: data.duration || 0,
      words: Array.isArray(data.words) ? data.words : []
    };
  }

  /**
   * Validasi cepat format kunci API Groq (gsk_...).
   */
  function isValidApiKeyFormat(key) {
    if (!key || typeof key !== 'string') return false;
    const clean = key.trim();
    return clean.startsWith('gsk_') && clean.length > 20;
  }

  // Registrasi global
  global.GroqWhisperClient = {
    transcribeAudio,
    getStoredApiKey,
    setStoredApiKey,
    isValidApiKeyFormat,
    STORAGE_KEY_GROQ
  };

})(typeof window !== 'undefined' ? window : globalThis);

