// Polyfill chrome API jika dijalankan langsung di PyWebView tanpa ekstensi Chrome
if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
  window.chrome = {
    storage: {
      local: {
        set: function(obj, cb) { if (cb) cb(); },
        get: function(keys, cb) { if (cb) cb({}); }
      }
    },
    runtime: {
      onMessage: {
        addListener: function() {}
      },
      sendMessage: function(msg, cb) {
        if (msg.action === 'download_storyboard' && msg.data) {
          fetch('http://127.0.0.1:8000/api/v1/save-storyboard-from-gemini', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msg.data)
          })
          .then(r => r.json())
          .then(res => {
            console.log('[PyWebView-Bridge] Storyboard berhasil disimpan:', res);
          })
          .catch(err => {
            console.error('[PyWebView-Bridge] Gagal menyimpan storyboard:', err);
          });
        }
        if (cb) cb({ success: true });
      }
    }
  };
}

// Mendengarkan pesan dari popup untuk memulai ekstraksi
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extract_table') {
    try {
      console.log('FlowAutoBridge: Memulai pemindaian elemen chat Gemini dengan proteksi Bab 1...');
      executeExtractionWithBab1Guard(
        (res) => {
          sendResponse({ 
            success: true, 
            count: res.count, 
            parts: res.parts, 
            filenames: res.filenames, 
            isMultiChapter: res.isMultiChapter 
          });
        },
        (errMsg) => {
          sendResponse({ success: false, error: errMsg });
        }
      );
      return true; // Menjaga channel komunikasi asinkron tetap aktif
    } catch (e) {
      console.error('FlowAutoBridge Exception:', e);
      sendResponse({ success: false, error: e.message });
    }
  }
});

/**
 * Normalisasi teks kurung siku menjadi ID adegan standar dengan padding nol (misal: "Adegan 1" -> "ADEGAN_01")
 */
function normalizeId(bracketText) {
  if (!bracketText) return 'ADEGAN_01';
  const str = String(bracketText).trim();

  // 1. Jika sudah berformat sub-scene seperti ADEGAN_01_A atau ADEGAN_01_1
  const subMatch = str.match(/ADEGAN_(\d+)_([A-Za-z0-9]+)/i);
  if (subMatch) {
    const num = parseInt(subMatch[1], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}_${subMatch[2].toUpperCase()}`;
  }

  // 2. Cek format seperti "Adegan 31 A" atau "Adegan 31 Shot 1"
  const adeganSub = str.match(/(?:adegan|scene)\s*(\d+)\s*[-_ ]*\s*([A-Za-z])/i);
  if (adeganSub) {
    const num = parseInt(adeganSub[1], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}_${adeganSub[2].toUpperCase()}`;
  }

  // 3. Adegan tunggal standar (Adegan 1 -> ADEGAN_01)
  const numMatch = str.match(/\d+/);
  if (numMatch) {
    const num = parseInt(numMatch[0], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}`;
  }
  return str.toUpperCase().replace(/[\s\-]+/g, '_');
}

/**
 * Ekstraksi judul video, judul bab lanjutan, dan caption media sosial dari blok kode text Gemini
 */
function extractTitleAndCaption(container) {
  let videoTitle = '';
  let chapterTitle = '';
  let genericTitle = '';
  let caption = '';
  let cover_prompt = '';
  
  const elements = container.querySelectorAll('*');
  let lastLabel = null;
  
  for (let i = 0; i < elements.length; i++) {
    const el = elements[i];
    
    // Skip sub-elemen di dalam pre
    if (el.closest('pre') && el.tagName !== 'PRE') {
      continue;
    }
    
    if (el.tagName === 'PRE') {
      const codeText = sanitizeCleanText(el.innerText || el.textContent || '');
      if (lastLabel === 'judul_bab') {
        chapterTitle = codeText;
        lastLabel = null;
      } else if (lastLabel === 'judul_video') {
        videoTitle = codeText;
        lastLabel = null;
      } else if (lastLabel === 'judul') {
        genericTitle = codeText;
        lastLabel = null;
      } else if (lastLabel === 'caption') {
        caption = codeText;
        lastLabel = null;
      } else if (lastLabel === 'cover_prompt') {
        cover_prompt = codeText;
        lastLabel = null;
      }
      continue;
    }
    
    // Pastikan hanya membaca teks dari elemen daun
    const hasBlockChildren = Array.from(el.children).some(child => 
      ['DIV', 'P', 'UL', 'LI', 'PRE', 'BLOCKQUOTE', 'TABLE'].includes(child.tagName)
    );
    if (hasBlockChildren) {
      continue;
    }
    
    const text = (el.innerText || el.textContent || '').trim();
    if (!text) continue;

    // Cek kemungkinan inline title (misal: "Judul Bab Lanjutan: Misteri Peradaban bab 03" atau "Judul Video: ...")
    const inlineBabMatch = text.match(/^(?:===)?\s*(?:judul\s+bab(?:\s+lanjutan)?|header\s+bab\s+lanjutan|judul\s+lanjutan|judul\s+kedua)\s*[:=\-]\s*["“']?([^"”\n\r]+)["”']?/i);
    if (inlineBabMatch && inlineBabMatch[1].trim()) {
      chapterTitle = inlineBabMatch[1].trim();
    }
    const inlineVideoMatch = text.match(/^(?:===)?\s*(?:judul\s+video|judul\s+utama)\s*[:=\-]\s*["“']?([^"”\n\r]+)["”']?/i);
    if (inlineVideoMatch && inlineVideoMatch[1].trim()) {
      videoTitle = inlineVideoMatch[1].trim();
    }

    const cleanText = text.replace(/[\*\_\~:#=\-]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
    
    // 1. Deteksi Label Judul Bab Lanjutan (Bab 2, 3, dst.) - Prioritas Tertinggi untuk nama file bab
    if (
      cleanText.includes('judul bab') ||
      cleanText.includes('bab lanjutan') ||
      cleanText.includes('judul lanjutan') ||
      cleanText.includes('judul kedua') ||
      cleanText.includes('judul part') ||
      cleanText.includes('judul episode') ||
      /^bab\s*\d+\s*judul/i.test(cleanText) ||
      /^judul\s*bab/i.test(cleanText)
    ) {
      lastLabel = 'judul_bab';
    } 
    // 2. Deteksi Label Judul Video Utama (Bab 1)
    else if (
      cleanText.includes('judul video') ||
      cleanText.includes('judul utama') ||
      cleanText.includes('judul film') ||
      cleanText.includes('judul movie') ||
      cleanText.includes('judul short') ||
      cleanText.includes('judul cerita') ||
      cleanText.includes('judul proyek')
    ) {
      lastLabel = 'judul_video';
    } 
    // 3. Fallback Judul Umum
    else if (cleanText === 'judul' || cleanText === 'title' || cleanText.startsWith('judul ')) {
      lastLabel = 'judul';
    } 
    // 4. Deteksi Caption Sosial Media
    else if (
      cleanText.includes('caption sosial media') ||
      cleanText.includes('caption sosmed') ||
      cleanText.includes('deskripsi video') ||
      cleanText.includes('deskripsi youtube') ||
      cleanText === 'caption'
    ) {
      lastLabel = 'caption';
    } 
    // 5. Deteksi Prompt Cover / Thumbnail
    else if (
      cleanText.includes('prompt cover') ||
      cleanText.includes('cover video') ||
      cleanText.includes('thumbnail') ||
      cleanText.includes('cover prompt')
    ) {
      lastLabel = 'cover_prompt';
    }
  }
  
  // Prioritaskan chapterTitle jika ada (misal Bab 2+: "Misteri Peradaban bab 03"),
  // jika tidak ada gunakan videoTitle (Bab 1) atau genericTitle
  const title = chapterTitle || videoTitle || genericTitle || '';
  
  return { 
    title, 
    caption, 
    cover_prompt,
    video_title: videoTitle,
    chapter_title: chapterTitle
  };
}

/**
 * Membagi satu kalimat narasi menjadi beberapa potongan proporsional untuk masing-masing shot.
 */
function splitNarrativeForShots(narrative, numShots = 2) {
  const cleanText = (narrative || "").trim();
  if (!cleanText || numShots <= 1) {
    return Array(numShots).fill(cleanText);
  }

  const words = cleanText.split(/\s+/).filter(Boolean);
  if (words.length <= numShots) {
    const res = [...words];
    while (res.length < numShots) res.push("");
    return res.slice(0, numShots);
  }

  const midIdx = Math.floor(words.length / 2);
  let bestSplit = midIdx;

  for (let offset = 0; offset < Math.min(4, midIdx); offset++) {
    for (const cand of [midIdx - offset, midIdx + offset]) {
      if (cand > 0 && cand < words.length) {
        const prevWord = words[cand - 1];
        if (/[,\;\:\.\?\!\-]/.test(prevWord)) {
          bestSplit = cand;
          break;
        }
      }
    }
    if (bestSplit !== midIdx) break;
  }

  const part1 = words.slice(0, bestSplit).join(" ").trim();
  const part2 = words.slice(bestSplit).join(" ").trim();
  return [part1, part2];
}

/**
 * Membersihkan residu teks UI Gemini seperti kata "Plaintext" dan header decorator
 */
function sanitizeCleanText(str) {
  if (!str) return "";
  let s = String(str).trim();
  // 1. Buang kata "Plaintext" di awal teks (bisa diikuti newline, carriage return, atau spasi berulang)
  s = s.replace(/^plaintext[\s\r\n]+/i, "").trim();
  // 2. Cek apakah baris pertama tepat kata "Plaintext"
  const lines = s.split(/\r?\n/);
  if (lines.length > 1 && lines[0].trim().toLowerCase() === "plaintext") {
    s = lines.slice(1).join("\n").trim();
  }
  // 3. Jika teks hanya berupa kata "Plaintext"
  if (s.toLowerCase() === "plaintext") {
    return "";
  }
  return s;
}

/**
 * Menyimpan adegan ke antrean target: jika memuat multi-shot, dipecah menjadi Flattened Sub-Scenes (_A, _B)
 */
function pushSceneWithShots(scene, targetArray) {
  if (!scene) return;
  const shots = scene.shots || [];
  
  if (shots.length > 1) {
    const letters = ['A', 'B', 'C', 'D', 'E'];
    const splitNarratives = splitNarrativeForShots(scene.narrative, shots.length);
    const baseId = scene.id || 'ADEGAN_01';

    shots.forEach((shot, sIdx) => {
      const letter = letters[sIdx] || `_${sIdx + 1}`;
      const subId = `${baseId}_${letter}`;
      const pText = sanitizeCleanText(shot.prompt || '');
      const pLower = pText.toLowerCase();
      let shotType = 'Standard Shot';
      if (pLower.includes('extreme wide')) shotType = 'Extreme Wide Shot';
      else if (pLower.includes('wide shot')) shotType = 'Wide Shot';
      else if (pLower.includes('close up') || pLower.includes('closeup')) shotType = 'Close Up';
      else if (pLower.includes('medium shot')) shotType = 'Medium Shot';
      else if (pLower.includes('macro')) shotType = 'Macro Shot';

      targetArray.push({
        id: subId,
        parent_scene: baseId,
        shot_number: shot.shot_number || (sIdx + 1),
        shot_type: shotType,
        narrative: sanitizeCleanText(splitNarratives[sIdx] || ''),
        translation: sanitizeCleanText(scene.translation || ''),
        image_prompt: pText,
        prompt_flow: pText,
        video_prompt: sanitizeCleanText(scene.video_prompt || ''),
        duration: 4
      });
    });
  } else {
    // Adegan standar (1 shot)
    const rawPrompt = (shots.length === 1 && shots[0].prompt) ? shots[0].prompt : (scene.image_prompt || scene.prompt_flow || '');
    const finalPrompt = sanitizeCleanText(rawPrompt);
    targetArray.push({
      ...scene,
      narrative: sanitizeCleanText(scene.narrative || ''),
      translation: sanitizeCleanText(scene.translation || ''),
      image_prompt: finalPrompt,
      prompt_flow: finalPrompt,
      video_prompt: sanitizeCleanText(scene.video_prompt || ''),
      duration: scene.duration || 4
    });
  }
}

/**
 * Ekstraksi storyboard dari elemen tabel HTML (Markdown table yang dirender oleh Gemini)
 */
function extractFromHtmlTable(container) {
  const tables = container.querySelectorAll('table');
  if (!tables || tables.length === 0) return null;

  for (let t = 0; t < tables.length; t++) {
    const table = tables[t];
    const rows = Array.from(table.querySelectorAll('tr'));
    if (rows.length < 2) continue;

    // 1. Identifikasi header
    const headerRow = table.querySelector('thead tr') || rows[0];
    const headerCells = Array.from(headerRow.querySelectorAll('th, td'));

    let colScene = -1;
    let colNarrative = -1;
    let colImage = -1;
    let colVideo = -1;

    headerCells.forEach((cell, idx) => {
      const hText = (cell.innerText || cell.textContent || '').trim().toLowerCase();
      // Deteksi kolom video motion / video prompt (Variabel Ketiga)
      if (/(?:video\s*(?:motion|prompt)|ai\s*video|motion|gerakan)/i.test(hText)) {
        colVideo = idx;
      } 
      // Deteksi kolom prompt gambar / image prompt
      else if (/(?:image|gambar|visual)/i.test(hText) || (/(?:prompt)/i.test(hText) && colImage === -1)) {
        colImage = idx;
      } 
      // Deteksi kolom voiceover / narasi
      else if (/(?:voiceover|narasi|narrative|\bvo\b|script|naskah|dialog)/i.test(hText)) {
        colNarrative = idx;
      } 
      // Deteksi kolom scene / adegan
      else if (/(?:scene|adegan|\bno\b|nomor|\bshot\b)/i.test(hText)) {
        colScene = idx;
      }
    });

    const hasDetectedColumns = colNarrative !== -1 && (colImage !== -1 || colVideo !== -1);

    // Tentukan baris-baris data
    let bodyRows = [];
    const tbody = table.querySelector('tbody');
    if (tbody) {
      bodyRows = Array.from(tbody.querySelectorAll('tr'));
      if (!table.querySelector('thead') && bodyRows.length > 0) {
        bodyRows = bodyRows.slice(1);
      }
    } else {
      bodyRows = rows.slice(1);
    }

    // Fallback jika nama kolom tidak cocok regex tapi ada 3-4 kolom
    if (!hasDetectedColumns && headerCells.length >= 3) {
      colScene = 0;
      colNarrative = 1;
      colImage = 2;
      if (headerCells.length >= 4) {
        colVideo = 3;
      }
    } else if (!hasDetectedColumns) {
      continue;
    }

    const scenes = [];
    bodyRows.forEach((row, rIdx) => {
      const cells = Array.from(row.querySelectorAll('td, th'));
      if (cells.length < 2) return;

      const rawSceneText = (colScene !== -1 && cells[colScene]) 
        ? (cells[colScene].innerText || cells[colScene].textContent || '').trim() 
        : `Adegan ${rIdx + 1}`;
      
      const narrativeText = (colNarrative !== -1 && cells[colNarrative]) 
        ? (cells[colNarrative].innerText || cells[colNarrative].textContent || '').trim() 
        : '';
      
      const imagePromptText = (colImage !== -1 && cells[colImage]) 
        ? (cells[colImage].innerText || cells[colImage].textContent || '').trim() 
        : '';
      
      const videoPromptText = (colVideo !== -1 && cells[colVideo]) 
        ? (cells[colVideo].innerText || cells[colVideo].textContent || '').trim() 
        : '';

      // Lewati baris kosong
      if (!narrativeText && !imagePromptText && !videoPromptText) return;

      const normId = normalizeId(rawSceneText || `Adegan ${rIdx + 1}`);

      scenes.push({
        id: normId,
        narrative: narrativeText,
        translation: '',
        image_prompt: imagePromptText,
        video_prompt: videoPromptText,
        prompt_flow: imagePromptText
      });
    });

    if (scenes.length > 0) {
      console.log(`FlowAutoBridge: Berhasil mengekstrak ${scenes.length} adegan dari HTML Table Gemini.`);
      return scenes;
    }
  }

  return null;
}

/**
 * Ekstraksi storyboard dari format visual terstruktur (brackets + code blocks + bullet list)
 */
function extractFromVisualFormat(container) {
  const result = [];
  let currentScene = null;
  let lastLabel = null;
  let currentShotNumber = null;

  // Temukan semua sub-elemen di dalam container untuk pemindaian DOM terurut
  const elements = container.querySelectorAll('*');

  for (let i = 0; i < elements.length; i++) {
    const el = elements[i];
    // Lewati elemen anak di dalam tag PRE (seperti tag CODE di dalam PRE) untuk menghindari redundansi teks
    if (el.closest('pre') && el.tagName !== 'PRE') {
      continue;
    }

    // Lewati panel tombol agar tidak mengganggu pencarian teks
    if (el.closest('.flow-bridge-panel')) {
      continue;
    }

    // Jika tag adalah PRE atau tag CODE mandiri (blok kode abu-abu), baca isinya sebagai blok kode teks bersih
    // CATATAN: JANGAN masukkan elemen decorator (code-block-decorator) agar kata header "Plaintext" tidak mengontaminasi prompt!
    const isCodeBlock = el.tagName === 'PRE' || 
                        (el.tagName === 'CODE' && !el.closest('pre'));

    if (isCodeBlock) {
      const codeText = el.innerText || el.textContent || '';
      let cleanCode = sanitizeCleanText(codeText);

      // Jika isinya kosong atau tidak memuat karakter alfanumerik, lewati!
      if (!cleanCode || !/[a-zA-Z0-9]/.test(cleanCode)) {
        continue;
      }

      if (currentScene) {
        if (lastLabel === 'narasi') {
          // Non-Overwrite Guard: Jangan biarkan blok pre liar berikutnya menimpa narasi adegan yang sudah sah
          if (!currentScene.narrative) {
            currentScene.narrative = cleanCode;
          }
          lastLabel = null; // reset setelah dipakai
        } else if (lastLabel === 'terjemahan') {
          if (!currentScene.translation) currentScene.translation = cleanCode;
          lastLabel = null; // reset setelah dipakai
        } else if (lastLabel === 'shot' || lastLabel === 'image_prompt' || lastLabel === 'prompt_flow') {
          const sNo = currentShotNumber || (currentScene.shots.length + 1);
          currentScene.shots.push({
            shot_number: sNo,
            prompt: cleanCode
          });
          if (!currentScene.image_prompt) {
            currentScene.image_prompt = cleanCode;
            currentScene.prompt_flow = cleanCode;
          }
          lastLabel = null;
          currentShotNumber = null;
        } else if (lastLabel === 'video_prompt') {
          if (!currentScene.video_prompt) currentScene.video_prompt = cleanCode;
          lastLabel = null; // reset setelah dipakai
        }
      }
      continue;
    }

    // Hanya baca teks dari elemen daun (tidak memiliki anak bertipe layout/blok)
    // agar tidak mendapatkan teks gabungan dari elemen kontainer besar.
    // Dikecualikan tag PRE/CODE dari filter block children agar label pembungkus PRE (seperti LI) tetap diproses.
    const hasBlockChildren = Array.from(el.children).some(child => 
      ['DIV', 'P', 'UL', 'LI', 'BLOCKQUOTE', 'TABLE'].includes(child.tagName)
    );
    if (hasBlockChildren) {
      continue;
    }

    // Jika elemen memuat tag PRE atau CODE di dalamnya, buang teks kode tersebut agar tidak ikut terbaca sebagai teks label luar
    let text = '';
    if (el.querySelector('pre, code, .code-block')) {
      const clone = el.cloneNode(true);
      const codeElements = clone.querySelectorAll('pre, code, .code-block');
      codeElements.forEach(item => {
        if (item.remove) item.remove();
        else if (item.parentNode) item.parentNode.removeChild(item);
      });
      text = (clone.innerText || clone.textContent || '').trim();
    } else {
      text = (el.innerText || el.textContent || '').trim();
    }
    if (!text) continue;

    // Hilangkan karakter markdown bold/italic seperti *, _, ~ untuk pencocokan teks
    const cleanText = text.replace(/[\*\_\~]/g, '').trim();

    // DETEKSI BAGIAN AKHIR STORYBOARD (REKAP / ESTIMASI / FULL VOICEOVER SCRIPTS / TEKS PENUTUP)
    const lowerTextToCheck = cleanText.toLowerCase();
    if (lowerTextToCheck.includes('rekap full narasi') || 
        lowerTextToCheck.includes('estimasi durasi') || 
        lowerTextToCheck.includes('durasi final') || 
        lowerTextToCheck.includes('rekap narasi') || 
        lowerTextToCheck.includes('rekap naskah') || 
        lowerTextToCheck.includes('naskah voiceover') || 
        lowerTextToCheck.includes('full voiceover') || 
        lowerTextToCheck.includes('full script') || 
        lowerTextToCheck.includes('skrip lengkap') || 
        lowerTextToCheck.includes('naskah vo') || 
        lowerTextToCheck.includes('audio script') || 
        lowerTextToCheck.includes('voiceover penuh') || 
        lowerTextToCheck.includes('naskah utuh') || 
        lowerTextToCheck.includes('naskah lengkap') || 
        lowerTextToCheck.includes('tips produksi') ||
        lowerTextToCheck.includes('semua naskah') ||
        lowerTextToCheck.includes('semua prompt') ||
        lowerTextToCheck.includes('langsung menyalin prompt') ||
        lowerTextToCheck.startsWith('estimasi total durasi')) {
      
      if (currentScene && (currentScene.narrative || currentScene.image_prompt || currentScene.prompt_flow || currentScene.video_prompt || (currentScene.shots && currentScene.shots.length > 0))) {
        if (currentScene.image_prompt && !currentScene.prompt_flow) currentScene.prompt_flow = currentScene.image_prompt;
        if (currentScene.prompt_flow && !currentScene.image_prompt) currentScene.image_prompt = currentScene.prompt_flow;
        pushSceneWithShots(currentScene, result);
        currentScene = null;
      }
      break; // Hentikan ekstraksi secara aman agar adegan terakhir tidak tertimpa oleh naskah rekap penuh
    }

    // Cocokkan pola nama adegan (misal "[ID Adegan 1]", "[Adegan 1]", "[ID Adegan 1]Narasi:", "Adegan 25", "01 (0:00-0:04)")
    let rawId = null;
    let hasInlineVo = false;
    let inlineVoText = "";

    const bracketSceneMatch = cleanText.match(/^[\s\-\*•o#]*\[(?:id\s*)?([^\]]+)\](.*)$/i);
    const parenMatch = cleanText.match(/^[\s\-\*•o]*\(([^)]+)\)[\s:]*$/);
    
    if (bracketSceneMatch) {
      const innerId = bracketSceneMatch[1].trim();
      // Pastikan bukan bracket metadata lain seperti [Bahasa Indonesia]
      if (/(?:adegan|scene|\b\d+\b)/i.test(innerId)) {
        rawId = innerId;
        const remainder = (bracketSceneMatch[2] || "").trim();
        if (remainder) {
          const voCheck = remainder.match(/^(?:narasi|voiceover|vo|narrative)(?:\s*\([^)]*\))?\s*[:=]?\s*["“']?([\s\S]*?)["”']?$/i);
          if (voCheck) {
            hasInlineVo = true;
            inlineVoText = (voCheck[1] || "").trim();
          }
        }
      }
    } else if (parenMatch) {
      rawId = parenMatch[1];
    } else {
      // Format tanpa kurung: "Adegan 25", "Adegan 25 (1:36 - 1:40)", "Scene 1", "ADEGAN 1 (00:00 - 00:12)..."
      const sceneNoBracketMatch = cleanText.match(/^[\s\-\*•o]*(?:id\s*)?(?:Adegan|Scene)[_\s]*(\d+)\b/i);
      if (sceneNoBracketMatch) {
        rawId = `Adegan ${sceneNoBracketMatch[1]}`;
      } else {
        // Cek baris nomor adegan seperti "01 (0:00-0:04)" atau "01."
        const leadingNumberMatch = cleanText.match(/^[\s\-\*•o#]*(?:adegan|scene)?\s*0?([1-9]\d{0,2})\s*(?:\([0-9:\-\s]+\))?[\s:—–\-]*$/i);
        if (leadingNumberMatch) {
          rawId = `Adegan ${leadingNumberMatch[1]}`;
        }
      }
    }

    if (rawId) {
      // Simpan adegan yang sedang diproses jika sudah memiliki data minimal
      if (currentScene && (currentScene.narrative || currentScene.image_prompt || currentScene.prompt_flow || currentScene.video_prompt || (currentScene.shots && currentScene.shots.length > 0))) {
        if (currentScene.image_prompt && !currentScene.prompt_flow) currentScene.prompt_flow = currentScene.image_prompt;
        if (currentScene.prompt_flow && !currentScene.image_prompt) currentScene.image_prompt = currentScene.prompt_flow;
        pushSceneWithShots(currentScene, result);
      }

      currentScene = {
        id: normalizeId(rawId),
        narrative: '',
        translation: '',
        image_prompt: '',
        video_prompt: '',
        prompt_flow: '',
        shots: []
      };
      lastLabel = null;
      currentShotNumber = null;

      // Jika ada teks narasi yang menempel di baris adegan (seperti [ID Adegan 1]Narasi:)
      if (hasInlineVo) {
        if (inlineVoText && /[a-zA-Z0-9]/.test(inlineVoText)) {
          currentScene.narrative = inlineVoText;
          lastLabel = null;
        } else {
          lastLabel = 'narasi';
        }
      }
      continue;
    }

    // Deteksi inline text untuk Voiceover / Narasi (misal: "Voiceover (ID): Pertanyaannya..." atau "Narasi (VO): ...")
    const inlineVoMatch = cleanText.match(/^[\s\-\*•o]*(?:voiceover(?:\s*\([^)]*\))?|narasi(?:\s*\([^)]*\))?|narrative|vo)\s*:\s*["“']?([\s\S]*?)["”']?$/i);
    if (inlineVoMatch && currentScene) {
      const inlineText = inlineVoMatch[1].trim();
      if (inlineText && /[a-zA-Z0-9]/.test(inlineText)) {
        if (!currentScene.narrative) currentScene.narrative = inlineText;
        lastLabel = null;
        continue;
      } else {
        lastLabel = 'narasi';
        continue;
      }
    }

    // Deteksi inline text untuk Image Prompt (misal: "Image Prompt: Close-up of..." atau "Image Prompt:\n...")
    const inlineImgMatch = cleanText.match(/^[\s\-\*•o]*(?:image\s*prompt(?:\s*\([^)]*\))?|prompt\s*gambar(?:\s*\([^)]*\))?|prompt\s*flow|image(?:\s*\([^)]*\))?)\s*:\s*["“']?([\s\S]*?)["”']?$/i);
    if (inlineImgMatch && currentScene) {
      const inlineImgText = inlineImgMatch[1].trim();
      if (inlineImgText && /[a-zA-Z0-9]/.test(inlineImgText)) {
        if (!currentScene.image_prompt) {
          currentScene.image_prompt = inlineImgText;
          currentScene.prompt_flow = inlineImgText;
        }
        currentScene.shots.push({
          shot_number: currentScene.shots.length + 1,
          prompt: inlineImgText
        });
        lastLabel = null;
        continue;
      } else {
        lastLabel = 'shot';
        continue;
      }
    }

    // Deteksi inline text untuk Video Motion / Video Prompt (Variabel Ketiga! misal: "Video Prompt: Golden light gets...")
    const inlineVidMatch = cleanText.match(/^[\s\-\*•o]*(?:video\s*(?:motion|prompt)(?:\s*\([^)]*\))?|ai\s*video(?:\s*prompt)?(?:\s*\([^)]*\))?|prompt\s*video(?:\s*\([^)]*\))?|video\s*motion)\s*:\s*["“']?([\s\S]*?)["”']?$/i);
    if (inlineVidMatch && currentScene) {
      const inlineVidText = inlineVidMatch[1].trim();
      if (inlineVidText && /[a-zA-Z0-9]/.test(inlineVidText)) {
        if (!currentScene.video_prompt) {
          currentScene.video_prompt = inlineVidText;
        }
        lastLabel = null;
        continue;
      } else {
        lastLabel = 'video_prompt';
        continue;
      }
    }

    // Deteksi label Narasi, Terjemahan, Prompt Gambar (Shot 1, Shot 2), atau Prompt Video (elemen terpisah)
    const lowerText = cleanText.toLowerCase();
    if (lowerText.includes('narasi') || lowerText.includes('narrative') || lowerText.includes('voiceover') || lowerText.includes('voice') || lowerText.includes('vo')) {
      lastLabel = 'narasi';
    } else if (lowerText.includes('terjemahan') || lowerText.includes('translation')) {
      lastLabel = 'terjemahan';
    } else if (lowerText.includes('ai video prompt') || lowerText.includes('video prompt') || lowerText.includes('prompt video') || lowerText.includes('motion prompt') || lowerText.includes('video motion')) {
      lastLabel = 'video_prompt';
    } else if (lowerText.includes('prompt gambar') || lowerText.includes('image prompt') || lowerText.includes('gambar (image)') || lowerText.includes('prompt (image)') || lowerText.includes('shot')) {
      lastLabel = 'shot';
      const shotNoMatch = cleanText.match(/(?:shot\s*(\d+)|\(shot\s*(\d+)\))/i);
      currentShotNumber = shotNoMatch ? parseInt(shotNoMatch[1] || shotNoMatch[2], 10) : null;
    } else if (currentScene && lastLabel) {
      // Jika label aktif dan baris saat ini adalah teks non-pre
      // PENTING: Jika teks hanya berupa tanda baca (seperti ":" atau "-") tanpa huruf/angka, atau kata "Plaintext", lewati!
      if (!/[a-zA-Z0-9]/.test(cleanText) || cleanText.toLowerCase() === 'plaintext') {
        continue;
      }

      const isAnotherLabel = /^(?:voiceover|narasi|narrative|vo|image\s*prompt|prompt\s*gambar|prompt\s*flow|image|video\s*motion|video\s*prompt|prompt\s*video|shot|terjemahan|translation)/i.test(cleanText);
      if (!isAnotherLabel) {
        if (lastLabel === 'narasi' && !currentScene.narrative) {
          currentScene.narrative = cleanText;
          lastLabel = null;
        } else if (lastLabel === 'terjemahan' && !currentScene.translation) {
          currentScene.translation = cleanText;
          lastLabel = null;
        } else if (lastLabel === 'video_prompt' && !currentScene.video_prompt) {
          currentScene.video_prompt = cleanText;
          lastLabel = null;
        } else if (lastLabel === 'shot') {
          const sNo = currentShotNumber || (currentScene.shots.length + 1);
          currentScene.shots.push({ shot_number: sNo, prompt: cleanText });
          if (!currentScene.image_prompt) {
            currentScene.image_prompt = cleanText;
            currentScene.prompt_flow = cleanText;
          }
          lastLabel = null;
          currentShotNumber = null;
        }
      }
    }
  }

  // Simpan adegan terakhir
  if (currentScene && (currentScene.narrative || currentScene.image_prompt || currentScene.prompt_flow || currentScene.video_prompt || (currentScene.shots && currentScene.shots.length > 0))) {
    if (currentScene.image_prompt && !currentScene.prompt_flow) currentScene.prompt_flow = currentScene.image_prompt;
    if (currentScene.prompt_flow && !currentScene.image_prompt) currentScene.image_prompt = currentScene.prompt_flow;
    pushSceneWithShots(currentScene, result);
  }

  return result;
}

/**
 * Ekstraksi fallback menggunakan format JSON lama
 */
function extractFromLegacyJson(container) {
  const elements = Array.from(container.querySelectorAll('pre, code, .code-block, code-block-decorator'));
  
  for (let i = elements.length - 1; i >= 0; i--) {
    try {
      const text = elements[i].innerText || elements[i].textContent || '';
      
      // Cari awal dan akhir JSON array [ ]
      const startIndex = text.indexOf('[');
      const endIndex = text.lastIndexOf(']');

      if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
        const cleanJsonStr = text.substring(startIndex, endIndex + 1);
        const parsedData = JSON.parse(cleanJsonStr);

        if (Array.isArray(parsedData) && parsedData.length > 0) {
          const firstItem = parsedData[0];
          
          const hasId = 'id' in firstItem || 'scene_id' in firstItem || 'scene' in firstItem;
          const hasPrompt = 'image_prompt' in firstItem || 'prompt_flow' in firstItem || 'prompt' in firstItem || 'flow_prompt' in firstItem;

          if (hasId && hasPrompt) {
            return parsedData.map(item => {
              const imgP = item.image_prompt || item.prompt_flow || item.prompt || item.flow_prompt || '';
              const vidP = item.video_prompt || item.motion_prompt || '';
              return {
                id: item.id || item.scene_id || item.scene || '',
                narrative: item.narrative || item.narasi || item.text || '',
                translation: item.translation || item.terjemahan || '',
                image_prompt: imgP,
                video_prompt: vidP,
                prompt_flow: imgP
              };
            });
          }
        }
      }
    } catch (err) {
      // Abaikan error parsing untuk blok kode non-JSON
    }
  }
  return null;
}

/**
 * Membatasi judul maksimal 4 kata saja.
 * Menjamin penanda bab (misal: "bab 03", "bab 2") tidak terpotong jika ada di dalam judul.
 */
function limitTitleFourWords(rawTitle) {
  if (!rawTitle) return "storyboard";
  // FIX #2A: Jangan hapus kata "part" / "bab" — keduanya penanda seri/bab yang wajib dipertahankan di nama file
  let clean = rawTitle.replace(/[^\w\s]+/g, ' ').trim();
  let words = clean.split(/\s+/).filter(Boolean);
  if (words.length > 4) {
    // Prioritas 1: Pertahankan kata "bab X" di akhir jika ada
    const babMatch = clean.match(/\b(bab\s*\d+)\b/i);
    // Prioritas 2: Pertahankan kata "part X" di akhir jika tidak ada "bab"
    const partMatch = !babMatch ? clean.match(/\b(part\s*0?\d+)\b/i) : null;

    if (babMatch) {
      const babWords = babMatch[1].split(/\s+/);
      const otherWords = clean.replace(new RegExp(`\\b${babMatch[1]}\\b`, 'i'), '').trim().split(/\s+/).filter(Boolean);
      const remainingSlots = Math.max(1, 4 - babWords.length);
      words = [...otherWords.slice(0, remainingSlots), ...babWords];
    } else if (partMatch) {
      const partWords = partMatch[1].split(/\s+/);
      const otherWords = clean.replace(new RegExp(`\\b${partMatch[1]}\\b`, 'i'), '').trim().split(/\s+/).filter(Boolean);
      const remainingSlots = Math.max(1, 4 - partWords.length);
      words = [...otherWords.slice(0, remainingSlots), ...partWords];
    } else {
      words = words.slice(0, 4);
    }
  }
  let title4 = words.join(" ").trim();
  return title4 || "storyboard";
}

/**
 * FIX #2B: Membuat sufiks waktu deterministik (yymmdd_hhmm) sebagai pengganti hash acak.
 * Nama file kini konsisten, mudah diidentifikasi berdasarkan waktu unduh, dan bebas tabrakan
 * dalam batas satu menit yang sama.
 */
function generateTimestampSuffix() {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(2);
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mi = String(now.getMinutes()).padStart(2, '0');
  return `${yy}${mm}${dd}_${hh}${mi}`;
}

/**
 * Memastikan metadata memenuhi standar:
 * - Judul asli disimpan secara penuh untuk isi file JSON (YouTube SEO & Title)
 */
function sanitizeMeta(meta) {
  const rawTitle = (meta && meta.title ? String(meta.title) : "storyboard").trim() || "storyboard";
  // Simpan judul lengkap asli tanpa dipotong 4 kata
  const title = rawTitle;
  const caption = (meta && meta.caption ? String(meta.caption) : "").trim();
  const cover_prompt = (meta && meta.cover_prompt ? String(meta.cover_prompt) : "").trim();
  const aspect_ratio = (meta && (meta.aspect_ratio || meta.video_ratio) ? String(meta.aspect_ratio || meta.video_ratio) : "9:16").trim();
  const video_ratio = aspect_ratio;
  const recommended_speed = (meta && meta.recommended_speed ? String(meta.recommended_speed) : "+0%").trim();
  const interaction_mode = (meta && meta.interaction_mode ? String(meta.interaction_mode) : "cinematic_pure").trim();
  const visual_reference = (meta && meta.visual_reference ? String(meta.visual_reference) : "").trim();
  return { title, caption, cover_prompt, aspect_ratio, video_ratio, recommended_speed, interaction_mode, visual_reference };
}

/**
 * Memastikan seluruh adegan memenuhi Syarat Mutlak backend (scan_folder):
 * - Setiap adegan WAJIB memiliki 'id' (format ADEGAN_X)
 * - Setiap adegan WAJIB memiliki 'narrative' (string non-null)
 */
function sanitizeScenes(scenes, coverPrompt = '', caption = '') {
  const result = [];
  const hasCoverInScenes = Array.isArray(scenes) && scenes.some(sc => {
    const rawId = String(sc.id || sc.scene_id || sc.scene || '').toUpperCase();
    return rawId === 'COVER' || rawId.includes('COVER');
  });

  // Jika ada cover_prompt dari metadata DAN belum ada adegan ber-ID COVER di dalam scenes
  if (coverPrompt && String(coverPrompt).trim() && !hasCoverInScenes) {
    result.push({
      id: "COVER",
      narrative: "Gambar Sampul / Cover Video (Thumbnail)",
      translation: "Cover Video Thumbnail",
      image_prompt: String(coverPrompt).trim(),
      video_prompt: "",
      prompt_flow: String(coverPrompt).trim()
    });
  }

  if (Array.isArray(scenes)) {
    scenes.forEach((scene, idx) => {
      const rawId = (scene && (scene.id || scene.scene_id || scene.scene)) 
        ? String(scene.id || scene.scene_id || scene.scene) 
        : `Adegan ${idx + 1}`;
      
      const id = normalizeId(rawId);
      
      let narrative = scene && (scene.narrative || scene.narasi || scene.text) 
        ? String(scene.narrative || scene.narasi || scene.text).trim() 
        : "";

      const translation = scene && (scene.translation || scene.terjemahan) 
        ? String(scene.translation || scene.terjemahan).trim() 
        : "";

      let image_prompt = scene && (scene.image_prompt || scene.prompt_flow || scene.prompt || scene.flow_prompt) 
        ? String(scene.image_prompt || scene.prompt_flow || scene.prompt || scene.flow_prompt).trim() 
        : "";

      const video_prompt = scene && (scene.video_prompt || scene.motion_prompt) 
        ? String(scene.video_prompt || scene.motion_prompt).trim() 
        : "";

      let prompt_flow = image_prompt;

      // Koreksi cerdas jika Gemini salah memetakan Image Prompt ke kolom Narrative
      const looksLikePrompt = /render|close-up|macro|lighting|detailed|photorealistic|epic|8k|cinematic|unreal engine/i.test(narrative);
      if (looksLikePrompt && !image_prompt) {
        image_prompt = narrative;
        prompt_flow = narrative;
        if (idx === 0 || id === "ADEGAN_01") {
          narrative = caption ? caption.trim() : "Jangan pernah meremehkan serangga berukuran dua sentimeter ini.";
        } else {
          narrative = "";
        }
      }

      let duration = 4;
      if (scene && scene.duration !== undefined && !isNaN(Number(scene.duration))) {
        duration = Number(scene.duration);
      } else if (video_prompt) {
        duration = 8;
      }

      const sceneObj = {
        id: id,
        narrative: narrative,
        translation: translation,
        image_prompt: image_prompt,
        video_prompt: video_prompt,
        prompt_flow: prompt_flow,
        duration: duration
      };

      // Ekstraksi & pertahankan headline dan editorial_text (SRS-40 / Headline Mandate)
      let headline = scene && scene.headline ? String(scene.headline).trim() : '';
      if (!headline && image_prompt) {
        const m = image_prompt.match(/Indonesian headline [\"\x27](.+?)[\"\x27]/i) || image_prompt.match(/headline [\"\x27](.+?)[\"\x27]/i);
        if (m) headline = m[1].trim();
      }
      if (headline) {
        sceneObj.headline = headline;
        sceneObj.editorial_text = (scene && Array.isArray(scene.editorial_text)) ? scene.editorial_text : [{
          text: headline,
          language: 'id',
          render_mode: 'in_image',
          placement: 'upper_safe',
          preset: 'headline'
        }];
      } else if (scene && Array.isArray(scene.editorial_text)) {
        sceneObj.editorial_text = scene.editorial_text;
      }

      if (scene && scene.parent_scene) {
        sceneObj.parent_scene = scene.parent_scene;
      } else if (id.includes('_') && /^ADEGAN_\d+_[A-Za-z0-9]+$/i.test(id)) {
        sceneObj.parent_scene = id.replace(/_[A-Za-z0-9]+$/, '');
      }

      if (scene && scene.shot_number) {
        sceneObj.shot_number = scene.shot_number;
      }

      if (scene && scene.shot_type) {
        sceneObj.shot_type = scene.shot_type;
      }

      result.push(sceneObj);
    });
  }

  return result;
}

/**
 * Mengecek apakah konteks ekstensi Chrome masih aktif dan valid.
 */
function isExtensionContextAlive() {
  try {
    return Boolean(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

/**
 * Mengunduh data JSON secara mandiri langsung melalui DOM (Blob URL + Anchor Download).
 * Sangat handal dan aman bahkan ketika background service worker sedang sleep atau context invalidated.
 */
function fallbackDownloadViaDom(data, filename) {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename.toLowerCase().endsWith('.json') ? filename : `${filename}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try {
        if (a.parentNode) a.parentNode.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (_) {}
    }, 200);
    console.log(`FlowAutoBridge: Berhasil mengunduh ${filename} via DOM Fallback`);
    return true;
  } catch (err) {
    console.error('FlowAutoBridge: Gagal mengunduh via DOM Fallback:', err);
    return false;
  }
}

/**
 * Pemicu unduhan JSON dua lapis (Dual-Layer Downloader):
 * 1. Coba kirimkan ke background.js via chrome.downloads API
 * 2. Jika background script error, sleep, atau context invalidated, otomatis fallback ke DOM Blob download
 */
function triggerJsonDownload(data, filename, projectFolder = '') {
  const safeFilename = filename.toLowerCase().endsWith('.json') ? filename : `${filename}.json`;
  // FIX #3: Bangun path lengkap dengan subfolder proyek agar JSON otomatis masuk ke folder yang tepat.
  // Chrome downloads API mendukung path relatif dengan '/' untuk membuat subfolder secara otomatis.
  // DOM fallback tetap menggunakan nama file saja (atribut 'download' di browser tidak mendukung path).
  const fullPath = projectFolder
    ? `intisariShortMovie/${projectFolder}/${safeFilename}`
    : safeFilename;

  if (isExtensionContextAlive()) {
    try {
      chrome.runtime.sendMessage({
        action: 'download_storyboard',
        data: data,
        filename: fullPath
      }, (resp) => {
        if (chrome.runtime.lastError || (resp && !resp.success)) {
          console.warn('FlowAutoBridge: Background download gagal, beralih ke DOM Fallback:', chrome.runtime.lastError?.message || resp?.error);
          fallbackDownloadViaDom(data, safeFilename);
        }
      });
      return;
    } catch (e) {
      console.warn('FlowAutoBridge: Exception saat sendMessage, beralih ke DOM Fallback:', e.message);
      fallbackDownloadViaDom(data, safeFilename);
      return;
    }
  }

  // Jika konteks ekstensi mati/invalidated, langsung gunakan DOM Fallback
  fallbackDownloadViaDom(data, safeFilename);
}

/**
 * Menyimpan nama file JSON yang berhasil didownload ke riwayat local storage (maksimal 5 file terakhir)
 */
function saveJsonFilenameToHistory(filename) {
  if (!isExtensionContextAlive()) return;
  try {
    chrome.storage.local.get(['lastDownloadedJsonList'], (res) => {
      if (chrome.runtime.lastError) return;
      let list = (res && res.lastDownloadedJsonList) || [];
      list = list.filter(item => item !== filename);
      list.unshift(filename);
      if (list.length > 5) {
        list = list.slice(0, 5);
      }
      chrome.storage.local.set({ lastDownloadedJsonList: list });
    });
  } catch (_) {
    // Context invalidated, abaikan
  }
}

/**
 * Mengirimkan data storyboard dan mengunduhnya.
 * Menggunakan judul 4 kata + 4 karakter acak di akhir nama berkas JSON (misal: kisah_haci_cahaya_kecil_part1_w2zl.json)
 */
function downloadStoryboardWithChunks(rawMeta, rawScenes, callback) {
  const proceedDownload = (splitMode) => {
    const meta = sanitizeMeta(rawMeta);
    const scenes = sanitizeScenes(rawScenes, meta.cover_prompt, meta.caption);
    const CHUNK_SIZE = 10;

    const baseFourWordsTitle = limitTitleFourWords(meta.title);
    const safeTitle = baseFourWordsTitle
      .replace(/[^a-zA-Z0-9\s\-]+/g, '')
      .replace(/[\s\-]+/g, '_')
      .toLowerCase() || 'storyboard';

    // Standarisasi Folder Proyek: 4 Karakter Acak Unik untuk Isolasi Eksperimen Multi-Run (Mode A - SRS-FAB-056)
    const randHash = Math.random().toString(36).substring(2, 6);
    const cleanTitle = (meta.title || 'storyboard')
      .replace(/\(?part\s*\d+\)?/gi, '')
      .replace(/[/\\?%*:|"<>]/g, ' ')
      .replace(/[^\w\s\-]+/g, ' ')
      .trim()
      .split(/\s+/)
      .slice(0, 5)
      .join('_') || 'storyboard';

    const projectFolderName = `${cleanTitle}_${randHash}`;

    // Simpan ke storage agar saat pengguna membuka Google Flow, folder ini langsung terhubung otomatis
    if (isExtensionContextAlive()) {
      try {
        chrome.storage.local.set({
          activeProjectFolder: projectFolderName,
          latestActiveStoryboardTitle: meta.title
        });
      } catch (_) {}
    }

    let resultInfo = { partsCount: 1, isChunked: false, filenames: [] };

    if (splitMode === 'full_json' || scenes.length <= CHUNK_SIZE) {
      const filename = `${projectFolderName}.json`;

      let detectedRatio = meta.aspect_ratio || meta.video_ratio || '';
      if (!detectedRatio) {
        for (const sc of scenes) {
          const p = `${sc.image_prompt || ''} ${sc.prompt_flow || ''}`;
          if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) { detectedRatio = '9:16'; break; }
          if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) { detectedRatio = '16:9'; break; }
        }
      }
      if (!detectedRatio) detectedRatio = '9:16';

      const structuredData = {
        title: meta.title, // Full Judul Lengkap disimpan di file JSON
        caption: meta.caption,
        aspect_ratio: detectedRatio,
        video_ratio: detectedRatio,
        recommended_speed: meta.recommended_speed || '+0%',
        interaction_mode: meta.interaction_mode || 'cinematic_pure',
        total_scenes: scenes.length,
        scenes: scenes
      };
      if (meta.visual_reference) structuredData.visual_reference = meta.visual_reference;
      
      triggerJsonDownload(structuredData, filename, projectFolderName);
      resultInfo = { partsCount: 1, isChunked: false, filenames: [filename] };
      saveJsonFilenameToHistory(filename);
    } else {
      const totalParts = Math.ceil(scenes.length / CHUNK_SIZE);
      const filenames = [];

      let detectedRatio = meta.aspect_ratio || meta.video_ratio || '';
      if (!detectedRatio) {
        for (const sc of scenes) {
          const p = `${sc.image_prompt || ''} ${sc.prompt_flow || ''}`;
          if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) { detectedRatio = '9:16'; break; }
          if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) { detectedRatio = '16:9'; break; }
        }
      }
      if (!detectedRatio) detectedRatio = '9:16';

      for (let i = 0; i < scenes.length; i += CHUNK_SIZE) {
        const partNum = Math.floor(i / CHUNK_SIZE) + 1;
        const chunkScenes = scenes.slice(i, i + CHUNK_SIZE);
        const partTitle = `${meta.title} (Part ${partNum})`;
        const chunkData = {
          title: partTitle, // Full Judul Lengkap + Part di file JSON
          caption: meta.caption,
          aspect_ratio: detectedRatio,
          video_ratio: detectedRatio,
          recommended_speed: meta.recommended_speed || '+0%',
          interaction_mode: meta.interaction_mode || 'cinematic_pure',
          scenes: chunkScenes,
          part: partNum,
          total_parts: totalParts,
          total_scenes: scenes.length
        };
        if (meta.visual_reference) chunkData.visual_reference = meta.visual_reference;
        const chunkFilename = `${projectFolderName}_part${partNum}.json`;
        filenames.push(chunkFilename);
        
        triggerJsonDownload(chunkData, chunkFilename, projectFolderName);
        saveJsonFilenameToHistory(chunkFilename);
      }
      resultInfo = { partsCount: totalParts, isChunked: true, filenames: filenames };
    }

    if (callback) callback(resultInfo);
  };

  if (isExtensionContextAlive()) {
    try {
      chrome.storage.local.get(['splitMode'], (storageData) => {
        const mode = (storageData && storageData.splitMode) || 'full_json';
        proceedDownload(mode);
      });
      return;
    } catch (_) {
      // Fallback jika storage get error
    }
  }

  proceedDownload('full_json');
}

/**
 * Mengambil semua elemen respons model Gemini yang ada di DOM
 */
function getAllModelMessages() {
  const selectors = [
    'model-response',
    '.model-response',
    'message-content',
    '.message-content',
    'div[data-message-author="model"]',
    'div[data-message-author-role="model"]',
    'div[class*="message-content"]',
    'div[data-test-id*="model-response"]',
    'div.response-container',
    'div.model-response-text'
  ];
  for (const selector of selectors) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      return Array.from(elements);
    }
  }
  const codeBlocks = document.querySelectorAll('code-block, code-block-decorator, pre, [class*="code-block"]');
  if (codeBlocks.length > 0) {
    return Array.from(codeBlocks);
  }
  return [document.body];
}

/**
 * Mengambil elemen respons model Gemini paling terakhir
 */
function getLastModelMessage() {
  const all = getAllModelMessages();
  return all.length > 0 ? all[all.length - 1] : document.body;
}

/**
 * Ekstraksi terpadu metadata dan adegan dari sebuah elemen container Gemini
 */
function extractStoryboardFromElement(container) {
  if (!container) return null;

  // 0. Prioritas Utama #0: Ekstraksi dari Blok Kode JSON Resmi (GPTs / Gemini JSON Output)
  if (typeof window !== 'undefined' && window.StoryboardJsonExtractor) {
    try {
      const jsonStoryboard = window.StoryboardJsonExtractor.findStoryboardJsonInContainer(container);
      if (jsonStoryboard && jsonStoryboard.scenes && jsonStoryboard.scenes.length > 0) {
        let detRatio = jsonStoryboard.aspect_ratio || jsonStoryboard.video_ratio || '';
        if (!detRatio) {
          for (const sc of jsonStoryboard.scenes) {
            const p = `${sc.image_prompt || ''} ${sc.prompt_flow || ''}`;
            if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) { detRatio = '9:16'; break; }
            if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) { detRatio = '16:9'; break; }
          }
        }
        if (!detRatio) detRatio = '9:16';

        const rawMeta = {
          title: jsonStoryboard.title || '',
          caption: jsonStoryboard.caption || '',
          aspect_ratio: detRatio,
          video_ratio: detRatio,
          recommended_speed: jsonStoryboard.recommended_speed || '+0%',
          interaction_mode: jsonStoryboard.interaction_mode || 'cinematic_pure',
          visual_reference: jsonStoryboard.visual_reference || '',
          cover_prompt: '',
          video_title: jsonStoryboard.title || '',
          chapter_title: ''
        };
        const meta = sanitizeMeta(rawMeta);
        const scenes = sanitizeScenes(jsonStoryboard.scenes, meta.cover_prompt, meta.caption);
        return { meta, scenes, rawMeta, rawScenes: jsonStoryboard.scenes, jsonStoryboard };
      }
    } catch (errJson) {
      console.warn('[FlowAutoBridge] Warning saat ekstraksi StoryboardJsonExtractor:', errJson);
    }
  }

  const rawMeta = extractTitleAndCaption(container);

  // 1. Prioritas 1: Ekstraksi dari tabel HTML (Gemini Markdown Table)
  let rawScenes = extractFromHtmlTable(container);

  // 2. Prioritas 2: Ekstraksi dari format visual (Bullet list, bracket scenes, code blocks)
  if (!rawScenes || rawScenes.length === 0) {
    rawScenes = extractFromVisualFormat(container);
  }

  // 3. Prioritas 3: Fallback ke Legacy JSON code block
  if (!rawScenes || rawScenes.length === 0) {
    rawScenes = extractFromLegacyJson(container);
  }

  if (!rawScenes || rawScenes.length === 0) {
    return null;
  }
  const meta = sanitizeMeta(rawMeta);
  const scenes = sanitizeScenes(rawScenes, meta.cover_prompt, meta.caption);
  return { meta, scenes, rawMeta, rawScenes };
}

/**
 * Mengecek apakah suatu data storyboard adalah Bab 1 (Bab Pembuka)
 * Sesuai aturan:
 * - Bab 1: Ditandai dengan JUDUL VIDEO tanpa kata "bab" di judulnya, memiliki caption sosial media atau adegan pertama [Adegan 1].
 * - Bab 2, 3, dst.: Ditandai dengan JUDUL BAB LANJUTAN yang memuat kata "bab" (contoh: "bab 02", "bab 03").
 */
function isChapterOne(storyboardData) {
  if (!storyboardData || !storyboardData.meta) return false;
  const meta = storyboardData.meta;
  const title = (meta.title || '').toLowerCase();
  
  // Jika di judul secara jelas tertulis bab 2, bab 03, bab 4, dst., BUKAN bab 1
  if (/\bbab\s*0?[2-9]\b/i.test(title) || /\bbab\s*[1-9]\d+\b/i.test(title)) {
    return false;
  }

  // Cek apakah ada adegan pertama (Adegan 1 atau ADEGAN_01)
  const hasFirstScene = (storyboardData.scenes || []).some(sc => {
    const rawId = String(sc.id || '').toUpperCase();
    return rawId === 'ADEGAN_01' || rawId.startsWith('ADEGAN_01_') || rawId === 'ADEGAN_1';
  });

  // Jika memuat adegan 1, PASTI bab 1
  if (hasFirstScene) {
    return true;
  }

  // Jika memiliki caption sosial media dan tidak ada kata bab lanjutan di judul
  if (Boolean(meta.caption) && !meta.chapter_title && !/\bbab\s*\d+\b/i.test(title)) {
    return true;
  }

  // Jika judul video eksplisit ada tanpa chapter_title dan tanpa kata bab
  if (meta.video_title && !meta.chapter_title && !/\bbab\s*\d+\b/i.test(title)) {
    return true;
  }

  return false;
}

/**
 * Memindai seluruh pesan sebelumnya di percakapan Gemini untuk mencari respons Bab 1
 */
function findChapterOneData() {
  const allMessages = getAllModelMessages();
  for (let i = 0; i < allMessages.length; i++) {
    const data = extractStoryboardFromElement(allMessages[i]);
    if (data && isChapterOne(data)) {
      return data;
    }
  }
  return null;
}

/**
 * Menghasilkan basis kunci proyek dari judul video (menghilangkan kata bab dan emoji)
 */
function getProjectBaseKey(title) {
  if (!title) return 'default_project';
  const clean = String(title)
    .replace(/\b(bab\s*\d+)\b/gi, '')
    .replace(/[^\w\s]/g, '')
    .trim()
    .toLowerCase();
  const words = clean.split(/\s+/).filter(Boolean);
  return words.slice(0, 2).join('_') || 'project';
}

/**
 * Memeriksa status riwayat Bab 1 dari local storage
 */
function checkChapterHistory(projectKey, callback) {
  if (!isExtensionContextAlive()) {
    callback(null);
    return;
  }
  try {
    chrome.storage.local.get(['storyboardProjectHistory'], (res) => {
      if (chrome.runtime.lastError) {
        callback(null);
        return;
      }
      const history = (res && res.storyboardProjectHistory) || {};
      callback(history[projectKey] || null);
    });
  } catch (_) {
    callback(null);
  }
}

/**
 * Menyimpan status dan metadata Bab 1 ke local storage
 */
function saveChapterToHistory(projectKey, chapterInfo) {
  if (!isExtensionContextAlive()) return;
  try {
    chrome.storage.local.get(['storyboardProjectHistory'], (res) => {
      if (chrome.runtime.lastError) return;
      const history = (res && res.storyboardProjectHistory) || {};
      history[projectKey] = {
        ...(history[projectKey] || {}),
        ...chapterInfo,
        updatedAt: Date.now()
      };
      chrome.storage.local.set({ storyboardProjectHistory: history });
    });
  } catch (_) {}
}

/**
 * Mengambil semua storyboard yang ada di seluruh percakapan Gemini secara berurutan
 */
function findAllStoryboardsInChat() {
  const allMessages = getAllModelMessages();
  const list = [];

  for (let i = 0; i < allMessages.length; i++) {
    const msg = allMessages[i];
    const data = extractStoryboardFromElement(msg);
    if (data && data.scenes && data.scenes.length > 0) {
      // Hitung nomor adegan pertama yang sah
      let startScene = 999;
      for (const sc of data.scenes) {
        const rawId = String(sc.id || '').toUpperCase();
        if (rawId === 'COVER') continue;
        const m = rawId.match(/ADEGAN_(\d+)/);
        if (m) {
          startScene = parseInt(m[1], 10);
          break;
        }
      }

      // Deteksi nomor bab dari judul (misal: "bab 02" -> 2, "bab 03" -> 3)
      let chapterNum = 1;
      const titleLower = (data.meta.title || '').toLowerCase();
      const babMatch = titleLower.match(/\bbab\s*0?(\d+)\b/);
      const partMatch = titleLower.match(/\bpart\s*0?(\d+)\b/); // FIX #1: Deteksi "Part02", "Part 2", dst.
      if (babMatch) {
        chapterNum = parseInt(babMatch[1], 10);
      } else if (partMatch) {
        chapterNum = parseInt(partMatch[1], 10); // FIX #1: Resolusi nomor bab dari kata "part"
      } else if (startScene !== 999) {
        chapterNum = Math.floor((startScene - 1) / 15) + 1;
      }

      list.push({
        elementIndex: i,
        startScene: startScene,
        chapterNum: chapterNum,
        data: data
      });
    }
  }

  // Urutkan berdasarkan nomor adegan awal (ascending) agar Bab 1, Bab 2, Bab 3 runut
  list.sort((a, b) => a.startScene - b.startScene);

  return list;
}

/**
 * Mengunduh daftar storyboard secara berantai dengan jeda antar berkas
 */
function downloadStoryboardsSequentially(itemsToDownload, onComplete) {
  if (!itemsToDownload || itemsToDownload.length === 0) {
    if (onComplete) onComplete({ allFilenames: [], totalScenes: 0, partsCount: 0 });
    return;
  }

  const allFilenames = [];
  let totalScenes = 0;
  let totalParts = 0;
  let currentIdx = 0;

  function processNext() {
    if (currentIdx >= itemsToDownload.length) {
      if (onComplete) {
        onComplete({
          allFilenames: allFilenames,
          totalScenes: totalScenes,
          partsCount: totalParts
        });
      }
      return;
    }

    const item = itemsToDownload[currentIdx];
    const data = item.data;

    downloadStoryboardWithChunks(data.meta, data.scenes, (chunkInfo) => {
      if (chunkInfo && chunkInfo.filenames) {
        allFilenames.push(...chunkInfo.filenames);
        totalParts += (chunkInfo.partsCount || 1);
      }
      totalScenes += data.scenes.length;

      currentIdx++;
      if (currentIdx < itemsToDownload.length) {
        setTimeout(processNext, 700); // Jeda 700ms antar berkas agar browser stabil
      } else {
        processNext();
      }
    });
  }

  processNext();
}

/**
 * Eksekusi ekstraksi storyboard cerdas dengan perlindungan Multi-Bab & Bab 1 (History Guard)
 */
function executeExtractionWithBab1Guard(onSuccess, onError) {
  const contextAlive = isExtensionContextAlive();
  const rawList = findAllStoryboardsInChat();

  if (!rawList || rawList.length === 0) {
    if (onError) onError('Storyboard tidak ditemukan. Pastikan respons Gemini berisi format adegan [Adegan X] dengan kode Narasi & Prompt Flow, atau blok kode JSON storyboard.');
    return;
  }

  // 1. Identifikasi storyboard paling mutakhir (respons model paling terakhir di DOM) sebagai referensi aktif
  let latestItem = rawList[0];
  for (const it of rawList) {
    if (it.elementIndex >= latestItem.elementIndex) {
      latestItem = it;
    }
  }

  const activeTitle = latestItem.data.meta.title || '';
  const activeProjectKey = getProjectBaseKey(activeTitle);

  // 2. Filter relevansi: Hanya sertakan respons yang selaras dengan proyek aktif saat ini
  const relevantList = rawList.filter(item => {
    const itemTitle = item.data.meta.title || '';
    if (!itemTitle) return true;
    const itemKey = getProjectBaseKey(itemTitle);
    return itemKey === activeProjectKey || itemKey === 'project' || activeProjectKey === 'project';
  });

  // 3. DEDUPLIKASI KETAT PER NOMOR BAB (Anti-Multiple Download Draf Usang):
  // Jika dalam riwayat percakapan Gemini terdapat beberapa kali respons untuk Bab yang sama
  // (misal ada beberapa respons Bab 1 karena draf awal, retry, atau revisi berkali-kali),
  // HANYA ambil respons TERAKHIR (elementIndex terbesar) untuk nomor bab tersebut.
  const chapterMap = new Map();
  // Urutkan elementIndex secara ascending agar respons paling baru menimpa respons lama di Map
  relevantList.sort((a, b) => a.elementIndex - b.elementIndex);
  for (const item of relevantList) {
    chapterMap.set(item.chapterNum, item);
  }

  // Ambil daftar bab unik dan urutkan berdasarkan urutan bab (Bab 1, Bab 2, dst.)
  const allStoryboards = Array.from(chapterMap.values());
  allStoryboards.sort((a, b) => a.chapterNum - b.chapterNum);

  // 4. Cari Bab 1 utama untuk mengambil master caption & SEO jika tersedia
  const bab1Item = allStoryboards.find(item => item.chapterNum === 1 || isChapterOne(item.data)) || latestItem;
  const masterCaption = (bab1Item && bab1Item.data.meta.caption) || latestItem.data.meta.caption || '';
  const masterTitle = (bab1Item && bab1Item.data.meta.title) || latestItem.data.meta.title || 'storyboard';
  const projectKey = getProjectBaseKey(masterTitle);

  // Bagikan master caption ke bab-bab yang caption-nya masih kosong
  if (masterCaption) {
    allStoryboards.forEach(item => {
      if (!item.data.meta.caption) {
        item.data.meta.caption = masterCaption;
      }
    });
  }

  checkChapterHistory(projectKey, (hist) => {
    const downloadedNums = (hist && Array.isArray(hist.downloadedChapterNums)) ? hist.downloadedChapterNums : [];
    
    // Tentukan bab mana saja yang perlu diunduh
    let itemsToDownload = [];

    if (downloadedNums.length === 0) {
      // Belum pernah diunduh sama sekali di sesi/proyek ini:
      // Unduh bab-bab unik yang terdeteksi (setelah deduplikasi, bab duplikat sudah dieliminasi)
      itemsToDownload = allStoryboards;
    } else {
      // Sudah ada riwayat: cari bab-bab unik yang belum pernah terunduh
      const missingChapters = allStoryboards.filter(item => !downloadedNums.includes(item.chapterNum));
      if (missingChapters.length > 0) {
        itemsToDownload = missingChapters;
      } else {
        // Jika seluruh bab sudah pernah diunduh, unduh bab pesan terakhir yang sedang aktif
        itemsToDownload = [latestItem];
      }
    }

    // PENGAMAN MUTLAK: Jangan biarkan itemsToDownload kosong
    if (itemsToDownload.length === 0) {
      itemsToDownload = [latestItem];
    }

    console.log(`FlowAutoBridge: Bab terdeteksi: ${allStoryboards.length}, Bab yang akan diunduh:`, itemsToDownload.map(i => `Bab ${i.chapterNum}`));

    // Update antrean aktif ke bab terakhir yang diproses
    const primaryItem = itemsToDownload[itemsToDownload.length - 1] || allStoryboards[allStoryboards.length - 1];
    const structuredData = {
      title: primaryItem.data.meta.title,
      caption: primaryItem.data.meta.caption,
      scenes: primaryItem.data.scenes
    };

    if (contextAlive) {
      try {
        chrome.storage.local.set({ storyboardQueue: structuredData, activeIndex: 0, automationRunning: false });
      } catch (_) {}
    }

    // Jalankan unduhan berantai
    downloadStoryboardsSequentially(itemsToDownload, (result) => {
      // Perbarui riwayat unduhan
      const newlyDownloaded = itemsToDownload.map(i => i.chapterNum);
      const updatedNums = Array.from(new Set([...downloadedNums, ...newlyDownloaded]));
      
      saveChapterToHistory(projectKey, {
        hasBab1: updatedNums.includes(1),
        title: masterTitle,
        caption: masterCaption,
        downloadedChapterNums: updatedNums
      });

      const downloadedText = itemsToDownload.map(i => `Bab ${i.chapterNum}`).join(', ');
      let msg = '';
      if (itemsToDownload.length === 1) {
        msg = `✓ Sukses: ${downloadedText} (${result.allFilenames.join(', ')}) berhasil disimpan!`;
      } else {
        msg = `✓ Sukses: ${itemsToDownload.length} Bab (${downloadedText}) berhasil diekstrak bersamaan!`;
      }

      if (onSuccess) {
        onSuccess({
          count: result.totalScenes,
          parts: result.partsCount,
          filenames: result.allFilenames,
          isMultiChapter: itemsToDownload.length > 1,
          message: msg
        });
      }
    });
  });
}

/**
 * Melakukan scroll halaman Gemini secara smooth ke bagian adegan storyboard terakhir (paling bawah)
 */
function scrollToLastScene() {
  console.log('FlowAutoBridge: Melakukan scroll ke adegan terakhir...');
  window.scrollTo({
    top: document.body.scrollHeight,
    behavior: 'smooth'
  });

  const modelResponses = document.querySelectorAll(
    'message-content, .message-content, .model-response, div[class*="message-content"], div[data-message-author="model"]'
  );
  if (modelResponses.length > 0) {
    const lastMsg = modelResponses[modelResponses.length - 1];
    const tableRows = lastMsg.querySelectorAll('tr');
    if (tableRows.length > 0) {
      const lastRow = tableRows[tableRows.length - 1];
      lastRow.scrollIntoView({ behavior: 'smooth', block: 'end' });
    } else {
      lastMsg.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }
}

/**
 * Menyuntikkan Panel Aksi Melayang di Sisi Kanan Layar (Right-Fixed Floating Panel).
 * Pengguna dapat langsung mengekstraksi, mentransfer, atau menyalin prompt tanpa perlu scroll.
 */
function injectFloatingRightPanel() {
  const FAB_ID = 'flow-bridge-fab';
  const POPOVER_ID = 'flow-bridge-popover';
  const STYLE_ID = 'flow-bridge-style';

  if (document.getElementById(FAB_ID)) return;

  // ─── Inject CSS khusus untuk FAB & Popover ─────────────────────────────────
  if (!document.getElementById(STYLE_ID)) {
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      #flow-bridge-fab {
        position: fixed;
        bottom: 28px;
        right: 28px;
        z-index: 999998;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: linear-gradient(135deg, #10b981 0%, #0284c7 100%);
        box-shadow: 0 4px 18px rgba(16, 185, 129, 0.45), 0 2px 8px rgba(0,0,0,0.4);
        border: 2px solid rgba(255,255,255,0.15);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        transition: transform 0.2s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.2s;
        animation: fbp-fab-in 0.4s cubic-bezier(0.34,1.56,0.64,1) both;
        pointer-events: all;
        user-select: none;
      }
      #flow-bridge-fab:hover {
        transform: scale(1.12);
        box-shadow: 0 6px 24px rgba(16, 185, 129, 0.6), 0 2px 8px rgba(0,0,0,0.4);
      }
      #flow-bridge-fab:active { transform: scale(0.95); }

      @keyframes fbp-fab-in {
        from { transform: scale(0) rotate(-30deg); opacity: 0; }
        to   { transform: scale(1) rotate(0deg);   opacity: 1; }
      }

      #flow-bridge-popover {
        position: fixed;
        bottom: 88px;
        right: 28px;
        z-index: 999999;
        width: 250px;
        background: rgba(10, 15, 29, 0.94);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(59, 130, 246, 0.4);
        box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.7), 0 0 15px rgba(59, 130, 246, 0.25);
        border-radius: 14px;
        padding: 14px;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #f1f5f9;
        display: none;
        flex-direction: column;
        gap: 8px;
        transform-origin: bottom right;
        transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
      }
      #flow-bridge-popover.fbp-open {
        display: flex;
        animation: fbp-popover-open 0.25s cubic-bezier(0.34,1.56,0.64,1) both;
      }
      @keyframes fbp-popover-open {
        from { transform: scale(0.85) translateY(12px); opacity: 0; }
        to   { transform: scale(1)   translateY(0);    opacity: 1; }
      }
    `;
    document.head.appendChild(style);
  }

  // ─── Buat Tombol FAB Bulat ──────────────────────────────────────────────────
  const fab = document.createElement('button');
  fab.id = FAB_ID;
  fab.title = 'Buka Menu FlowAutoBridge';
  fab.innerHTML = '🎬';
  document.body.appendChild(fab);

  // ─── Buat Popover Menu ──────────────────────────────────────────────────────
  const panel = document.createElement('div');
  panel.id = POPOVER_ID;

  // Header Status & Close
  const header = document.createElement('div');
  header.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    margin-bottom: 8px;
  `;
  header.innerHTML = `
    <div style="display: flex; align-items: center; gap: 6px;">
      <div style="width: 8px; height: 8px; border-radius: 50%; background: #10b981; box-shadow: 0 0 6px #10b981;"></div>
      <span style="font-weight: 700; font-size: 12px; color: #60a5fa;">FlowAutoBridge</span>
    </div>
    <button id="fbp-close-x" style="background:none; border:none; color:#94a3b8; cursor:pointer; font-size:14px; padding:0; line-height:1;">✕</button>
  `;
  panel.appendChild(header);

  // Content container
  const content = document.createElement('div');
  content.style.cssText = `
    display: flex;
    flex-direction: column;
    gap: 8px;
  `;
  panel.appendChild(content);

  // Badge Status Adegan
  const statusBadge = document.createElement('div');
  statusBadge.id = 'fbp-status-badge';
  statusBadge.style.cssText = `
    font-size: 11px;
    font-weight: 600;
    color: #94a3b8;
    background: rgba(255, 255, 255, 0.05);
    padding: 6px 10px;
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.08);
    display: flex;
    align-items: center;
    justify-content: space-between;
  `;
  statusBadge.innerHTML = `<span>Status:</span> <span id="fbp-scene-count" style="color: #38bdf8;">Siap Ekstrak</span>`;
  content.appendChild(statusBadge);

  // Helper untuk membuat button bergaya modern
  function createPanelButton(id, label, iconSvg, bgColor, hoverBgColor) {
    const btn = document.createElement('button');
    btn.id = id;
    btn.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      padding: 9px 12px;
      border-radius: 9px;
      font-size: 12px;
      font-weight: 600;
      border: none;
      cursor: pointer;
      color: #ffffff;
      background-color: ${bgColor};
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
      transition: all 0.2s ease;
      text-align: left;
    `;
    btn.innerHTML = `${iconSvg} <span>${label}</span>`;

    btn.addEventListener('mouseenter', () => {
      btn.style.backgroundColor = hoverBgColor;
      btn.style.transform = 'translateY(-1px)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.backgroundColor = bgColor;
      btn.style.transform = 'translateY(0)';
    });
    btn.addEventListener('mousedown', () => {
      btn.style.transform = 'scale(0.97)';
    });
    btn.addEventListener('mouseup', () => {
      btn.style.transform = 'scale(1)';
    });

    return btn;
  }

  // 1. Tombol Ekstrak & Simpan JSON
  const btnExtract = createPanelButton(
    'fbp-btn-extract',
    'Ekstrak & Simpan JSON',
    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    '#10b981',
    '#059669'
  );

  // 2. Tombol Pengaturan Mode Ekspor (Toggle Part 10 vs Full JSON)
  const btnToggleMode = createPanelButton(
    'fbp-btn-toggle-mode',
    'Mode: Full 1 File JSON',
    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>`,
    '#334155',
    '#475569'
  );

  if (isExtensionContextAlive()) {
    try {
      chrome.storage.local.get(['splitMode'], (data) => {
        if (chrome.runtime.lastError) return;
        const isFull = (data && data.splitMode || 'full_json') === 'full_json';
        const labelSpan = btnToggleMode.querySelector('span');
        if (labelSpan) {
          labelSpan.textContent = isFull ? 'Mode: Full 1 File JSON' : 'Mode: Pecah 10 Adegan';
        }
      });
    } catch (_) {}
  }

  btnToggleMode.addEventListener('click', () => {
    if (!isExtensionContextAlive()) {
      showToast('⚠️ Ekstensi baru diperbarui. Silakan Refresh halaman Gemini (F5).', false);
      return;
    }
    try {
      chrome.storage.local.get(['splitMode'], (data) => {
        if (chrome.runtime.lastError) return;
        const currentMode = (data && data.splitMode) || 'full_json';
        const newMode = currentMode === 'full_json' ? 'split_10' : 'full_json';
        chrome.storage.local.set({ splitMode: newMode }, () => {
          const isFull = newMode === 'full_json';
          const labelSpan = btnToggleMode.querySelector('span');
          if (labelSpan) {
            labelSpan.textContent = isFull ? 'Mode: Full 1 File JSON' : 'Mode: Pecah 10 Adegan';
          }
          showToast(isFull ? '📄 Mode Ekspor: Full 1 File JSON Master' : '✨ Mode Ekspor: Pecah Maks 10 Adegan/Part');
        });
      });
    } catch (e) {
      showToast('⚠️ Silakan Refresh halaman Gemini (F5).', false);
    }
  });

  // Container Riwayat 5 File JSON Terakhir
  const historyContainer = document.createElement('div');
  historyContainer.id = 'fbp-history-container';
  historyContainer.style.cssText = `
    margin-top: 6px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.05);
    font-size: 10px;
  `;
  historyContainer.innerHTML = `
    <div style="font-weight: 700; color: #94a3b8; margin-bottom: 4px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 3px; display: flex; align-items: center; justify-content: space-between; gap: 4px; user-select: none;">
      <div style="display: flex; align-items: center; gap: 4px;">
        📂 <span>5 Unduhan Terakhir:</span>
      </div>
      <button id="fbp-btn-clear-history" title="Bersihkan riwayat unduhan" style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.25); color: #f87171; cursor: pointer; font-size: 9px; font-weight: 600; padding: 2px 6px; border-radius: 4px; display: flex; align-items: center; gap: 3px; transition: all 0.15s ease;">
        🗑️ <span>Hapus</span>
      </button>
    </div>
    <ul id="fbp-history-list" style="list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 4px;">
      <li style="color: #64748b; font-style: italic; user-select: none;">Belum ada unduhan</li>
    </ul>
  `;

  function updateHistoryListUI(list) {
    const listEl = historyContainer.querySelector('#fbp-history-list');
    if (!listEl) return;
    if (!list || list.length === 0) {
      listEl.innerHTML = `<li style="color: #64748b; font-style: italic; user-select: none;">Belum ada unduhan</li>`;
      return;
    }
    listEl.innerHTML = list.map(filename => `
      <li style="color: #38bdf8; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-family: monospace; display: flex; align-items: center; gap: 4px;" title="${filename}">
        🗎 <span>${filename}</span>
      </li>
    `).join('');
  }

  const btnClearHistory = historyContainer.querySelector('#fbp-btn-clear-history');
  if (btnClearHistory) {
    btnClearHistory.addEventListener('mouseenter', () => {
      btnClearHistory.style.backgroundColor = 'rgba(239, 68, 68, 0.25)';
      btnClearHistory.style.color = '#ffffff';
      btnClearHistory.style.borderColor = 'rgba(239, 68, 68, 0.4)';
    });
    btnClearHistory.addEventListener('mouseleave', () => {
      btnClearHistory.style.backgroundColor = 'rgba(239, 68, 68, 0.12)';
      btnClearHistory.style.color = '#f87171';
      btnClearHistory.style.borderColor = 'rgba(239, 68, 68, 0.25)';
    });
    btnClearHistory.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!isExtensionContextAlive()) {
        showToast('⚠️ Ekstensi baru diperbarui. Silakan Refresh halaman Gemini (F5).', false);
        return;
      }
      try {
        chrome.storage.local.remove(['lastDownloadedJsonList', 'storyboardProjectHistory'], () => {
          updateHistoryListUI([]);
          showToast('🗑️ Riwayat nama berkas berhasil dibersihkan!');
        });
      } catch (err) {
        updateHistoryListUI([]);
        showToast('🗑️ Riwayat berhasil dibersihkan!');
      }
    });
  }

  if (isExtensionContextAlive()) {
    try {
      // Muat data awal history
      chrome.storage.local.get(['lastDownloadedJsonList'], (data) => {
        if (!chrome.runtime.lastError) {
          updateHistoryListUI((data && data.lastDownloadedJsonList) || []);
        }
      });

      // Pantau perubahan data history
      chrome.storage.onChanged.addListener((changes) => {
        if (changes.lastDownloadedJsonList) {
          updateHistoryListUI(changes.lastDownloadedJsonList.newValue || []);
        }
      });
    } catch (_) {}
  }

  // Elemen Toast Status di dalam Widget Panel
  const toast = document.createElement('div');
  toast.id = 'fbp-toast';
  toast.style.cssText = `
    font-size: 11px;
    font-weight: 600;
    color: #10b981;
    background-color: rgba(16, 185, 129, 0.12);
    border: 1px solid rgba(16, 185, 129, 0.3);
    padding: 7px 10px;
    border-radius: 7px;
    opacity: 0;
    transform: translateY(5px);
    transition: all 0.3s ease;
    display: none;
    line-height: 1.4;
    word-break: break-word;
  `;

  function showToast(message, isSuccess = true) {
    toast.textContent = message;
    toast.style.display = 'block';
    if (!isSuccess) {
      toast.style.color = '#ef4444';
      toast.style.backgroundColor = 'rgba(239, 68, 68, 0.15)';
      toast.style.border = '1px solid rgba(239, 68, 68, 0.3)';
    } else {
      toast.style.color = '#10b981';
      toast.style.backgroundColor = 'rgba(16, 185, 129, 0.15)';
      toast.style.border = '1px solid rgba(16, 185, 129, 0.3)';
    }
    toast.offsetHeight;
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(5px)';
      setTimeout(() => {
        toast.style.display = 'none';
      }, 300);
    }, 4500);
  }

  // Action Handlers:
  let isExtracting = false;
  btnExtract.addEventListener('click', () => {
    if (isExtracting) return;
    isExtracting = true;

    const originalContent = btnExtract.innerHTML;
    btnExtract.style.pointerEvents = 'none';
    btnExtract.style.opacity = '0.7';
    btnExtract.innerHTML = `<span>⏳ Mengekstrak...</span>`;

    const resetBtn = () => {
      isExtracting = false;
      btnExtract.style.pointerEvents = 'auto';
      btnExtract.style.opacity = '1';
      btnExtract.innerHTML = originalContent;
    };

    try {
      const contextAlive = isExtensionContextAlive();
      executeExtractionWithBab1Guard(
        (res) => {
          resetBtn();
          if (!contextAlive) {
            showToast(`${res.message} (Silakan Refresh F5 untuk update ekstensi).`, true);
          } else {
            showToast(res.message);
          }
          setTimeout(() => {
            scrollToLastScene();
          }, 600);
        },
        (errMsg) => {
          resetBtn();
          showToast(errMsg, false);
        }
      );
    } catch (e) {
      resetBtn();
      if (e.message && e.message.includes('Extension context invalidated')) {
        showToast('⚠️ Ekstensi baru diperbarui. Silakan Refresh halaman Gemini (F5).', false);
      } else {
        showToast('Error: ' + e.message, false);
      }
    }
  });

  // ── Toggle expand/collapse saat FAB / Close X diklik ──
  let isExpanded = false;

  function togglePopover(show) {
    isExpanded = show !== undefined ? show : !isExpanded;
    if (isExpanded) {
      panel.classList.add('fbp-open');
    } else {
      panel.classList.remove('fbp-open');
    }
  }

  // Klik FAB → toggle
  fab.addEventListener('click', (e) => {
    e.stopPropagation();
    togglePopover();
  });

  // Klik Close X → tutup
  header.querySelector('#fbp-close-x').addEventListener('click', (e) => {
    e.stopPropagation();
    togglePopover(false);
  });

  // Klik di luar → tutup popover
  document.addEventListener('click', (e) => {
    if (isExpanded && !e.target.closest(`#${POPOVER_ID}`) && !e.target.closest(`#${FAB_ID}`)) {
      togglePopover(false);
    }
  });

  // Susun elemen
  content.appendChild(btnExtract);
  content.appendChild(btnToggleMode);
  content.appendChild(historyContainer);
  content.appendChild(toast);

  document.body.appendChild(panel);
}

// Jalankan injeksi awal saat skrip dimuat
injectFloatingRightPanel();

