// ============================================================
// FlowAutoBridge — storyboard_json_extractor.js
// Pustaka universal ekstraksi & normalisasi JSON Storyboard
// Mendukung luaran ChatGPT (Custom GPT) & Google Gemini.
// ============================================================

/**
 * Membersihkan karakter kontrol, komentar trailing, atau dekorasi markdown dari string JSON
 */
function sanitizeJsonString(rawStr) {
  if (!rawStr) return '';
  let str = String(rawStr).trim();

  // Bersihkan non-breaking spaces, zero-width spaces, dan entitas HTML
  str = str
    .replace(/\u00A0/g, ' ')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');

  // 1. Buang wrapper markdown ```json ... ``` atau ``` ... ``` jika ada
  const mdMatch = str.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (mdMatch) {
    str = mdMatch[1].trim();
  }

  // 2. Buang trailing koma sebelum closing bracket/brace
  str = str.replace(/,\s*([\]}])/g, '$1');

  return str;
}

/**
 * Mencoba mem-parsing teks mentah menjadi objek atau array JSON yang valid
 */
function parseRawJsonSafely(text) {
  if (!text || typeof text !== 'string') return null;
  const clean = sanitizeJsonString(text);

  // Percobaan 1: Parsing langsung
  try {
    const obj = JSON.parse(clean);
    if (obj && typeof obj === 'object') return obj;
  } catch (_) {}

  // Percobaan 2: Cari bracket terluar untuk Object { ... }
  const firstBrace = clean.indexOf('{');
  const lastBrace = clean.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    try {
      const candidate = clean.substring(firstBrace, lastBrace + 1);
      const obj = JSON.parse(candidate);
      if (obj && typeof obj === 'object') return obj;
    } catch (_) {}
  }

  // Percobaan 3: Cari bracket terluar untuk Array [ ... ]
  const firstBracket = clean.indexOf('[');
  const lastBracket = clean.lastIndexOf(']');
  if (firstBracket !== -1 && lastBracket > firstBracket) {
    try {
      const candidate = clean.substring(firstBracket, lastBracket + 1);
      const arr = JSON.parse(candidate);
      if (Array.isArray(arr) && arr.length > 0 && typeof arr[0] === 'object' && arr[0] !== null) {
        return arr;
      }
    } catch (_) {}
  }

  return null;
}

/**
 * Sanitasi narasi suara agar TTS-Safe (bersihkan simbol @ dan _)
 */
function sanitizeTtsNarrative(narrative) {
  if (!narrative) return '';
  return String(narrative)
    .replace(/@([a-zA-Z0-9]+)/g, '$1') // Buang simbol @ pada nama karakter (@PakWahyu -> PakWahyu)
    .replace(/_/g, ' ')               // Ganti underscore dengan spasi
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalisasi ID adegan menjadi format standar (misal: ADEGAN_01, ADEGAN_01_A, COVER)
 */
function normalizeSceneId(rawId, index = 1) {
  if (!rawId) {
    return `ADEGAN_${String(index).padStart(2, '0')}`;
  }
  const str = String(rawId).trim();
  if (str.toUpperCase() === 'COVER') return 'COVER';

  // Format ADEGAN_01_A
  const subMatch = str.match(/ADEGAN_(\d+)_([A-Za-z0-9]+)/i);
  if (subMatch) {
    const num = parseInt(subMatch[1], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}_${subMatch[2].toUpperCase()}`;
  }

  // Format Adegan 1 A
  const adeganSub = str.match(/(?:adegan|scene)\s*(\d+)\s*[-_ ]*\s*([A-Za-z])/i);
  if (adeganSub) {
    const num = parseInt(adeganSub[1], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}_${adeganSub[2].toUpperCase()}`;
  }

  // Format Adegan 1
  const numMatch = str.match(/\d+/);
  if (numMatch) {
    const num = parseInt(numMatch[0], 10);
    const padded = num < 100 ? String(num).padStart(2, '0') : String(num).padStart(3, '0');
    return `ADEGAN_${padded}`;
  }

  return str.toUpperCase().replace(/[\s\-]+/g, '_');
}

/**
 * Memvalidasi apakah data hasil parsing memenuhi syarat skema Storyboard JSON
 */
function isValidStoryboardData(data) {
  if (!data) return false;

  // Kasus A: Root Object dengan array "scenes"
  if (typeof data === 'object' && !Array.isArray(data)) {
    if (Array.isArray(data.scenes) && data.scenes.length > 0) {
      const first = data.scenes[0];
      return Boolean(
        first && typeof first === 'object' &&
        (first.id || first.narrative || first.image_prompt || first.prompt_flow)
      );
    }
  }

  // Kasus B: Root Array murni daftar scenes
  if (Array.isArray(data) && data.length > 0) {
    const first = data[0];
    return Boolean(
      first && typeof first === 'object' &&
      (first.id || first.narrative || first.image_prompt || first.prompt_flow)
    );
  }

  return false;
}

/**
 * Menormalisasi seluruh struktur storyboard ke spesifikasi resmi AutoVid Factory
 */
function normalizeStoryboard(parsedJson) {
  if (!isValidStoryboardData(parsedJson)) return null;

  let rawTitle = '';
  let rawCaption = '';
  let recommendedSpeed = '+0%';
  let interactionMode = 'cinematic_pure';
  let rawScenes = [];

  if (Array.isArray(parsedJson)) {
    rawScenes = parsedJson;
  } else {
    // Dukungan format Custom GPT ChatGPT: { project: { title, chapter, chapter_title } }
    if (parsedJson.project && typeof parsedJson.project === 'object') {
      const p = parsedJson.project;
      const pTitle = p.title || p.project_title || '';
      const pChapter = p.chapter !== undefined ? p.chapter : (p.chapter_num || '');
      const pChapterTitle = p.chapter_title || '';
      if (pTitle && pChapter) {
        rawTitle = `${pTitle} - Bab ${pChapter}${pChapterTitle ? ': ' + pChapterTitle : ''}`;
      } else if (pTitle) {
        rawTitle = pTitle;
      }
      if (p.caption) rawCaption = p.caption;
      if (p.interaction_mode) interactionMode = p.interaction_mode;
      if (p.recommended_speed) recommendedSpeed = p.recommended_speed;
    }

    if (!rawTitle) {
      rawTitle = parsedJson.title || (parsedJson.meta && parsedJson.meta.title) || '';
    }
    if (!rawCaption) {
      rawCaption = parsedJson.caption || (parsedJson.meta && parsedJson.meta.caption) || '';
    }
    if (parsedJson.recommended_speed) recommendedSpeed = parsedJson.recommended_speed;
    if (parsedJson.interaction_mode) interactionMode = parsedJson.interaction_mode;
    rawScenes = parsedJson.scenes || [];
  }

  const normalizedScenes = [];
  let sceneIndexCounter = 1;

  for (let i = 0; i < rawScenes.length; i++) {
    const sc = rawScenes[i];
    if (!sc || typeof sc !== 'object') continue;

    const rawId = sc.id || sc.scene_id || sc.scene || '';
    const isCover = String(rawId).toUpperCase() === 'COVER';
    const normId = isCover ? 'COVER' : normalizeSceneId(rawId, sceneIndexCounter);

    if (!isCover) {
      sceneIndexCounter++;
    }

    const narrative = sanitizeTtsNarrative(sc.narrative || sc.narasi || sc.text || '');
    const translation = String(sc.translation || sc.terjemahan || '').trim();
    const rawImagePrompt = sc.image_prompt || sc.prompt_flow || sc.prompt || sc.flow_prompt || '';
    const imagePrompt = String(rawImagePrompt).trim();
    const videoPrompt = String(sc.video_prompt || sc.motion_prompt || '').trim();
    const promptFlow = imagePrompt; // Selaras untuk automator Google Flow

    let duration = 4;
    if (sc.duration !== undefined && !isNaN(Number(sc.duration))) {
      duration = Number(sc.duration);
    } else if (videoPrompt) {
      duration = 8;
    }

    const sceneObj = {
      id: normId,
      narrative: narrative,
      translation: translation,
      image_prompt: imagePrompt,
      video_prompt: videoPrompt,
      prompt_flow: promptFlow,
      duration: duration
    };

    // Ekstraksi & pertahankan headline dan editorial_text (SRS-40 / Headline Mandate)
    let headline = String(sc.headline || '').trim();
    if (!headline && imagePrompt) {
      const m = imagePrompt.match(/Indonesian headline [\"\x27](.+?)[\"\x27]/i) || imagePrompt.match(/headline [\"\x27](.+?)[\"\x27]/i);
      if (m) headline = m[1].trim();
    }
    if (headline) {
      sceneObj.headline = headline;
      sceneObj.editorial_text = Array.isArray(sc.editorial_text) ? sc.editorial_text : [{
        text: headline,
        language: 'id',
        render_mode: 'in_image',
        placement: 'upper_safe',
        preset: 'headline'
      }];
    } else if (Array.isArray(sc.editorial_text)) {
      sceneObj.editorial_text = sc.editorial_text;
    }

    if (sc.parent_scene) sceneObj.parent_scene = sc.parent_scene;
    if (sc.shot_number) sceneObj.shot_number = Number(sc.shot_number);
    if (sc.shot_type) sceneObj.shot_type = sc.shot_type;
    if (sc.cta_type) sceneObj.cta_type = sc.cta_type;

    normalizedScenes.push(sceneObj);
  }

  if (normalizedScenes.length === 0) return null;

  // Deteksi rasio aspek: Kunci eksplisit -> Analisis teks prompt -> Default 9:16
  let aspectRatio = '';
  if (!Array.isArray(parsedJson)) {
    aspectRatio = parsedJson.aspect_ratio || parsedJson.video_ratio || (parsedJson.project && (parsedJson.project.aspect_ratio || parsedJson.project.video_ratio)) || '';
  }
  if (!aspectRatio) {
    for (const sc of normalizedScenes) {
      const p = `${sc.image_prompt || ''} ${sc.prompt_flow || ''}`;
      if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) {
        aspectRatio = '9:16';
        break;
      }
      if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) {
        aspectRatio = '16:9';
        break;
      }
    }
  }
  if (!aspectRatio) aspectRatio = '9:16';

  // Fallback judul jika kosong: ambil 4 kata awal dari adegan pertama
  let finalTitle = rawTitle.trim();
  if (!finalTitle) {
    const firstRealScene = normalizedScenes.find(s => s.id !== 'COVER') || normalizedScenes[0];
    const words = (firstRealScene.narrative || 'Cerita Pendek').split(/\s+/).slice(0, 4);
    finalTitle = words.join(' ').trim();
  }

  const result = {
    title: finalTitle,
    caption: rawCaption.trim(),
    aspect_ratio: aspectRatio,
    video_ratio: aspectRatio,
    recommended_speed: recommendedSpeed,
    interaction_mode: interactionMode,
    total_scenes: normalizedScenes.length,
    scenes: normalizedScenes
  };

  if (!Array.isArray(parsedJson) && parsedJson.visual_reference) {
    result.visual_reference = parsedJson.visual_reference;
  }

  return result;
}

/**
 * Memindai seluruh blok kode pre/code pada container DOM dan mengekstrak Storyboard JSON
 */
function findStoryboardJsonInContainer(container) {
  if (!container) return null;

  // Kumpulkan seluruh elemen blok kode
  const codeElements = Array.from(
    container.querySelectorAll('pre, code, .code-block, [class*="code-block"]')
  );

  // Iterasi dari blok kode paling bawah (terakhir) ke atas
  for (let i = codeElements.length - 1; i >= 0; i--) {
    const el = codeElements[i];
    // Hindari membaca elemen anak jika tag induk pre sudah mencakup seluruh teks
    if (el.tagName === 'CODE' && el.parentElement && el.parentElement.tagName === 'PRE') {
      continue;
    }

    const text = (el.innerText || el.textContent || '').trim();
    if (!text || text.length < 50) continue;

    // Abaikan jika jelas-jelas ini blok teks opsi interview [1] / [2]
    if (/^\[\d+\]\s+/m.test(text) && !text.includes('"scenes"') && !text.includes('"id"')) {
      continue;
    }

    const parsed = parseRawJsonSafely(text);
    if (parsed) {
      const normalized = normalizeStoryboard(parsed);
      if (normalized && normalized.scenes.length > 0) {
        console.log(`[FlowAutoBridge-Extractor] Berhasil mendeteksi Storyboard JSON dengan ${normalized.scenes.length} adegan.`);
        return normalized;
      }
    }
  }

  return null;
}

/**
 * Menghasilkan nama berkas JSON yang bersih dan representatif berdasarkan judul
 */
function generateCleanStoryboardFilename(title) {
  const rawStr = String(title || "storyboard").trim();
  const existingHashMatch = rawStr.match(/^(.+)[_\s]([a-z0-9]{4})$/i);
  if (existingHashMatch) {
    let cleanBase = existingHashMatch[1]
      .replace(/\(?part\s*\d+\)?/gi, '')
      .replace(/[^\w\s\-]+/g, ' ')
      .trim();
    let words = cleanBase.split(/\s+/).filter(Boolean);
    if (words.length > 4) words = words.slice(0, 4);
    const safeTitle = words.join('_').toLowerCase() || 'storyboard';
    return `${safeTitle}_${existingHashMatch[2].toLowerCase()}.json`;
  }

  let clean = rawStr
    .replace(/\(?part\s*\d+\)?/gi, '')
    .replace(/[^\w\s\-]+/g, ' ')
    .trim();
  let words = clean.split(/\s+/).filter(Boolean);
  if (words.length > 4) {
    const babMatch = clean.match(/\b(bab\s*\d+)\b/i);
    if (babMatch) {
      const babWords = babMatch[1].split(/\s+/);
      const otherWords = clean.replace(new RegExp(`\\b${babMatch[1]}\\b`, 'i'), '').trim().split(/\s+/).filter(Boolean);
      const remainingSlots = Math.max(1, 4 - babWords.length);
      words = [...otherWords.slice(0, remainingSlots), ...babWords];
    } else {
      words = words.slice(0, 4);
    }
  }
  const safeTitle = words.join('_').toLowerCase() || 'storyboard';
  const randHash = Math.random().toString(36).substring(2, 6);
  return `${safeTitle}_${randHash}.json`;
}

/**
 * Mencegat klik tombol unduh bawaan Gemini/ChatGPT (Native Code-Block Download Interceptor)
 * Mengganti nama default 'download.json' dengan nama berbasis judul asli storyboard JSON.
 */
/**
 * Menampilkan toast kecil sementara di pojok layar saat file dicegat
 */
function showFloatingInterceptorToast(message) {
  if (typeof document === 'undefined') return;
  let toastEl = document.getElementById('fab-interceptor-toast');
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.id = 'fab-interceptor-toast';
    toastEl.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: linear-gradient(135deg, #0f172a, #1e293b);
      color: #38bdf8;
      border: 1px solid #38bdf8;
      border-radius: 8px;
      padding: 10px 16px;
      font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 8px 24px rgba(0,0,0,0.5);
      z-index: 9999999;
      opacity: 0;
      transform: translateY(10px);
      transition: all 0.3s ease;
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    document.body.appendChild(toastEl);
  }
  toastEl.innerHTML = `<span>✨</span> <span>${message}</span>`;
  toastEl.style.opacity = '1';
  toastEl.style.transform = 'translateY(0)';
  setTimeout(() => {
    toastEl.style.opacity = '0';
    toastEl.style.transform = 'translateY(10px)';
  }, 4000);
}

/**
 * Mencegat klik tombol unduh bawaan Gemini/ChatGPT (Native Code-Block Download Interceptor)
 * Mengganti nama default 'download.json' dengan nama berbasis judul asli storyboard JSON.
 */
function attachNativeCodeBlockDownloadInterceptor(downloadHandler) {
  if (typeof window === 'undefined') return;

  window.addEventListener('click', (e) => {
    const btn = e.target.closest('button, [role="button"], a');
    if (!btn) return;

    // Jika ini adalah tombol injeksi FlowAutoBridge kita sendiri, biarkan handler tombolnya bekerja
    if (btn.classList && btn.classList.contains('fab-btn-extract-json')) {
      return;
    }

    // Cek apakah tombol ini berada di dalam container/header blok kode
    let codeBlockContainer = btn.closest('code-block, code-block-decorator, .code-block, .code-block-container, pre, [class*="code-block"]') ||
                             btn.closest('.code-block-header, .code-block-decoration')?.parentElement ||
                             btn.parentElement?.parentElement;
    if (!codeBlockContainer) return;

    // Abaikan jika tombol ini jelas-jelas tombol salin (copy/salin)
    const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
    const titleAttr = (btn.getAttribute('title') || '').toLowerCase();
    const btnText = (btn.innerText || btn.textContent || '').toLowerCase();
    const isCopyBtn = aria.includes('copy') || aria.includes('salin') || 
                      titleAttr.includes('copy') || titleAttr.includes('salin') || 
                      btnText.includes('copy') || btnText.includes('salin');
    if (isCopyBtn) return;

    // Cek indikator tombol download kode bawaan Gemini / ChatGPT
    const testId = (btn.getAttribute('data-test-id') || '').toLowerCase();
    const svgContent = btn.querySelector('svg')?.innerHTML?.toLowerCase() || '';

    const isDownloadIndicator = 
      aria.includes('download') || aria.includes('unduh') ||
      titleAttr.includes('download') || titleAttr.includes('unduh') ||
      testId.includes('download') ||
      btnText.includes('download') || btnText.includes('unduh') ||
      svgContent.includes('download') ||
      Boolean(btn.querySelector('[data-icon*="download"], [class*="download"], mat-icon'));

    // Di header blok kode Gemini, biasanya hanya ada 2 tombol: Download dan Copy.
    // Jika tombol bukan Copy dan berada di header code block, anggap sebagai tombol download!
    const isHeaderAction = Boolean(btn.closest('.code-block-header, .code-block-decoration, [class*="decoration"], [class*="header"]'));
    if (!isDownloadIndicator && !isHeaderAction) return;

    let preOrCode = codeBlockContainer.querySelector('pre, code');
    if (!preOrCode) {
      const parent = btn.closest('div, header');
      if (parent && parent.nextElementSibling) {
        preOrCode = parent.nextElementSibling.querySelector('pre, code') || parent.nextElementSibling;
      }
    }
    if (!preOrCode) preOrCode = codeBlockContainer;

    const rawCodeText = (preOrCode.innerText || preOrCode.textContent || '').trim();
    if (!rawCodeText || rawCodeText.length < 50) return;

    const parsed = parseRawJsonSafely(rawCodeText);
    if (parsed) {
      const normalized = normalizeStoryboard(parsed);
      if (normalized && normalized.scenes && normalized.scenes.length > 0) {
        // HENTIKAN DOWNLOAD DEFAULT GOOGLE GEMINI YANG MENAMAI 'download.json'!
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const filename = generateCleanStoryboardFilename(normalized.title);
        console.log(`[FlowAutoBridge] Mencegat tombol unduh bawaan ('download.json' dicegah) -> Diganti: ${filename}`);

        showFloatingInterceptorToast(`Storyboard dinamai otomatis: <b>${filename}</b>`);

        if (typeof downloadHandler === 'function') {
          downloadHandler(normalized, filename);
        } else {
          executeIntegratedDownload(normalized, filename);
        }
      }
    }
  }, true); // Gunakan capture phase agar mendahului event listener internal Gemini!
}

/**
 * Eksekusi pengunduhan terpadu (Service Worker -> DOM Fallback)
 */
function executeIntegratedDownload(data, filename) {
  const projectFolderName = filename.replace(/\.json$/i, '');
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ activeProjectFolder: projectFolderName });
  }
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
    try {
      chrome.runtime.sendMessage({
        action: 'download_storyboard',
        data: data,
        filename: filename,
        projectFolder: projectFolderName
      }, (res) => {
        if (chrome.runtime.lastError || !res || !res.success) {
          triggerDomBlobDownload(data, filename);
        }
      });
      if (chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['lastDownloadedJsonList'], (storeData) => {
          const list = (storeData && storeData.lastDownloadedJsonList) || [];
          if (!list.includes(filename)) {
            list.unshift(filename);
            if (list.length > 10) list.pop();
            chrome.storage.local.set({ lastDownloadedJsonList: list });
          }
        });
      }
      return;
    } catch (_) {}
  }
  triggerDomBlobDownload(data, filename);
}

/**
 * Unduhan DOM Blob URL langsung
 */
function triggerDomBlobDownload(data, filename) {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename.toLowerCase().endsWith('.json') ? filename : `${filename}.json`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (a.parentNode) a.parentNode.removeChild(a);
      URL.revokeObjectURL(url);
    }, 400);
  } catch (err) {
    console.error('[FlowAutoBridge] Gagal unduh file via DOM:', err);
  }
}

/**
 * Melakukan scroll halus ke bagian paling bawah percakapan (scroll to bottom)
 */
function smoothScrollToBottom() {
  if (typeof window === 'undefined') return;
  try {
    // 1. Scroll level window / documentElement
    const maxScroll = Math.max(
      document.body.scrollHeight || 0,
      document.documentElement.scrollHeight || 0
    );
    window.scrollTo({ top: maxScroll, behavior: 'smooth' });

    // 2. Scroll container scrollable khusus ChatGPT dan Gemini
    const scrollContainers = document.querySelectorAll(
      'main, div[class*="react-scroll-to-bottom"], div[class*="overflow-y-auto"], .conversation-container, [data-testid="conversation-turn-list"]'
    );
    scrollContainers.forEach(sc => {
      if (sc && sc.scrollHeight > sc.clientHeight) {
        sc.scrollTo({ top: sc.scrollHeight, behavior: 'smooth' });
      }
    });
  } catch (err) {
    console.warn('[FlowAutoBridge] Gagal scrolling:', err);
  }
}

/**
 * Menyisipkan tombol aksi [⚡ Ekstrak JSON] langsung di header setiap blok kode JSON
 * Dilengkapi proteksi deduplikasi mutlak agar tombol hanya muncul tepat 1 buah per blok kode.
 */
function injectStoryboardDownloadButtonsInCodeBlocks() {
  if (typeof document === 'undefined') return;

  // 1. Pembersihan global: Buang semua tombol duplikat jika ada parent yang memuat lebih dari 1 tombol
  const allBtns = document.querySelectorAll('.fab-btn-extract-json');
  const seenParents = new Set();
  allBtns.forEach(btn => {
    const parent = btn.parentElement;
    if (!parent) return;
    if (seenParents.has(parent)) {
      btn.remove();
    } else {
      seenParents.add(parent);
    }
  });

  // 2. Temukan semua elemen blok kode di halaman (Mendukung Gemini & ChatGPT)
  const codeBlocks = document.querySelectorAll(
    'code-block, code-block-decorator, .code-block-container, pre, [class*="code-block"]'
  );

  codeBlocks.forEach(container => {
    // Dapatkan elemen kode (pre / code)
    let codeEl = container.querySelector('pre, code') || container;
    const rawText = (codeEl.innerText || codeEl.textContent || '').trim();
    if (!rawText || rawText.length < 50) return;

    // Cek apakah teks kode memenuhi kriteria Storyboard JSON (scenes & title/narrative/id)
    if (!rawText.includes('"scenes"') || (!rawText.includes('"title"') && !rawText.includes('"narrative"') && !rawText.includes('"id"') && !rawText.includes('"project"'))) {
      return;
    }

    // Cari header blok kode:
    // A. Header bawaan Gemini (.code-block-decoration, .code-block-header)
    let headerEl = container.querySelector('.code-block-decoration, .code-block-header, [class*="code-block-decoration"]');
    
    // B. Header bawaan ChatGPT (div tepat sebelum tag pre, atau baris atas di container)
    if (!headerEl) {
      const pre = container.tagName === 'PRE' ? container : container.querySelector('pre');
      if (pre && pre.previousElementSibling) {
        const prev = pre.previousElementSibling;
        const prevText = (prev.innerText || prev.textContent || '').toLowerCase();
        if (prevText.includes('json') || prev.querySelector('button, svg')) {
          headerEl = prev;
        }
      }
    }

    // C. Jika belum ketemu, periksa div pembungkus terdekat yang memuat label 'JSON'
    if (!headerEl && container.parentElement) {
      headerEl = container.parentElement.querySelector('.code-block-decoration, .code-block-header, div[class*="items-center"], div[class*="justify-between"]');
    }

    if (!headerEl) {
      headerEl = container;
    }

    // Proteksi: Jika header ini sudah memiliki tombol kita, lewati!
    if (headerEl.querySelector('.fab-btn-extract-json') || headerEl.hasAttribute('data-fab-ready')) {
      return;
    }

    // Tandai header agar tidak pernah disisipkan ulang oleh observer
    headerEl.setAttribute('data-fab-ready', 'true');

    // Sinkronkan judul aktif ke storage dan background sedini mungkin
    const parsedInitial = parseRawJsonSafely(rawText);
    if (parsedInitial) {
      const normInitial = normalizeStoryboard(parsedInitial);
      if (normInitial && normInitial.title) {
        const initialFn = generateCleanStoryboardFilename(normInitial.title);
        const initialFolder = initialFn.replace(/\.json$/i, '');
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({
            latestActiveStoryboardTitle: normInitial.title,
            lastGeneratedStoryboardFilename: initialFn,
            activeProjectFolder: initialFolder
          });
        }
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
          try {
            chrome.runtime.sendMessage({
              action: 'sync_storyboard_title',
              title: normInitial.title,
              filename: initialFn,
              projectFolder: initialFolder
            });
          } catch (_) {}
        }
      }
    }

    // Buat tombol aksi tunggal yang rapi dan elegan
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'fab-btn-extract-json';
    btn.innerHTML = '⚡ Ekstrak JSON';
    btn.title = 'Ekstrak & Unduh Storyboard JSON sesuai Judul Asli';
    btn.style.cssText = `
      background: linear-gradient(135deg, #0284c7, #0369a1);
      color: #ffffff;
      border: 1px solid #38bdf8;
      border-radius: 6px;
      padding: 3px 9px;
      font-size: 11px;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      cursor: pointer;
      margin: 0 8px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      transition: all 0.2s ease;
      vertical-align: middle;
      white-space: nowrap;
      z-index: 10;
    `;

    btn.addEventListener('mouseenter', () => {
      btn.style.background = 'linear-gradient(135deg, #0369a1, #0284c7)';
      btn.style.boxShadow = '0 3px 8px rgba(56, 189, 248, 0.4)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
      btn.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
    });

    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();

      // Gulir halaman ke bawah secara otomatis saat tombol diklik
      smoothScrollToBottom();

      // Baca teks kode secara segar dari DOM saat tombol diklik
      const activeCodeEl = container.querySelector('pre, code') || codeEl;
      const currentRawText = (activeCodeEl.innerText || activeCodeEl.textContent || '').trim();

      const parsed = parseRawJsonSafely(currentRawText);
      if (parsed) {
        const normalized = normalizeStoryboard(parsed);
        if (normalized && normalized.scenes && normalized.scenes.length > 0) {
          const filename = generateCleanStoryboardFilename(normalized.title);
          const projectFolder = filename.replace(/\.json$/i, '');
          
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({
              latestActiveStoryboardTitle: normalized.title,
              lastGeneratedStoryboardFilename: filename,
              activeProjectFolder: projectFolder
            });
          }
          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
            try {
              chrome.runtime.sendMessage({
                action: 'sync_storyboard_title',
                title: normalized.title,
                filename: filename,
                projectFolder: projectFolder
              });
            } catch (_) {}
          }

          executeIntegratedDownload(normalized, filename);
          
          btn.innerHTML = `✓ Disimpan: ${filename}`;
          btn.style.background = 'linear-gradient(135deg, #059669, #047857)';
          btn.style.borderColor = '#34d399';
          showFloatingInterceptorToast(`Storyboard tersimpan otomatis: <b>${filename}</b>`);

          setTimeout(() => {
            btn.innerHTML = '⚡ Ekstrak JSON';
            btn.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
            btn.style.borderColor = '#38bdf8';
          }, 3500);
          return;
        }
      }
      btn.innerHTML = '⚠️ Gagal mem-parsing JSON';
      setTimeout(() => {
        btn.innerHTML = '⚡ Ekstrak JSON';
      }, 2000);
    });

    // Sisipkan tombol persis di sebelah label bahasa ("JSON" / "</> JSON")
    if (headerEl.firstChild) {
      headerEl.insertBefore(btn, headerEl.firstChild.nextSibling || headerEl.firstChild);
    } else {
      headerEl.appendChild(btn);
    }
  });
}

// Inisialisasi pengawasan DOM dinamis untuk blok kode baru
function setupCodeBlockObserver() {
  if (typeof document === 'undefined') return;

  injectStoryboardDownloadButtonsInCodeBlocks();

  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      injectStoryboardDownloadButtonsInCodeBlocks();
    }, 500);
  });

  const targetNode = document.body || document.documentElement;
  if (targetNode) {
    observer.observe(targetNode, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  // Pantau pointerdown pada seluruh dokumen untuk menangkap sinkronisasi judul sebelum unduhan dimulai
  window.addEventListener('pointerdown', (e) => {
    const btn = e.target.closest('button, [role="button"], a');
    if (!btn) return;
    const container = btn.closest('code-block, code-block-decorator, .code-block, .code-block-container, pre, [class*="code-block"]') ||
                      btn.closest('.code-block-header, .code-block-decoration')?.parentElement;
    if (!container) return;
    const codeEl = container.querySelector('pre, code') || container;
    const text = (codeEl.innerText || codeEl.textContent || '').trim();
    if (text.includes('"scenes"')) {
      const parsed = parseRawJsonSafely(text);
      if (parsed) {
        const norm = normalizeStoryboard(parsed);
        if (norm && norm.title) {
          const fn = generateCleanStoryboardFilename(norm.title);
          const projectFolder = fn.replace(/\.json$/i, '');
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({
              latestActiveStoryboardTitle: norm.title,
              lastGeneratedStoryboardFilename: fn,
              activeProjectFolder: projectFolder
            });
          }
          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
            try {
              chrome.runtime.sendMessage({
                action: 'sync_storyboard_title',
                title: norm.title,
                filename: fn,
                projectFolder: projectFolder
              });
            } catch (_) {}
          }
        }
      }
    }
  }, true);
}

// Ekspor untuk pemakaian di lingkungan Browser extension & Node test runner jika ada
if (typeof window !== 'undefined') {
  window.StoryboardJsonExtractor = {
    parseRawJsonSafely,
    sanitizeTtsNarrative,
    normalizeSceneId,
    isValidStoryboardData,
    normalizeStoryboard,
    findStoryboardJsonInContainer,
    generateCleanStoryboardFilename,
    attachNativeCodeBlockDownloadInterceptor,
    showFloatingInterceptorToast,
    injectStoryboardDownloadButtonsInCodeBlocks,
    executeIntegratedDownload
  };

  // Aktifkan pencegatan tombol unduh bawaan Gemini/ChatGPT secara otomatis
  try {
    attachNativeCodeBlockDownloadInterceptor();
    setupCodeBlockObserver();
  } catch (err) {
    console.warn('[FlowAutoBridge] Gagal menginisialisasi download interceptor & observer:', err);
  }
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    parseRawJsonSafely,
    sanitizeTtsNarrative,
    normalizeSceneId,
    isValidStoryboardData,
    normalizeStoryboard,
    findStoryboardJsonInContainer,
    generateCleanStoryboardFilename,
    attachNativeCodeBlockDownloadInterceptor
  };
}
