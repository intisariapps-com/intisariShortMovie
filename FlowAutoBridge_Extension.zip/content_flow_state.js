// ==============================================================================
// 📁 FILE   : content_flow_state.js (Lokasi: extension/content_flow_state.js)
// 📝 FUNGSI : Manajer sinkronisasi state Google Flow tanpa injeksi DOM melayang.
//             Menghubungkan siklus hidup robotik ke chrome.storage.local untuk Popup.
// ==============================================================================

(function(root) {
  function removeLegacyOverlay() {
    try {
      if (typeof document !== 'undefined') {
        const overlay = document.getElementById('flow-bridge-status-overlay');
        if (overlay && overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
      }
    } catch (e) {}
  }

  function extractStep(text) {
    if (!text || typeof text !== 'string') return null;
    const match = text.match(/(\d\/\d)/);
    return match ? match[1] : null;
  }

  function isAllQueueCompletedText(text) {
    if (!text || typeof text !== 'string') return false;
    return /semua\s+(antrean|tugas|adegan)\s+selesai/i.test(text);
  }

  function createFlowStatePayload(statusText, isRunning = true, isSwarm = false, isStandby = false, extra = {}) {
    const isAllCompleted = Boolean(extra && extra.allCompleted) || isAllQueueCompletedText(statusText);
    let status = 'running';
    if (isAllCompleted) {
      status = 'done';
    } else if (isStandby) {
      status = 'standby';
    } else if (!isRunning) {
      status = 'paused';
    }

    return {
      text: statusText || '',
      status: status,
      mode: isSwarm ? 'swarm' : 'local',
      isStandby: !!isStandby,
      isRunning: !!isRunning,
      allCompleted: isAllCompleted,
      step: extractStep(statusText),
      updatedAt: Date.now(),
      ...extra
    };
  }

  function syncFlowState(statusText, isRunning = true, isSwarm = false, isStandby = false, extra = {}) {
    removeLegacyOverlay();
    const payload = createFlowStatePayload(statusText, isRunning, isSwarm, isStandby, extra);

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.set({ flowExecutionState: payload });
      } catch (e) {}
    }
    return payload;
  }

  const FlowStateManager = {
    removeLegacyOverlay,
    extractStep,
    isAllQueueCompletedText,
    createFlowStatePayload,
    syncFlowState
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlowStateManager;
  } else {
    root.FlowStateManager = FlowStateManager;
    root.removeLegacyOverlay = removeLegacyOverlay;
    root.syncFlowState = syncFlowState;
    // Backward compatibility alias: pastikan setiap panggilan lama tidak lagi merender DOM
    root.injectFlowStatusOverlay = function(statusText, isRunning = true, isSwarm = false, isStandby = false, extra = {}) {
      return syncFlowState(statusText, isRunning, isSwarm, isStandby, extra);
    };
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
