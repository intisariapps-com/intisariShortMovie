// ==============================================================================
// 📁 FILE   : extension/capcut_draft_writer.js
// 📝 FUNGSI : Injektor Draf CapCut Desktop via File System Access API (SRS-FAB-STANDALONE-001)
//             Menulis draft_info.json, draft_meta_info.json, subtitles.srt, dan root_meta_info.json.
// ==============================================================================

(function(global) {
  'use strict';

  const DB_NAME = 'FlowAutoBridgeDB';
  const STORE_NAME = 'handles';
  const KEY_CAPCUT_DIR = 'capcut_draft_dir_handle';

  /**
   * Helper UUID v4 generator di peramban.
   */
  function generateUuid() {
    if (global.crypto && global.crypto.randomUUID) {
      return global.crypto.randomUUID().toUpperCase();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16).toUpperCase();
    });
  }

  /**
   * Membuka koneksi IndexedDB untuk persistensi FileSystemDirectoryHandle.
   */
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Menyimpan DirectoryHandle ke IndexedDB dan metadata nama folder ke chrome.storage.local.
   */
  async function saveDirectoryHandle(handle) {
    const db = await openDatabase();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(handle, KEY_CAPCUT_DIR);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.set({
          capcutFolderName: handle.name || 'CapCut Drafts',
          capcutFolderConnectedAt: Date.now()
        });
      } catch (_) {}
    }
  }

  /**
   * Mengambil DirectoryHandle dari IndexedDB.
   */
  async function getStoredDirectoryHandle() {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(KEY_CAPCUT_DIR);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Menghapus DirectoryHandle dari IndexedDB dan metadata dari chrome.storage.local.
   */
  async function clearStoredDirectoryHandle() {
    try {
      const db = await openDatabase();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).delete(KEY_CAPCUT_DIR);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch (_) {}

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.remove(['capcutFolderName', 'capcutFolderConnectedAt']);
      } catch (_) {}
    }
  }

  /**
   * Cek izin pasif tanpa memicu error DOMException 'User activation required'.
   * Aman dipanggil saat inisialisasi / startup peramban.
   */
  async function queryDirectoryPermission(fileHandle, readWrite = true) {
    if (!fileHandle || typeof fileHandle.queryPermission !== 'function') return 'denied';
    try {
      const options = { mode: readWrite ? 'readwrite' : 'read' };
      return await fileHandle.queryPermission(options);
    } catch (e) {
      return 'denied';
    }
  }

  /**
   * Meminta izin pembacaan/penulisan secara interaktif saat adanya user gesture (klik tombol).
   */
  async function verifyPermission(fileHandle, readWrite = true) {
    if (!fileHandle) return false;
    const options = { mode: readWrite ? 'readwrite' : 'read' };
    try {
      const status = await fileHandle.queryPermission(options);
      if (status === 'granted') return true;
      const reqStatus = await fileHandle.requestPermission(options);
      return reqStatus === 'granted';
    } catch (e) {
      console.warn("verifyPermission interaktif gagal:", e);
      return false;
    }
  }

  /**
   * Membuka File Picker browser untuk memilih folder draf CapCut (com.lveditor.draft).
   */
  async function pairCapCutDirectory() {
    if (!global.showDirectoryPicker) {
      throw new Error("File System Access API tidak didukung di peramban ini. Pastikan menggunakan Chrome/Edge terbaru.");
    }

    let dirHandle;
    try {
      // W3C File System Access API: 'videos' adalah enum WellKnownDirectory yang sah (enum standar)
      dirHandle = await global.showDirectoryPicker({
        id: 'capcut_draft_picker',
        mode: 'readwrite',
        startIn: 'videos'
      });
    } catch (pickerErr) {
      // Jika pengguna membatalkan dialog, teruskan AbortError tanpa retry
      if (pickerErr && pickerErr.name === 'AbortError') {
        throw pickerErr;
      }
      // Jika startIn 'videos' ditolak atau tidak didukung oleh browser, coba tanpa startIn
      try {
        dirHandle = await global.showDirectoryPicker({
          id: 'capcut_draft_picker',
          mode: 'readwrite'
        });
      } catch (retryErr) {
        throw retryErr;
      }
    }

    // Verifikasi izin direktori

    const isGranted = await verifyPermission(dirHandle, true);
    if (!isGranted) {
      throw new Error("Izin akses folder draf CapCut tidak diberikan.");
    }

    await saveDirectoryHandle(dirHandle);
    return dirHandle;
  }

  /**
   * Helper menulis string / blob ke berkas di dalam DirectoryHandle.
   */
  async function writeFileToDir(dirHandle, fileName, content) {
    const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
  }

  /**
   * Pembangkit cover thumbnail JPEG default (1080x1920) jika belum ada.
   */
  async function createDefaultCoverBlob() {
    if (typeof document !== 'undefined') {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 1080;
        canvas.height = 1920;
        const ctx = canvas.getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 0, 1920);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#1e293b');
        grad.addColorStop(1, '#0284c7');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1080, 1920);
        return await new Promise(res => canvas.toBlob(res, 'image/jpeg', 0.9));
      } catch (_) {}
    }
    return null;
  }

  /**
   * Membangun berkas draft_info.json & draft_content.json sesuai spesifikasi CapCut Global Desktop v9.5.0 (SRS-FAB-062).
   */
  function buildDraftInfoJson(projectName, scenes, audioFileName, totalDurationUs, imageFolderPath = '', draftFoldPath = '', audioPathOverride = '') {
    const nowUs = Date.now() * 1000;
    const projectUuid = generateUuid();
    const speedId = generateUuid();
    const canvasDefaultId = generateUuid();
    const audioMaterialId = generateUuid();
    const isMac = typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.includes('Mac');
    const fontPathSystem = isMac ? '/Applications/CapCut.app/Contents/Resources/Font/SystemFont/en.ttf' : '';

    // 1. Eksklusi adegan COVER dari track linimasa (COVER dijadikan draft_cover.jpg)
    const rawList = Array.isArray(scenes) ? scenes : [];
    const hasCoverFirst = rawList.length > 1 && String(rawList[0].id || '').toUpperCase() === 'COVER';
    let coverOffsetS = 0.0;
    if (hasCoverFirst) {
      const covTiming = rawList[0].timing || {};
      if (typeof covTiming.end === 'number' && covTiming.end > 0) {
        coverOffsetS = parseFloat(covTiming.end);
      }
    }
    const timelineScenes = rawList.length > 1
      ? rawList.filter(sc => String(sc.id || '').toUpperCase() !== 'COVER')
      : rawList;

    // 2. Normalisasi stempel waktu mikrodetik (Anti-Null / Anti-Empty Timerange Guard)
    const parsedScenes = [];
    let currentTimeUs = 0;
    let computedTotalDurationUs = 0;

    timelineScenes.forEach((sc, idx) => {
      const scId = sc.id || `ADEGAN_${String(idx + 1).padStart(2, '0')}`;
      let startUs = currentTimeUs;
      let durUs = 3500000;

      if (typeof sc.duration_us === 'number' && !Number.isNaN(sc.duration_us) && sc.duration_us > 0) {
        durUs = Math.round(sc.duration_us);
        startUs = (typeof sc.start_us === 'number' && !Number.isNaN(sc.start_us) && sc.start_us >= 0)
          ? Math.round(sc.start_us)
          : currentTimeUs;
      } else if (sc.timing && typeof sc.timing.start === 'number' && typeof sc.timing.end === 'number' && sc.timing.end > sc.timing.start) {
        const durS = parseFloat(sc.timing.end) - parseFloat(sc.timing.start);
        const normStartS = Math.max(0.0, parseFloat(sc.timing.start) - coverOffsetS);
        startUs = Math.round(normStartS * 1000000);
        durUs = Math.round(durS * 1000000);
      } else {
        const rawDurS = parseFloat(sc.duration);
        const durS = (!Number.isNaN(rawDurS) && rawDurS > 0) ? rawDurS : 3.5;
        startUs = currentTimeUs;
        durUs = Math.round(durS * 1000000);
      }

      const ext = sc.image_ext || 'jpg';
      const imgFileName = sc.image_filename || `${scId}.${ext}`;
      const fullImgPath = imageFolderPath ? `${imageFolderPath.replace(/\\/g, '/')}/${imgFileName}` : imgFileName;

      parsedScenes.push({
        id: scId,
        imageName: imgFileName,
        imagePath: fullImgPath,
        narrative: (sc.narrative || sc.text || '').trim(),
        startUs,
        durUs
      });

      currentTimeUs = startUs + durUs;
      if (currentTimeUs > computedTotalDurationUs) {
        computedTotalDurationUs = currentTimeUs;
      }
    });

    const effectiveTotalDurationUs = (typeof totalDurationUs === 'number' && !Number.isNaN(totalDurationUs) && totalDurationUs > 0)
      ? Math.round(totalDurationUs)
      : (computedTotalDurationUs > 0 ? computedTotalDurationUs : 14000000);

    const materialsVideos = [];
    const materialsTexts = [];
    const videoSegments = [];
    const textSegments = [];

    // 3. Bangun Video Segments (Track 0) dan Subtitle Segments (Track 1)
    parsedScenes.forEach((psc) => {
      const imgMaterialId = generateUuid();
      const videoSegmentId = generateUuid();

      materialsVideos.push({
        aigc_history_id: "",
        aigc_item_id: "",
        aigc_type: "none",
        audio_fade: null,
        category_id: "",
        category_name: "local",
        check_flag: 63487,
        crop: null,
        crop_ratio: "free",
        crop_scale: 1.0,
        duration: 10800000000,
        extra_type_option: 0,
        formula_id: "",
        freeze: null,
        has_audio: false,
        has_sound_separated: false,
        height: 1920,
        id: imgMaterialId,
        intensifies_audio_path: "",
        intensifies_path: "",
        is_ai_generate_content: false,
        is_copyright: false,
        is_set_beauty_mode: false,
        is_text_edit_overdub: false,
        is_unified_beauty_mode: false,
        is_video_copilot_aigc_content: false,
        local_id: "",
        local_material_id: "",
        material_id: "",
        material_name: psc.imageName,
        material_url: "",
        media_path: "",
        path: psc.imagePath,
        picture_from: "none",
        request_id: "",
        reverse_path: "",
        source: 0,
        source_platform: 0,
        team_id: "",
        type: "photo",
        width: 1080
      });

      videoSegments.push({
        caption_info: null,
        cartoon: false,
        clip: {
          alpha: 1.0,
          flip: { horizontal: false, vertical: false },
          rotation: 0.0,
          scale: { x: 1.0, y: 1.0 },
          transform: { x: 0.0, y: 0.0 }
        },
        enable_adjust: true,
        enable_color_curves: true,
        enable_color_wheels: true,
        enable_lut: true,
        extra_material_refs: [speedId, canvasDefaultId],
        id: videoSegmentId,
        intensifies_audio: false,
        is_loop: false,
        is_placeholder: false,
        material_id: imgMaterialId,
        render_index: 0,
        responsive_layout: {
          enable: false,
          horizontal_pos_layout: 0,
          size_layout: 0,
          target_follow: "",
          vertical_pos_layout: 0
        },
        reverse: false,
        source: "segmentsourcenormal",
        source_timerange: {
          duration: psc.durUs,
          start: 0
        },
        speed: 1.0,
        state: 0,
        target_timerange: {
          duration: psc.durUs,
          start: psc.startUs
        },
        template_id: "",
        template_scene: "default",
        track_attribute: 0,
        track_render_index: 0,
        uniform_scale: { on: true, value: 1.0 },
        visible: true,
        volume: 1.0
      });

      if (psc.narrative && psc.narrative !== '-') {
        const textMatId = generateUuid();
        const textSegId = generateUuid();
        const contentPayload = {
          styles: [{
            fill: {
              alpha: 1.0,
              content: {
                render_type: "solid",
                solid: { alpha: 1.0, color: [1.0, 1.0, 1.0] }
              }
            },
            font: { id: "", path: fontPathSystem },
            range: [0, psc.narrative.length],
            size: 10.0
          }],
          text: psc.narrative
        };
        const strContent = JSON.stringify(contentPayload);

        materialsTexts.push({
          add_type: 1,
          alignment: 1,
          background_alpha: 1.0,
          background_color: "",
          base_content: strContent,
          check_flag: 7,
          content: strContent,
          font_size: 10.0,
          font_path: fontPathSystem,
          global_alpha: 1.0,
          id: textMatId,
          language: "id-ID",
          layer_weight: 1,
          line_feed: 1,
          name: "",
          sub_type: 0,
          text_alpha: 1.0,
          text_color: "#FFFFFF",
          type: "subtitle",
          typesetting: 0
        });

        textSegments.push({
          caption_info: null,
          clip: {
            alpha: 1.0,
            flip: { horizontal: false, vertical: false },
            rotation: 0.0,
            scale: { x: 1.0, y: 1.0 },
            transform: { x: 0.0, y: -0.56 }
          },
          extra_material_refs: [],
          id: textSegId,
          material_id: textMatId,
          render_index: 14000,
          source_timerange: null,
          speed: 1.0,
          state: 0,
          target_timerange: {
            duration: psc.durUs,
            start: psc.startUs
          },
          track_attribute: 0,
          track_render_index: 1,
          uniform_scale: { on: true, value: 1.0 },
          visible: true,
          volume: 1.0
        });
      }
    });

    // 4. Track Audio (Voiceover)
    const materialsAudios = [];
    const audioSegments = [];
    if (audioFileName) {
      const fullAudioPath = audioPathOverride
        ? audioPathOverride.replace(/\\/g, '/')
        : (draftFoldPath ? `${draftFoldPath.replace(/\\/g, '/')}/${audioFileName}` : audioFileName);

      materialsAudios.push({
        app_id: 0,
        category_id: "",
        category_name: "local",
        check_flag: 1,
        duration: effectiveTotalDurationUs,
        id: audioMaterialId,
        name: audioFileName,
        path: fullAudioPath,
        type: "extract_music"
      });

      audioSegments.push({
        caption_info: null,
        clip: null,
        extra_material_refs: [speedId],
        id: generateUuid(),
        material_id: audioMaterialId,
        render_index: 0,
        source_timerange: {
          duration: effectiveTotalDurationUs,
          start: 0
        },
        speed: 1.0,
        state: 0,
        target_timerange: {
          duration: effectiveTotalDurationUs,
          start: 0
        },
        track_attribute: 0,
        track_render_index: 2,
        visible: true,
        volume: 1.0
      });
    }

    const platformInfo = {
      app_id: 359289,
      app_source: "cc",
      app_version: "9.5.0",
      device_id: "c4ca4238a0b923820dcc509a6f75849b",
      hard_disk_id: "74738fb18971965367fbe11461aa03d8",
      mac_address: "0f607264fc6318a92b9e13c65db7cd3c",
      os: isMac ? "mac" : "windows",
      os_version: isMac ? "27.0.1" : "10.0.26200"
    };

    const tracks = [
      {
        attribute: 0,
        flag: 0,
        id: generateUuid(),
        is_default_name: true,
        name: "",
        segments: videoSegments,
        type: "video"
      },
      ...(textSegments.length > 0 ? [{
        attribute: 0,
        flag: 1,
        id: generateUuid(),
        is_default_name: true,
        name: "",
        segments: textSegments,
        type: "text"
      }] : []),
      ...(audioSegments.length > 0 ? [{
        attribute: 0,
        flag: 0,
        id: generateUuid(),
        is_default_name: true,
        name: "",
        segments: audioSegments,
        type: "audio"
      }] : [])
    ];

    return {
      canvas_config: {
        background: null,
        height: 1920,
        ratio: "original",
        width: 1080
      },
      color_space: -1,
      config: {
        adjust_max_index: 1,
        combination_max_index: 1,
        export_range: null,
        extract_audio_last_index: 1,
        hdr_vivid: false,
        lyrics_sync: true,
        maintrack_adsorb: true,
        material_save_mode: 0,
        multi_language_current: "none",
        original_sound_last_index: 1,
        record_audio_last_index: 1,
        sticker_max_index: 1,
        subtitle_sync: true,
        use_float_render: false,
        video_mute: false,
        voice_change_sync: false
      },
      cover: null,
      create_time: Math.floor(nowUs / 1000000),
      draft_type: "",
      duration: effectiveTotalDurationUs,
      extra_info: null,
      fps: 30.0,
      free_render_index_mode_on: false,
      group_container: null,
      id: projectUuid,
      is_drop_frame_timecode: false,
      keyframe_graph_list: [],
      keyframes: { adjusts: [], audios: [], effects: [], filters: [], handwrites: [], stickers: [], texts: [], videos: [] },
      last_modified_platform: platformInfo,
      materials: {
        ai_text_effects: [],
        ai_translates: [],
        audio_balances: [],
        audio_effects: [],
        audio_fades: [],
        audio_pannings: [],
        audio_pitch_shifts: [],
        audio_track_indexes: [],
        audios: materialsAudios,
        beats: [],
        canvases: [{
          album_image: "",
          blur: 0.0,
          color: "",
          id: canvasDefaultId,
          image: "",
          image_id: "",
          image_name: "",
          source_platform: 0,
          team_id: "",
          type: "canvas_color"
        }],
        chromas: [],
        color_curves: [],
        common_mask: [],
        digital_human_model_dressing: [],
        digital_humans: [],
        drafts: [],
        effects: [],
        flowers: [],
        green_screens: [],
        handwrites: [],
        hsl: [],
        hsl_curves: [],
        images: [],
        log_color_wheels: [],
        loudnesses: [],
        manual_beautys: [],
        manual_deformations: [],
        material_animations: [],
        material_colors: [],
        multi_language_refs: [],
        placeholder_infos: [],
        placeholders: [],
        plugin_effects: [],
        primary_color_wheels: [],
        realtime_denoises: [],
        shapes: [],
        smart_crops: [],
        smart_relights: [],
        sound_channel_mappings: [],
        speeds: [{ curve_speed: null, id: speedId, mode: 0, speed: 1.0, type: "speed" }],
        stickers: [],
        tail_leaders: [],
        text_templates: [],
        texts: materialsTexts,
        time_marks: [],
        transitions: [],
        video_effects: [],
        video_radius: [],
        video_shadows: [],
        video_strokes: [],
        video_trackings: [],
        videos: materialsVideos,
        vocal_beautifys: [],
        vocal_separations: []
      },
      mixed_track_mode_on: false,
      mutable_config: null,
      name: projectName,
      new_version: "187.0.0",
      path: draftFoldPath,
      platform: platformInfo,
      relationships: [],
      render_index_track_mode_on: false,
      retouch_cover: null,
      smart_ads_info: null,
      source: "default",
      static_cover_image_path: "",
      time_marks: null,
      tracks: tracks,
      uneven_animation_template_info: null,
      update_time: Math.floor(nowUs / 1000000),
      version: 360000
    };
  }

  /**
   * Menulis struktur proyek CapCut lengkap ke FileSystemDirectoryHandle.
   * @param {FileSystemDirectoryHandle} rootDirHandle - Handle folder com.lveditor.draft
   * @param {Object} projectData - Data proyek { title, scenes, totalDurationUs }
   * @param {File|Blob} [audioFileOrBlob] - Berkas audio untuk disimpan ke folder proyek
   * @param {Blob} [coverBlob] - Gambar thumbnail cover
   * @returns {Promise<{success: boolean, projectDirName: string}>}
   */
  async function writeCapCutDraft(rootDirHandle, projectData, audioFileOrBlob, coverBlob, options = {}) {
    if (!rootDirHandle) throw new Error("Direktori draf CapCut belum terhubung.");
    if (!projectData || !Array.isArray(projectData.scenes)) throw new Error("Data proyek tidak valid.");

    const rawTitle = (projectData.projectFolder || projectData.title || 'Proyek_ShortMovie').trim().replace(/[^a-zA-Z0-9_\-\u0600-\u06FF\s]/g, '');
    const projectName = projectData.projectFolder || (rawTitle.replace(/\s+/g, '_') || 'Proyek_CapCut');

    let effectiveDirHandle = rootDirHandle;
    try {
      const sub = await rootDirHandle.getDirectoryHandle('com.lveditor.draft', { create: false });
      if (sub) effectiveDirHandle = sub;
    } catch (_) {}

    // Resolusi effectiveRootPath (Path Absolut Direktori Induk CapCut Drafts)
    let effectiveRootPath = options.rootPath || '';
    if (!effectiveRootPath) {
      try {
        const rootMetaHandle = await effectiveDirHandle.getFileHandle('root_meta_info.json', { create: false });
        const file = await rootMetaHandle.getFile();
        const existingRoot = JSON.parse(await file.text());
        if (existingRoot.root_path && typeof existingRoot.root_path === 'string') {
          effectiveRootPath = existingRoot.root_path;
        } else if (Array.isArray(existingRoot.all_draft_store) && existingRoot.all_draft_store.length > 0) {
          for (const d of existingRoot.all_draft_store) {
            if (d.draft_root_path) { effectiveRootPath = d.draft_root_path; break; }
            if (d.draft_fold_path && (d.draft_fold_path.includes('/') || d.draft_fold_path.includes('\\'))) {
              const norm = d.draft_fold_path.replace(/\\/g, '/');
              const idx = norm.lastIndexOf('/');
              if (idx > 0) { effectiveRootPath = norm.substring(0, idx); break; }
            }
          }
        }
      } catch (_) {}
    }

    // Fallback jika belum terdeteksi dari root_meta_info.json
    if (!effectiveRootPath) {
      const isWin = typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.includes('Win');
      effectiveRootPath = isWin
        ? 'C:/Users/ripal/Downloads/intisariShortMovie/CapCut Drafts'
        : `${rootDirHandle.name || 'CapCut Drafts'}`;
    }

    const normRootPath = effectiveRootPath.replace(/\\/g, '/');
    const draftFoldPath = `${normRootPath}/${projectName}`;
    const draftJsonFilePath = `${draftFoldPath}/draft_content.json`;
    const draftCoverFilePath = `${draftFoldPath}/draft_cover.jpg`;

    // Folder media gambar (Downloads/intisariShortMovie/[projectName])
    let imageFolderPath = options.imageFolderPath || '';
    if (!imageFolderPath) {
      const intisariBase = normRootPath.replace(/\/CapCut Drafts$/i, '');
      imageFolderPath = `${intisariBase}/${projectName}`;
    }

    // 1. Buat folder proyek draf di dalam effectiveDirHandle
    const projectSubDir = await effectiveDirHandle.getDirectoryHandle(projectName, { create: true });

    // Dukung penulisan berkas gambar adegan mandiri langsung ke folder draf (Self-Contained v2.7.0)
    if (options.imageFiles && Array.isArray(options.imageFiles)) {
      for (const imgItem of options.imageFiles) {
        if (imgItem && imgItem.name && (imgItem.file || imgItem.blob)) {
          await writeFileToDir(projectSubDir, imgItem.name, imgItem.file || imgItem.blob);
        }
      }
      if (options.imageFolderPath === 'DRAFT_DIR') {
        imageFolderPath = draftFoldPath;
      }
    }

    // 2. Simpan berkas audio jika ada, atau gunakan fallback dari folder proyek intisariShortMovie (v2.6.3)
    let audioFileName = options.audioFileName || projectData.audioFileName || '';
    let audioPathOverride = options.audioPath || '';
    if (audioFileOrBlob) {
      audioFileName = audioFileOrBlob.name || audioFileName || `${projectName}.mp3`;
      await writeFileToDir(projectSubDir, audioFileName, audioFileOrBlob);
    } else if (audioFileName && imageFolderPath) {
      audioPathOverride = `${imageFolderPath.replace(/\\/g, '/')}/${audioFileName}`;
    }

    // 3. Simpan thumbnail draft_cover.jpg jika ada / fallback canvas cover
    if (coverBlob) {
      await writeFileToDir(projectSubDir, 'draft_cover.jpg', coverBlob);
    } else {
      const defaultCover = await createDefaultCoverBlob();
      if (defaultCover) {
        await writeFileToDir(projectSubDir, 'draft_cover.jpg', defaultCover);
      }
    }

    // 4. Bersihkan berkas cache upgrade korup jika folder draf sudah pernah dibuka sebelumnya
    for (const staleEntry of ['Timelines', 'draft.extra', 'draft_content.json.bak', 'template-2.tmp', 'attachment_pc_common.json', 'draft_virtual_store.json']) {
      try {
        await projectSubDir.removeEntry(staleEntry, { recursive: true });
      } catch (_) {}
    }

    // 5. Buat dan tulis draft_info.json serta draft_content.json (Dual Contract)
    const draftInfo = buildDraftInfoJson(projectName, projectData.scenes, audioFileName, projectData.totalDurationUs, imageFolderPath, draftFoldPath, audioPathOverride);
    const finalDurationUs = draftInfo.duration || projectData.totalDurationUs || 14000000;
    const draftJsonPayload = JSON.stringify(draftInfo, null, 2);
    await writeFileToDir(projectSubDir, 'draft_info.json', draftJsonPayload);
    await writeFileToDir(projectSubDir, 'draft_content.json', draftJsonPayload);

    const nowUs = Date.now() * 1000;
    const draftId = draftInfo.id || generateUuid();

    // 6. Buat dan tulis draft_meta_info.json (Skema Lokal Murni Sesuai Standar CapCut Global Desktop v9.5.0)
    const draftMeta = {
      cloud_draft_cover: false,
      cloud_draft_sync: false,
      draft_cover: "draft_cover.jpg",
      draft_enterprise_info: null,
      draft_fold_path: draftFoldPath,
      draft_id: draftId,
      draft_is_from_deeplink: "false",
      draft_materials: [],
      draft_materials_copied_info: [],
      draft_name: projectName,
      draft_need_rename_folder: false,
      draft_new_version: "187.0.0",
      draft_root_path: effectiveRootPath,
      draft_timeline_materials_size_: 8287202,
      tm_draft_cloud_entry_id: -1,
      tm_draft_cloud_parent_entry_id: -1,
      tm_draft_cloud_space_id: -1,
      tm_draft_cloud_user_id: -1,
      tm_draft_create: nowUs,
      tm_draft_modified: nowUs,
      tm_duration: finalDurationUs
    };
    await writeFileToDir(projectSubDir, 'draft_meta_info.json', JSON.stringify(draftMeta, null, 2));

    // 7. Buat berkas subtitles.srt
    if (global.StoryboardAligner) {
      const srtContent = global.StoryboardAligner.generateSrtText(projectData.scenes, projectData.coverOffset || 0.0);
      await writeFileToDir(projectSubDir, 'subtitles.srt', srtContent);
    }

    // 8. Simpan draft_settings
    const isMac = typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.includes('Mac');
    const settingsContent = `[General]\ncloud_last_modify_platform=${isMac ? 'mac' : 'win'}\ndraft_create_time=${Math.floor(nowUs / 1000000)}\ndraft_last_edit_time=${Math.floor(nowUs / 1000000)}\nreal_edit_keys=1\nreal_edit_seconds=60\n`;
    await writeFileToDir(projectSubDir, 'draft_settings', settingsContent);

    // 9. Update root_meta_info.json di direktori com.lveditor.draft
    try {
      let rootMeta = { all_draft_store: [] };
      try {
        const rootMetaHandle = await effectiveDirHandle.getFileHandle('root_meta_info.json', { create: false });
        const file = await rootMetaHandle.getFile();
        const text = await file.text();
        rootMeta = JSON.parse(text);
      } catch (_) {
        // File belum ada, inisialisasi baru
      }

      if (!Array.isArray(rootMeta.all_draft_store)) rootMeta.all_draft_store = [];
      if (typeof rootMeta.draft_ids !== 'number') rootMeta.draft_ids = rootMeta.all_draft_store.length;
      rootMeta.root_path = effectiveRootPath;

      // Self-Healing entri draf warisan yang masih berformat relatif (SRS-FAB-061)
      for (const d of rootMeta.all_draft_store) {
        if (d && d.draft_fold_path && !d.draft_fold_path.includes(':') && !d.draft_fold_path.startsWith('/')) {
          const oldName = d.draft_name || d.draft_fold_path;
          d.draft_fold_path = `${normRootPath}/${oldName}`;
          if (!d.draft_json_file) d.draft_json_file = `${normRootPath}/${oldName}/draft_content.json`;
          if (!d.draft_cover) d.draft_cover = `${normRootPath}/${oldName}/draft_cover.jpg`;
          if (!d.draft_root_path) d.draft_root_path = effectiveRootPath;
          d.streaming_edit_draft_ready = true;
          d.tm_draft_cloud_entry_id = -1;
        }
      }

      // Periksa apakah entri draft sudah ada
      const existingIdx = rootMeta.all_draft_store.findIndex(d => 
        d.draft_fold_path === draftFoldPath || 
        d.draft_fold_path === projectName ||
        d.draft_name === projectName
      );

      const rootEntry = {
        cloud_draft_cover: false, cloud_draft_sync: false, draft_cloud_last_action_download: false,
        draft_cloud_purchase_info: "", draft_cloud_template_id: "", draft_cloud_tutorial_info: "", draft_cloud_videocut_purchase_info: "",
        draft_cover: draftCoverFilePath, draft_fold_path: draftFoldPath, draft_id: draftId,
        draft_is_ai_shorts: false, draft_is_cloud_temp_draft: false, draft_is_infinite_canvas_draft: false,
        draft_is_invisible: false, draft_is_pippit_draft: false, draft_is_web_article_video: false,
        draft_json_file: draftJsonFilePath, draft_name: projectName, draft_new_version: "187.0.0",
        draft_root_path: effectiveRootPath, draft_timeline_materials_size: 8287202,
        draft_type: "", draft_web_article_video_enter_from: "",
        pippit_avatar_url: "", pippit_extra_info: "", pippit_id: "", pippit_user_name: "",
        streaming_edit_draft_ready: true, tm_draft_cloud_completed: "",
        tm_draft_cloud_entry_id: -1, tm_draft_cloud_modified: 0, tm_draft_cloud_parent_entry_id: -1,
        tm_draft_cloud_space_id: -1, tm_draft_cloud_user_id: -1,
        tm_draft_create: nowUs, tm_draft_modified: nowUs, tm_draft_removed: 0, tm_duration: finalDurationUs
      };

      if (existingIdx >= 0) {
        rootMeta.all_draft_store[existingIdx] = rootEntry;
      } else {
        rootMeta.all_draft_store.unshift(rootEntry); // Masukkan paling atas
        rootMeta.draft_ids += 1;
      }

      await writeFileToDir(effectiveDirHandle, 'root_meta_info.json', JSON.stringify(rootMeta, null, 2));
    } catch (e) {
      console.warn("Gagal memperbarui root_meta_info.json (opsional):", e);
    }

    return {
      success: true,
      projectName,
      projectSubDir,
      draftFoldPath,
      draftJsonFilePath
    };
  }

  // Registrasi global
  global.CapCutDraftWriter = {
    pairCapCutDirectory,
    getStoredDirectoryHandle,
    clearStoredDirectoryHandle,
    queryDirectoryPermission,
    verifyPermission,
    writeCapCutDraft,
    buildDraftInfoJson,
    isFileSystemAccessSupported: () => !!(global.showDirectoryPicker)
  };

})(typeof window !== 'undefined' ? window : globalThis);

