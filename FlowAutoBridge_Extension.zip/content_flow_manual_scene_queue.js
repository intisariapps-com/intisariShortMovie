// Antrean FIFO untuk generate adegan manual pada satu tab Flow.
(function (global) {
  'use strict';

  const QUEUE_KEY = 'manualSceneGenerationQueue';
  const isTopFrame = global === global.top;
  let tabId = isTopFrame ? Number(sessionStorage.getItem('fab_manual_scene_queue_tab_id') || 0) : 0;
  let stopped = false;
  let pumping = false;
  let mutationChain = Promise.resolve();

  const get = keys => new Promise(resolve => chrome.storage.local.get(keys, resolve));
  const set = values => new Promise(resolve => chrome.storage.local.set(values, resolve));

  function mutate(mutator) {
    const operation = mutationChain.then(async () => {
      const stored = await get([QUEUE_KEY]);
      const jobs = Array.isArray(stored[QUEUE_KEY]) ? stored[QUEUE_KEY] : [];
      const result = await mutator(jobs);
      await set({ [QUEUE_KEY]: jobs });
      return result;
    });
    mutationChain = operation.catch(() => {});
    return operation;
  }

  async function pump() {
    if (!isTopFrame || stopped || pumping) return;
    pumping = true;
    try {
      const state = await get([QUEUE_KEY, 'automationRunning', 'flowExecutionState', 'renderedSceneUrls']);
      const jobs = Array.isArray(state[QUEUE_KEY]) ? state[QUEUE_KEY] : [];
      const flowStatus = state.flowExecutionState?.status;
      if (jobs.some(job => job.status === 'needs_review')) return;

      const active = jobs.find(job => ['sending', 'rendering'].includes(job.status));
      if (active && !state.automationRunning && !['running', 'paused', 'starting'].includes(flowStatus)) {
        const currentUrl = state.renderedSceneUrls?.[active.sceneId] || '';
        const completed = Boolean(currentUrl && currentUrl !== (active.previousRenderedUrl || ''));
        await mutate(currentJobs => {
          const current = currentJobs.find(job => job.jobId === active.jobId);
          if (!current || !['sending', 'rendering'].includes(current.status)) return;
          current.status = completed ? 'completed' : 'failed';
          current.finishedAt = Date.now();
          current.error = completed ? '' : (state.flowExecutionState?.text || 'Render tidak menghasilkan gambar tersimpan.');
          const terminal = currentJobs.filter(job => ['completed', 'failed', 'cancelled'].includes(job.status));
          if (terminal.length > 40) {
            const removeIds = new Set(terminal.slice(0, terminal.length - 40).map(job => job.jobId));
            for (let i = currentJobs.length - 1; i >= 0; i--) {
              if (removeIds.has(currentJobs[i].jobId)) currentJobs.splice(i, 1);
            }
          }
        });
      }

      const refreshed = await get([QUEUE_KEY, 'automationRunning', 'flowExecutionState', 'renderedSceneUrls']);
      const currentJobs = Array.isArray(refreshed[QUEUE_KEY]) ? refreshed[QUEUE_KEY] : [];
      const busy = refreshed.automationRunning || ['running', 'paused', 'starting'].includes(refreshed.flowExecutionState?.status);
      if (busy || currentJobs.some(job => ['sending', 'rendering'].includes(job.status))) return;

      const next = currentJobs.find(job => job.status === 'queued');
      if (!next || next.flowTabId !== tabId) return;
      const jobId = next.jobId;
      await mutate(latestJobs => {
        const latest = latestJobs.find(job => job.jobId === jobId);
        if (!latest || latest.status !== 'queued') return;
        latest.status = 'sending';
        latest.startedAt = Date.now();
        latest.previousRenderedUrl = refreshed.renderedSceneUrls?.[latest.sceneId] || '';
      });

      const sending = (await get([QUEUE_KEY]))[QUEUE_KEY].find(job => job.jobId === jobId);
      if (!sending || sending.status !== 'sending') return;
      const pipeline = global.FlowSlidingWindowPipeline;
      const result = pipeline && typeof pipeline.sendSingleScene === 'function'
        ? await pipeline.sendSingleScene(sending.sceneId, sending.sceneIndex, sending.prompt, sending.aspectRatio)
        : { success: false, error: 'Validator render Flow belum siap. Muat ulang tab Google Flow.' };

      if (result?.success) {
        await mutate(latestJobs => {
          const latest = latestJobs.find(job => job.jobId === jobId);
          if (latest && latest.status === 'sending') latest.status = 'rendering';
        });
        setTimeout(pump, 500);
      } else {
        await mutate(latestJobs => {
          const latest = latestJobs.find(job => job.jobId === jobId);
          if (!latest) return;
          latest.status = 'failed';
          latest.finishedAt = Date.now();
          latest.error = result?.error || 'Gagal mengirim prompt ke Flow.';
        });
        setTimeout(pump, 0);
      }
    } catch (error) {
      console.warn('[FlowAutoBridge] Antrean generate ulang gagal diproses:', error);
    } finally {
      pumping = false;
    }
  }

  function enqueue(payload, senderTabId) {
    if (typeof senderTabId === 'number') {
      tabId = senderTabId;
      sessionStorage.setItem('fab_manual_scene_queue_tab_id', String(tabId));
    }
    const sceneIndex = typeof payload.sceneIndex === 'number' ? payload.sceneIndex : 0;
    const sceneId = payload.sceneId || `ADEGAN_${String(sceneIndex + 1).padStart(2, '0')}`;
    const prompt = String(payload.prompt || '').trim();
    const aspectRatio = payload.aspectRatio || (prompt.includes('16:9') ? '16:9' : '9:16');
    if (!prompt) return Promise.resolve({ success: false, error: 'Prompt adegan kosong.' });
    stopped = false;

    return mutate(jobs => {
      jobs.forEach(job => {
        if (job.flowTabId === tabId && job.sceneId === sceneId && job.status === 'needs_review') {
          job.status = 'failed';
          job.error = 'Ditandai untuk retry manual oleh pengguna.';
          job.finishedAt = Date.now();
        }
      });
      const existing = jobs.find(job => job.flowTabId === tabId && job.sceneId === sceneId && job.prompt === prompt && ['queued', 'sending', 'rendering'].includes(job.status));
      if (existing) {
        const position = jobs.filter(job => ['queued', 'sending', 'rendering'].includes(job.status)).indexOf(existing) + 1;
        return { success: true, queued: true, position, duplicate: true };
      }
      const job = {
        jobId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        sceneId, sceneIndex, prompt, aspectRatio, flowTabId: tabId, status: 'queued', createdAt: Date.now()
      };
      jobs.push(job);
      const position = jobs.filter(item => ['queued', 'sending', 'rendering'].includes(item.status)).indexOf(job) + 1;
      setTimeout(pump, 150);
      return { success: true, queued: true, position };
    });
  }

  function stop() {
    stopped = true;
    return mutate(jobs => {
      jobs.forEach(job => {
        if (job.flowTabId === tabId && ['queued', 'sending', 'rendering'].includes(job.status)) {
          job.status = 'cancelled';
          job.error = 'Dihentikan oleh pengguna.';
          job.finishedAt = Date.now();
        }
      });
    });
  }

  async function recoverOnPageLoad() {
    const state = await get([QUEUE_KEY]);
    const jobs = Array.isArray(state[QUEUE_KEY]) ? state[QUEUE_KEY] : [];
    const active = jobs.find(job => job.flowTabId === tabId && ['sending', 'rendering'].includes(job.status));
    if (!active) return false;
    await mutate(currentJobs => {
      const current = currentJobs.find(job => job.jobId === active.jobId);
      if (current) {
        current.status = 'needs_review';
        current.error = 'Tab Flow dimuat ulang saat render berjalan; klik Generate ulang untuk mencoba lagi dengan aman.';
        current.finishedAt = Date.now();
      }
    });
    await set({
      automationRunning: false,
      currentProcessingSceneId: null,
      flowExecutionState: { status: 'error', mode: 'local', text: `Periksa hasil ${active.sceneId}; tab dimuat ulang saat render berlangsung.` }
    });
    return true;
  }

  if (isTopFrame) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes[QUEUE_KEY] || changes.automationRunning || changes.flowExecutionState || changes.renderedSceneUrls)) {
        setTimeout(pump, 250);
      }
    });
  }

  global.FlowManualSceneQueue = { enqueue, pump, stop, recoverOnPageLoad };
})(window);
