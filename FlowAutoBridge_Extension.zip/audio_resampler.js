// ==============================================================================
// 📁 FILE   : extension/audio_resampler.js
// 📝 FUNGSI : Web Audio API Native Resampler (Zero-Python In-Browser Audio Engine)
//             Mengonversi audio (WAV/MP3/M4A) menjadi 16kHz 16-bit Mono WAV.
// ==============================================================================

(function(global) {
  'use strict';

  /**
   * Mengonversi Float32Array PCM (-1.0 s/d 1.0) menjadi 16-bit signed integer PCM.
   */
  function floatTo16BitPCM(output, offset, input) {
    for (let i = 0; i < input.length; i++, offset += 2) {
      let s = Math.max(-1, Math.min(1, input[i]));
      output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
  }

  /**
   * Menulis string ASCII ke DataView.
   */
  function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  /**
   * Membungkus AudioBuffer 1-channel 16kHz menjadi Blob berkas WAV standar (RIFF 44-byte header).
   * @param {AudioBuffer} audioBuffer
   * @returns {Blob}
   */
  function bufferToWavBlob(audioBuffer) {
    const numChannels = 1; // Mono
    const sampleRate = audioBuffer.sampleRate;
    const format = 1; // Linear PCM
    const bitDepth = 16;
    const channelData = audioBuffer.getChannelData(0);
    const dataByteLength = channelData.length * 2; // 2 bytes per sample (16-bit)
    const headerByteLength = 44;
    const totalByteLength = headerByteLength + dataByteLength;

    const buffer = new ArrayBuffer(totalByteLength);
    const view = new DataView(buffer);

    // RIFF identifier 'RIFF'
    writeString(view, 0, 'RIFF');
    // File length minus RIFF identifier & length field
    view.setUint32(4, 36 + dataByteLength, true);
    // RIFF type 'WAVE'
    writeString(view, 8, 'WAVE');
    // Format chunk identifier 'fmt '
    writeString(view, 12, 'fmt ');
    // Format chunk length (16 bytes for PCM)
    view.setUint32(16, 16, true);
    // Sample format (1 = PCM)
    view.setUint16(20, format, true);
    // Channel count
    view.setUint16(22, numChannels, true);
    // Sample rate
    view.setUint32(24, sampleRate, true);
    // Byte rate (SampleRate * NumChannels * BitsPerSample / 8)
    view.setUint32(28, sampleRate * numChannels * (bitDepth / 8), true);
    // Block align (NumChannels * BitsPerSample / 8)
    view.setUint16(32, numChannels * (bitDepth / 8), true);
    // Bits per sample
    view.setUint16(34, bitDepth, true);
    // Data chunk identifier 'data'
    writeString(view, 36, 'data');
    // Data chunk length
    view.setUint32(40, dataByteLength, true);

    // Write samples
    floatTo16BitPCM(view, 44, channelData);

    return new Blob([view], { type: 'audio/wav' });
  }

  /**
   * Meresample berkas audio apa pun (WAV/MP3/FLAC/AAC) menjadi 16kHz 16-bit Mono WAV.
   * Sangat hemat memori dan cepat (< 100ms untuk audio 2 menit).
   * @param {File|Blob} audioFile
   * @returns {Promise<{blob: Blob, duration: number, sampleRate: number}>}
   */
  async function resampleAudioTo16kMono(audioFile) {
    const AudioContextClass = global.AudioContext || global.webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error('Web Audio API tidak didukung di peramban ini.');
    }

    const audioCtx = new AudioContextClass();
    try {
      const arrayBuffer = await audioFile.arrayBuffer();
      const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer);

      const targetSampleRate = 16000;
      const totalSamples = Math.ceil(decodedBuffer.duration * targetSampleRate);

      // Gunakan OfflineAudioContext untuk rendering background super cepat tanpa playback
      const OfflineCtxClass = global.OfflineAudioContext || global.webkitOfflineAudioContext;
      const offlineCtx = new OfflineCtxClass(1, totalSamples, targetSampleRate);

      const source = offlineCtx.createBufferSource();
      source.buffer = decodedBuffer;
      source.connect(offlineCtx.destination);
      source.start(0);

      const renderedBuffer = await offlineCtx.startRendering();
      const wavBlob = bufferToWavBlob(renderedBuffer);

      return {
        blob: wavBlob,
        duration: decodedBuffer.duration,
        sampleRate: targetSampleRate
      };
    } finally {
      if (audioCtx.state !== 'closed') {
        try {
          await audioCtx.close();
        } catch (_) {}
      }
    }
  }

  /**
   * Helper untuk memeriksa apakah berkas adalah audio yang didukung.
   */
  function isAudioFile(file) {
    if (!file) return false;
    const name = (file.name || '').toLowerCase();
    const type = (file.type || '').toLowerCase();
    return (
      type.startsWith('audio/') ||
      name.endsWith('.mp3') ||
      name.endsWith('.wav') ||
      name.endsWith('.m4a') ||
      name.endsWith('.aac') ||
      name.endsWith('.ogg') ||
      name.endsWith('.flac')
    );
  }

  /**
   * Format detik float ke menit:detik ramah pengguna.
   */
  function formatDuration(seconds) {
    if (typeof seconds !== 'number' || isNaN(seconds) || seconds < 0) return '00:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  // Registrasi ke global window
  global.AudioResampler = {
    resampleAudioTo16kMono,
    bufferToWavBlob,
    isAudioFile,
    formatDuration
  };

})(typeof window !== 'undefined' ? window : globalThis);

