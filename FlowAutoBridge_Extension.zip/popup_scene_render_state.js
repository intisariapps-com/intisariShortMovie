/**
 * popup_scene_render_state.js (SRS-111 / FR-01, FR-02, FR-03, FR-05)
 * Adapter Status & In-Place DOM Patcher Kartu Linimasa Popup FlowAutoBridge.
 * Penyelarasan UI/UX identik dengan status Aplikasi Desktop (StoryboardSceneCard.js).
 */
(function() {
  'use strict';

  let activeTimerInterval = null;

  function getChromeStorage() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
    return null;
  }

  /**
   * Menentukan status tampilan kartu adegan berdasarkan prioritas data.
   * @param {Object} scene Objek adegan
   * @param {number} sceneIndex Indeks adegan
   * @param {Object} statesMap Peta sceneRenderStates dari storage
   * @param {Object} renderedUrlsMap Peta renderedSceneUrls dari storage
   */
  function deriveSceneState(scene, sceneIndex, statesMap = {}, renderedUrlsMap = {}) {
    if (!scene) {
      return { state: 'pending', label: 'kosong', badgeClass: 'badge-offline', color: 'slate' };
    }

    const sceneId = String(scene.id || '').trim();
    const cleanId = sceneId || (sceneIndex === 0 ? 'COVER' : `ADEGAN_${String(sceneIndex).padStart(2, '0')}`);

    // Prioritas 1: Gambar sudah selesai tersimpan
    const hasImage = Boolean(scene.imageUrl || (renderedUrlsMap && (renderedUrlsMap[cleanId] || renderedUrlsMap[sceneId])));
    if (hasImage) {
      return {
        state: 'done',
        label: '✓ siap',
        badgeClass: 'badge-done',
        color: 'emerald',
        hasImage: true
      };
    }

    // Prioritas 2: Data dari sceneRenderStates
    const st = statesMap ? (statesMap[cleanId] || statesMap[sceneId]) : null;
    if (st && st.state) {
      const s = st.state;
      const pos = st.pos || (sceneIndex + 1);

      if (s === 'queued') {
        return {
          state: 'queued',
          label: `Antrean #${pos}`,
          badgeClass: 'badge-queued',
          color: 'amber',
          pos: pos
        };
      }

      if (s === 'submitting') {
        return {
          state: 'submitting',
          label: 'Menyiapkan...',
          badgeClass: 'badge-submitting',
          color: 'purple'
        };
      }

      if (s === 'rendering') {
        const since = st.since || Date.now();
        const elapsedSec = Math.max(0, Math.floor((Date.now() - since) / 1000));
        const mins = Math.floor(elapsedSec / 60);
        const secs = elapsedSec % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const isSlow = elapsedSec > 180;
        return {
          state: 'rendering',
          label: isSlow ? `Sedang Dibuat (Lambat ${timeStr})` : `Sedang Dibuat di Flow (${timeStr})`,
          badgeClass: 'badge-rendering',
          color: 'indigo',
          elapsedSec: elapsedSec,
          isSlow: isSlow,
          since: since
        };
      }

      if (s === 'held') {
        return {
          state: 'held',
          label: 'Tertahan',
          badgeClass: 'badge-held',
          color: 'amber',
          reason: st.reason || 'Submit tertahan'
        };
      }

      if (s === 'failed') {
        return {
          state: 'failed',
          label: '⚠️ butuh revisi',
          badgeClass: 'badge-failed',
          color: 'rose',
          reason: st.reason || 'Gagal generate'
        };
      }
    }

    // Prioritas 3: Default fallback
    return {
      state: 'pending',
      label: 'kosong',
      badgeClass: 'badge-offline',
      color: 'slate'
    };
  }

  /**
   * Menghasilkan elemen HTML string untuk Pill Status.
   */
  function renderScenePillHtml(derivedState) {
    const isSpinner = derivedState.state === 'rendering' || derivedState.state === 'submitting';
    const isClock = derivedState.state === 'queued';
    const isCheck = derivedState.state === 'done';
    const isWarn = derivedState.state === 'failed' || derivedState.state === 'held';

    // Bersihkan karakter simbol duplikat di awal label agar tidak ganda
    const cleanLabel = String(derivedState.label || '').replace(/^[✓⚠️⏳🔄•]\s*/, '');

    let iconHtml = '';
    if (isSpinner) {
      iconHtml = '<span class="pill-spin-icon">🔄</span> ';
    } else if (isClock) {
      iconHtml = '<span class="pill-clock-icon">⏳</span> ';
    } else if (isCheck) {
      iconHtml = '<span class="pill-check-icon">✓</span> ';
    } else if (isWarn) {
      iconHtml = '<span class="pill-warn-icon">⚠️</span> ';
    }

    const titleAttr = derivedState.reason ? ` title="${derivedState.reason}"` : '';
    return `<span class="scene-state-pill ${derivedState.badgeClass}"${titleAttr} data-state="${derivedState.state}">${iconHtml}<span class="pill-text">${cleanLabel}</span></span>`;
  }

  /**
   * Melakukan in-place patching DOM pada elemen kartu linimasa tanpa merusak innerHTML.
   * @param {HTMLElement} containerEl Kontainer linimasa
   * @param {Array<Object>} scenes Daftar adegan
   * @param {Object} statesMap Peta sceneRenderStates
   * @param {Object} renderedUrlsMap Peta renderedSceneUrls
   */
  function patchTimelineSceneCards(containerEl, scenes, statesMap = {}, renderedUrlsMap = {}) {
    if (!containerEl || !Array.isArray(scenes) || scenes.length === 0) return;

    scenes.forEach((sc, idx) => {
      if (!sc) return;
      const cleanId = String(sc.id || (idx === 0 ? 'COVER' : `ADEGAN_${String(idx).padStart(2, '0')}`)).trim();
      const cardEl = containerEl.querySelector(`.scene-card[data-scene-id="${cleanId}"]`);
      if (!cardEl) return;

      const derived = deriveSceneState(sc, idx, statesMap, renderedUrlsMap);

      // 1. Perbarui class status pada card
      const currentStatusClass = Array.from(cardEl.classList).find(c => c.startsWith('scene-status-'));
      const targetStatusClass = `scene-status-${derived.state}`;
      if (currentStatusClass !== targetStatusClass) {
        if (currentStatusClass) cardEl.classList.remove(currentStatusClass);
        cardEl.classList.add(targetStatusClass);
      }

      // 2. Perbarui slot pill status
      let pillSlot = cardEl.querySelector('.scene-state-pill-slot');
      if (!pillSlot) {
        const statusRow = cardEl.querySelector('.scene-status-row') || cardEl.querySelector('.scene-header-line');
        if (statusRow) {
          pillSlot = document.createElement('div');
          pillSlot.className = 'scene-state-pill-slot';
          statusRow.insertBefore(pillSlot, statusRow.firstChild);
        }
      }

      if (pillSlot) {
        const existingPill = pillSlot.querySelector('.scene-state-pill');
        const newHtml = renderScenePillHtml(derived);
        if (!existingPill || existingPill.getAttribute('data-state') !== derived.state || existingPill.textContent !== derived.label) {
          pillSlot.innerHTML = newHtml;
        }
      }

      // 3. Perbarui overlay visual thumbnail
      const thumbBox = cardEl.querySelector('.scene-thumb-box');
      if (thumbBox) {
        let skeletonEl = thumbBox.querySelector('.scene-skeleton-loading');

        if (derived.state === 'queued' || derived.state === 'submitting' || derived.state === 'rendering') {
          if (!skeletonEl && !derived.hasImage) {
            skeletonEl = document.createElement('div');
            skeletonEl.className = 'scene-skeleton-loading';
            thumbBox.appendChild(skeletonEl);
          }
          if (skeletonEl) {
            skeletonEl.style.display = 'flex';
            skeletonEl.setAttribute('data-state', derived.state);
            skeletonEl.innerHTML = `
              <div class="skeleton-content">
                <span class="skeleton-icon">${derived.state === 'queued' ? '⏳' : '🎨'}</span>
                <span class="skeleton-label">${derived.state === 'queued' ? `Antrean #${derived.pos || (idx+1)}` : 'Sedang dibuat...'}</span>
              </div>
            `;
          }
        } else if (skeletonEl) {
          skeletonEl.style.display = 'none';
        }
      }
    });

    startLiveTimerUpdater(containerEl, scenes, statesMap);
  }

  /**
   * Menjalankan updater live timer setiap 1 detik untuk kartu dengan status 'rendering'.
   */
  function startLiveTimerUpdater(containerEl, scenes, statesMap) {
    if (activeTimerInterval) clearInterval(activeTimerInterval);

    activeTimerInterval = setInterval(() => {
      if (!containerEl || !document.body.contains(containerEl)) {
        clearInterval(activeTimerInterval);
        activeTimerInterval = null;
        return;
      }

      const renderingCards = containerEl.querySelectorAll('.scene-card.scene-status-rendering');
      if (renderingCards.length === 0) return;

      renderingCards.forEach(card => {
        const scId = card.getAttribute('data-scene-id');
        const st = statesMap ? statesMap[scId] : null;
        if (!st || !st.since) return;

        const elapsedSec = Math.max(0, Math.floor((Date.now() - st.since) / 1000));
        const mins = Math.floor(elapsedSec / 60);
        const secs = elapsedSec % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const isSlow = elapsedSec > 180;
        const labelText = isSlow ? `Sedang Dibuat (Lambat ${timeStr})` : `Sedang Dibuat di Flow (${timeStr})`;

        const textNode = card.querySelector('.scene-state-pill .pill-text');
        if (textNode && textNode.textContent !== labelText) {
          textNode.textContent = labelText;
        }
      });
    }, 1000);
  }

  /**
   * Inisialisasi pendengar otomatis ke chrome.storage.onChanged.
   */
  function initAutoStorageSync(containerGetter, scenesGetter) {
    const storage = getChromeStorage();
    if (!storage || typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.onChanged) return;

    chrome.storage.onChanged.addListener((changes) => {
      if (changes.sceneRenderStates || changes.renderedSceneUrls) {
        const container = typeof containerGetter === 'function' ? containerGetter() : null;
        const scenes = typeof scenesGetter === 'function' ? scenesGetter() : null;
        if (!container || !scenes) return;

        storage.get(['sceneRenderStates', 'renderedSceneUrls'], (res) => {
          patchTimelineSceneCards(container, scenes, res.sceneRenderStates || {}, res.renderedSceneUrls || {});
        });
      }
    });
  }

  const api = {
    deriveSceneState,
    renderScenePillHtml,
    patchTimelineSceneCards,
    initAutoStorageSync
  };

  if (typeof window !== 'undefined') {
    window.PopupSceneRenderState = api;
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
