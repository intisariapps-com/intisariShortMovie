// ==============================================================================
// 📁 FILE   : popup.js (Lokasi: extension/popup.js)
// 📝 FUNGSI : Pusat kendali terpadu FlowAutoBridge Popup UI/UX
//             (Mematuhi Rule 24 Anti-Floating: Seluruh Aksi Berada di Popup)
// ==============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  const DESKTOP_BRIDGE_URL = 'http://127.0.0.1:8000/api/v1/bridge';

  // ─── 1. Referensi Elemen UI ────────────────────────────────────────────────
  // Header
  const backendStatusBadge = document.getElementById('backend-status-badge');
  const backendStatusText = document.getElementById('backend-status-text');
  const extensionVersionPill = document.getElementById('extension-version-pill');
  if (extensionVersionPill) {
    try {
      const v = chrome.runtime.getManifest().version;
      extensionVersionPill.textContent = `v${v}`;
    } catch (e) {}
  }

  // Navigasi Mode Segmented (Rule 19 Compliant)
  const tabNavStudio = document.getElementById('tab-nav-studio');
  const tabNavFlow = document.getElementById('tab-nav-flow');
  const tabNavAi = document.getElementById('tab-nav-ai');

  // Views Kontekstual
  const standaloneStudioView = document.getElementById('standalone-studio-view');
  const flowPlatformView = document.getElementById('flow-platform-view');
  const aiPlatformView = document.getElementById('ai-platform-view');

  // Standalone Studio Elements (Didelegasikan ke PopupStandaloneStudio)
  const standaloneUI = {
    capcutStatusBadge: document.getElementById('capcut-status-badge'),
    capcutPathPreview: document.getElementById('capcut-path-preview'),
    btnPairCapcut: document.getElementById('btn-pair-capcut'),
    btnOpenFullTab: document.getElementById('btn-open-full-tab'),
    capcutOsLabel: document.getElementById('capcut-os-label'),
    capcutOsHintPath: document.getElementById('capcut-os-hint-path'),
    btnCopyCapcutPath: document.getElementById('btn-copy-capcut-path'),
    groqApiKeyInput: document.getElementById('groq-api-key-input'),
    groqKeyStatus: document.getElementById('groq-key-status'),
    btnSaveGroqKey: document.getElementById('btn-save-groq-key'),
    btnTogglePassword: document.getElementById('btn-toggle-password'),
    dropzoneBox: document.getElementById('dropzone-box'),
    filePickerInput: document.getElementById('file-picker-input'),
    btnBrowseFiles: document.getElementById('btn-browse-files'),
    standaloneProjectCard: document.getElementById('standalone-project-card'),
    standaloneProjectTitle: document.getElementById('standalone-project-title'),
    standaloneAlignBadge: document.getElementById('standalone-align-badge'),
    standaloneSceneCount: document.getElementById('standalone-scene-count'),
    standaloneAudioInfo: document.getElementById('standalone-audio-info'),
    btnInjectCapcut: document.getElementById('btn-inject-capcut'),
    btnStandaloneStartFlow: document.getElementById('btn-standalone-start-flow')
  };

  // Chrome Download Settings Shortcuts (Universal Access SRS-53 & FAB-SRS-070/072)
  const btnDownloadAllFlowImages = document.getElementById('btn-download-all-flow-images');
  if (btnDownloadAllFlowImages) {
    btnDownloadAllFlowImages.addEventListener('click', async () => {
      // Pastikan targetTabId menargetkan Google Flow yang sah (anti-query diri sendiri di popup window)
      let targetTabId = activeTabId;
      if (!targetTabId) {
        try {
          const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
          if (tabs && tabs[0] && tabs[0].url && !tabs[0].url.startsWith('chrome-extension:')) {
            targetTabId = tabs[0].id;
          }
        } catch (e) {}
      }

      btnDownloadAllFlowImages.disabled = true;
      btnDownloadAllFlowImages.textContent = '⏳ Mengunduh Gambar...';
      updateStatus('Memindai adegan untuk diunduh...');

      const onDownloadComplete = (count, projectFolder) => {
        updateStatus(`✓ 1 berkas JSON & ${count} gambar dikirim ke folder: intisariShortMovie/${projectFolder}/!`);
        btnDownloadAllFlowImages.disabled = false;
        btnDownloadAllFlowImages.textContent = '✓ Unduhan Berjalan!';
        setTimeout(() => {
          btnDownloadAllFlowImages.textContent = '📥 Unduh Semua Gambar & JSON ke intisariShortMovie';
        }, 3000);
      };

      const executeDownload = async (items, detectedTitle, projectJsonData) => {
        if (window.FlowCanvasDownloader && window.FlowCanvasDownloader.executeDownloadItems) {
          const res = await window.FlowCanvasDownloader.executeDownloadItems(
            items,
            detectedTitle,
            projectJsonData,
            cachedScanResult,
            updateStatus
          );
          onDownloadComplete(res.count, res.projectFolder);
        }
      };

      // Graceful Fallback jika targetTabId tidak dapat dihubungi atau hasil live scan kosong
      if (!targetTabId) {
        if (cachedScanResult && cachedScanResult.items && cachedScanResult.items.length > 0) {
          await executeDownload(cachedScanResult.items, cachedScanResult.projectName || detectedProjectName, cachedScanResult.projectJson);
          return;
        }
        updateStatus('Tidak ada tab Google Flow aktif yang terhubung.');
        btnDownloadAllFlowImages.disabled = false;
        btnDownloadAllFlowImages.textContent = '📥 Unduh Semua Gambar & JSON ke intisariShortMovie';
        return;
      }

      scanScenesAcrossAllFrames(targetTabId, async (res) => {
        let items = (res && res.success && res.items && res.items.length > 0) ? res.items : null;
        let title = (res && res.projectName) || detectedProjectName;
        let pJson = (res && res.projectJson) || (cachedScanResult && cachedScanResult.projectJson);

        // Fallback ke cache telemetri layar jika live scan tertukar / kosong
        if (!items && cachedScanResult && cachedScanResult.items && cachedScanResult.items.length > 0) {
          items = cachedScanResult.items;
          title = cachedScanResult.projectName || title;
          pJson = cachedScanResult.projectJson || pJson;
        }

        if (!items || items.length === 0) {
          updateStatus('Tidak ada gambar adegan aktif ditemukan di kanvas Flow.');
          btnDownloadAllFlowImages.disabled = false;
          btnDownloadAllFlowImages.textContent = '📥 Unduh Semua Gambar & JSON ke intisariShortMovie';
          return;
        }

        await executeDownload(items, title, pJson);
      });
    });
  }

  const btnHeaderDownloadSettings = document.getElementById('btn-header-download-settings');
  const btnOpenDownloadSettings = document.getElementById('btn-open-download-settings');

  // Scene Validation & Canvas Telemetry (Protected Engine)
  const flowDetectedBadge = document.getElementById('flow-detected-badge');
  const flowProjectTitle = document.getElementById('flow-project-title');
  const sceneValidationStatusText = document.getElementById('scene-validation-status-text');
  const btnRescanScenes = document.getElementById('btn-rescan-scenes');

  // Flow Automation Controls
  const flowModeBadge = document.getElementById('flow-mode-badge');
  const flowStatusBadge = document.getElementById('flow-status-badge');
  const flowStatusText = document.getElementById('flow-status-text');
  const flowStepText = document.getElementById('flow-step-text');
  const flowProgressBar = document.getElementById('flow-progress-bar');
  const flowProgressPercent = document.getElementById('flow-progress-percent');
  const flowCtrlStart = document.getElementById('flow-ctrl-start');
  const flowCtrlActive = document.getElementById('flow-ctrl-active');
  const flowCompletionCard = document.getElementById('flow-completion-card');
  const btnFlowDirectCapcut = document.getElementById('btn-flow-direct-capcut');
  const btnGenerate = document.getElementById('btn-generate');
  const btnPauseFlow = document.getElementById('btn-pause-flow');
  const btnResumeFlow = document.getElementById('btn-resume-flow');
  const btnStopFlow = document.getElementById('btn-stop-flow');

  // AI Extraction Controls
  const platformName = document.getElementById('platform-name');
  const btnExtract = document.getElementById('btn-extract');
  const splitModeSelect = document.getElementById('split-mode-select');

  // Universal Queue & Footer
  const queueStatus = document.getElementById('queue-status');
  const activeIndexSpan = document.getElementById('active-index');
  const btnResetIndex = document.getElementById('btn-reset-index');
  const btnClear = document.getElementById('btn-clear');
  const lastStatusPill = document.getElementById('last-status-pill');
  const btnToggleLog = document.getElementById('btn-toggle-log');
  const logDrawer = document.getElementById('log-drawer');
  const flowQueueUI = {
    sceneCardsSection: document.getElementById('scene-cards-section'),
    sceneCardsCountBadge: document.getElementById('scene-cards-count-badge'),
    sceneCardsList: document.getElementById('scene-cards-list')
  };

  let activeTabId = null;
  let currentPlatform = null;
  let latestClusterData = null;
  let detectedSceneCount = 0;
  let detectedProjectName = 'Proyek_Flow';
  let cachedScanResult = null; // Cache telemetri adegan untuk graceful fallback unduhan (SRS-FAB-072)

  // ─── 2. Sistem Status Pill & Logger Ringkas ────────────────────────────────
  function updateStatus(msg, isLogOnly = false) {
    const time = new Date().toLocaleTimeString();
    if (!isLogOnly && lastStatusPill) {
      lastStatusPill.textContent = msg;
      lastStatusPill.title = msg;
    }
    if (logDrawer) {
      logDrawer.textContent += `\n[${time}] ${msg}`;
      logDrawer.scrollTop = logDrawer.scrollHeight;
    }
  }

  if (btnToggleLog && logDrawer) {
    btnToggleLog.addEventListener('click', () => {
      const isVisible = logDrawer.style.display === 'block';
      logDrawer.style.display = isVisible ? 'none' : 'block';
      btnToggleLog.querySelector('span').textContent = isVisible ? 'Log' : 'Tutup';
    });
  }

  // ─── 3. Helper Status & Progres (Didelegasikan ke PopupFlowQueue v2.6.2) ──
  function calculateProgress(mode, clusterData, localQueue, activeIndex) {
    return window.PopupFlowQueue.calculateProgress(mode, clusterData, localQueue, activeIndex);
  }

  function isFlowRenderCompletelyFinished(mode, clusterData, queue, activeIndex, isRunning, flowState) {
    return window.PopupFlowQueue.isFlowRenderCompletelyFinished(mode, clusterData, queue, activeIndex, isRunning, flowState);
  }

  function getButtonStates(isAutomationRunning, flowStatus) {
    return window.PopupFlowQueue.getButtonStates(isAutomationRunning, flowStatus);
  }

  function renderSceneCardsList(queue, activeIndex, isRunning, currentProcessingId) {
    return window.PopupFlowQueue.renderSceneCardsList(
      flowQueueUI,
      queue,
      activeIndex,
      isRunning,
      currentProcessingId,
      () => activeTabId,
      updateStatus
    );
  }

  // ─── 4. Cek Koneksi Desktop Backend ───────────────────────────────────────
  async function checkBackendStatus() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${DESKTOP_BRIDGE_URL}/cluster-status`, { credentials: 'omit', signal: controller.signal });
      clearTimeout(timeoutId);

      if (res.ok) {
        latestClusterData = await res.json();
        if (backendStatusBadge) backendStatusBadge.className = 'badge badge-online';
        if (backendStatusText) {
          const count = typeof latestClusterData.active_workers_count === 'number'
            ? latestClusterData.active_workers_count
            : (Array.isArray(latestClusterData.active_workers) ? latestClusterData.active_workers.length : 0);
          backendStatusText.textContent = `Online (${count} W)`;
        }
        updateQueueUI();
        return latestClusterData;
      }
    } catch (e) {}

    latestClusterData = null;
    if (backendStatusBadge) backendStatusBadge.className = 'badge badge-offline';
    if (backendStatusText) backendStatusText.textContent = 'Offline';
    updateQueueUI();
    return null;
  }

  // ─── 5. Sinkronisasi Antrean & Indikator UI (v2.7.3: Pure DOM Validation) ──
  function syncVisualValidationCountWithQueue(completedInQueue, renderedUrlsCount, fallbackTitle) {
    if (fallbackTitle && (!detectedProjectName || detectedProjectName === 'Proyek_Flow' || detectedProjectName === 'Proyek_Flow_Adegan')) {
      detectedProjectName = fallbackTitle;
      if (flowProjectTitle) flowProjectTitle.textContent = detectedProjectName;
    }
    // v2.7.3: Hapus manipulasi completedInQueue agar tidak memalsukan jumlah gambar nyata
    const effectiveCount = Math.max(detectedSceneCount || 0, renderedUrlsCount || 0);
    if (effectiveCount > 0) {
      if (flowDetectedBadge) {
        flowDetectedBadge.textContent = `${effectiveCount} Adegan Siap`;
        flowDetectedBadge.className = 'badge badge-online';
      }
      if (sceneValidationStatusText) {
        sceneValidationStatusText.textContent = `✓ ${effectiveCount} Adegan Memiliki Gambar di Layar`;
        sceneValidationStatusText.style.color = '#38bdf8';
      }
    }
  }

  function updateQueueUI() {
    chrome.storage.local.get(['storyboardQueue', 'activeIndex', 'automationRunning', 'flowExecutionState', 'currentProcessingSceneId', 'renderedSceneUrls', 'latestActiveStoryboardTitle'], (data) => {
      const rawQueue = data.storyboardQueue || [];
      const queue = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);
      const activeIndex = typeof data.activeIndex === 'number' ? data.activeIndex : -1;
      const isRunning = !!data.automationRunning;
      const flowState = data.flowExecutionState || {};
      const completedInQueue = (queue.length > 0 && activeIndex >= 0) ? Math.min(queue.length, activeIndex + 1) : 0;
      const renderedUrlsCount = (data.renderedSceneUrls && typeof data.renderedSceneUrls === 'object')
        ? Object.keys(data.renderedSceneUrls).length
        : 0;

      syncVisualValidationCountWithQueue(completedInQueue, renderedUrlsCount, data.latestActiveStoryboardTitle);

      const realQueue = queue.filter(sc => String(sc.id || '').toUpperCase() !== 'COVER');
      const realCount = realQueue.length;

      if (queueStatus) queueStatus.textContent = `${realCount} Prompt Tersimpan`;

      if (activeIndexSpan) {
        if (queue.length > 0 && activeIndex >= 0 && activeIndex < queue.length) {
          const currentScene = queue[activeIndex];
          const isCover = String(currentScene.id || '').toUpperCase() === 'COVER';
          if (isCover) {
            activeIndexSpan.textContent = `Cover Video (1 dari ${realCount})`;
          } else {
            const realIdx = queue.slice(0, activeIndex + 1).filter(sc => String(sc.id || '').toUpperCase() !== 'COVER').length;
            activeIndexSpan.textContent = `Scene ${realIdx} dari ${realCount}`;
          }
        } else {
          activeIndexSpan.textContent = '-';
        }
      }

      // Panel Flow Status & Progress (FR-LOC-001: Prioritas Mode Lokal jika ada antrean lokal di ekstensi)
      const hasLocalPending = queue.length > 0 && activeIndex < queue.length - 1;
      const currentMode = hasLocalPending ? 'local' : (flowState.mode || (latestClusterData ? 'swarm' : 'local'));
      const isCompleted = isFlowRenderCompletelyFinished(currentMode, latestClusterData, queue, activeIndex, isRunning, flowState);
      let currentStatus = isCompleted ? 'done' : (flowState.status || (isRunning ? 'running' : 'idle'));
      // v2.7.3: Penyelarasan State UI Atomik - Jika isRunning false, status dilarang 'running'
      if (!isRunning && currentStatus === 'running') {
        currentStatus = 'idle';
      }

      if (flowModeBadge) flowModeBadge.textContent = currentMode === 'swarm' ? 'SWARM' : 'LOKAL';
      if (flowStatusBadge && flowStatusText) {
        if (currentStatus === 'running') {
          flowStatusBadge.className = 'badge badge-online';
          flowStatusText.textContent = 'AKTIF';
        } else if (currentStatus === 'done') {
          flowStatusBadge.className = 'badge badge-online';
          flowStatusText.textContent = 'SELESAI';
        } else if (currentStatus === 'paused') {
          flowStatusBadge.className = 'badge badge-active';
          flowStatusText.textContent = 'JEDA';
        } else {
          flowStatusBadge.className = 'badge badge-offline';
          flowStatusText.textContent = 'SIAP';
        }
      }

      if (flowStepText) {
        flowStepText.textContent = flowState.text || (isRunning ? 'Memproses tugas...' : 'Standby / Siap mulai');
      }

      const pct = isCompleted ? 100 : calculateProgress(currentMode, latestClusterData, queue, activeIndex);
      if (flowProgressBar) flowProgressBar.style.width = `${pct}%`;
      if (flowProgressPercent) flowProgressPercent.textContent = `${pct}%`;

      // Tampilkan kartu perayaan sukses & tombol CapCut langsung HANYA jika seluruh gambar selesai dirender 100% (v2.6.1)
      if (flowCompletionCard) {
        flowCompletionCard.style.display = isCompleted ? 'block' : 'none';
      }
      if (btnFlowDirectCapcut) {
        btnFlowDirectCapcut.disabled = !isCompleted;
      }

      renderSceneCardsList(queue, activeIndex, isRunning, data.currentProcessingSceneId);

      const btnStates = getButtonStates(isRunning, currentStatus);
      if (flowCtrlStart && flowCtrlActive) {
        if (btnStates.showStart) {
          flowCtrlStart.style.display = 'block';
          flowCtrlActive.style.display = 'none';
        } else {
          flowCtrlStart.style.display = 'none';
          flowCtrlActive.style.display = 'flex';
          if (btnPauseFlow) btnPauseFlow.style.display = btnStates.showPause ? 'inline-flex' : 'none';
          if (btnResumeFlow) btnResumeFlow.style.display = btnStates.showResume ? 'inline-flex' : 'none';
          if (btnStopFlow) btnStopFlow.style.display = btnStates.showStop ? 'inline-flex' : 'none';
        }
      }

      if (btnResetIndex) btnResetIndex.disabled = !btnStates.canReset;
    });
  }

  // ─── 6. Pengalih Mode Tab Segmented & Adaptasi Tab Aktif ──────────────────
  function setActiveNavTab(tabName) {
    if (tabNavStudio) tabNavStudio.classList.toggle('active', tabName === 'studio');
    if (tabNavFlow) tabNavFlow.classList.toggle('active', tabName === 'flow');
    if (tabNavAi) tabNavAi.classList.toggle('active', tabName === 'ai');

    if (standaloneStudioView) standaloneStudioView.style.display = tabName === 'studio' ? 'block' : 'none';
    if (flowPlatformView) flowPlatformView.style.display = tabName === 'flow' ? 'block' : 'none';
    if (aiPlatformView) aiPlatformView.style.display = tabName === 'ai' ? 'block' : 'none';

    if (tabName === 'flow') {
      checkFlowScenesOnScreen();
    }
  }

  if (tabNavStudio) tabNavStudio.addEventListener('click', () => setActiveNavTab('studio'));
  if (tabNavFlow) tabNavFlow.addEventListener('click', () => setActiveNavTab('flow'));
  if (tabNavAi) tabNavAi.addEventListener('click', () => setActiveNavTab('ai'));

  // Deteksi Tab Aktif & Adaptasi Tampilan Awal
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url) {
    activeTabId = tab.id;
    const url = tab.url;
    if (url.includes('gemini.google.com') || url.includes('chatgpt.com') || url.includes('chat.openai.com')) {
      currentPlatform = url.includes('gemini') ? 'Gemini' : 'ChatGPT';
      if (platformName) platformName.textContent = currentPlatform;
      setActiveNavTab('ai');
      updateStatus(`Terhubung ke ${currentPlatform}. Siap mengekstrak naskah.`);
    } else if (url.includes('google.com/flow') || url.includes('flow.google.com')) {
      currentPlatform = 'Google Flow';
      setActiveNavTab('flow');
      updateStatus('Terhubung ke Google Flow.');
    } else {
      setActiveNavTab('studio');
      updateStatus('Mode Standalone Studio Siap.');
    }
  } else {
    setActiveNavTab('studio');
    updateStatus('Mode Standalone Studio Siap.');
  }

  // Inisialisasi Standalone Studio Controller Modular (SRS-FAB-STANDALONE-001)
  if (window.PopupStandaloneStudio) {
    window.PopupStandaloneStudio.init(standaloneUI, updateStatus);
  }

  // ─── 7. Pintasan Setelan Unduhan Browser Chrome ───────────────────────────
  if (btnOpenDownloadSettings) {
    btnOpenDownloadSettings.addEventListener('click', () => {
      chrome.tabs.query({ url: 'chrome://settings/downloads*' }, (tabs) => {
        if (tabs && tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, { active: true });
          if (typeof tabs[0].windowId === 'number') {
            chrome.windows.update(tabs[0].windowId, { focused: true });
          }
        } else {
          chrome.tabs.create({ url: 'chrome://settings/downloads' });
        }
      });
      updateStatus('Membuka setelan unduhan Chrome...');
    });
  }

  // ─── 8. Pemindai Live DOM Multi-Frame (Protected Scene Validation Engine) ──
  function updateScanUI(res) {
    if (!res) return;
    if (res.success) {
      if (res.count > 0 || (res.items && res.items.length > 0)) {
        cachedScanResult = res;
      }
      detectedSceneCount = res.count || 0;
      let pName = res.projectName || '';

      const updateUIWithData = (finalName) => {
        detectedProjectName = finalName || 'Proyek_Flow_Adegan';
        if (flowProjectTitle) flowProjectTitle.textContent = detectedProjectName;
        const totalCards = res.totalCards || 0;
        if (flowDetectedBadge) {
          flowDetectedBadge.textContent = detectedSceneCount > 0 ? `${detectedSceneCount} Adegan Siap` : '0 Adegan Siap';
          flowDetectedBadge.className = detectedSceneCount > 0 ? 'badge badge-online' : 'badge badge-offline';
        }
        if (sceneValidationStatusText) {
          if (detectedSceneCount > 0) {
            const totalStr = totalCards > 0 ? ` / ${totalCards}` : '';
            sceneValidationStatusText.textContent = `✓ ${detectedSceneCount}${totalStr} Adegan Memiliki Gambar di Layar`;
            sceneValidationStatusText.style.color = '#38bdf8';
          } else if (totalCards > 0) {
            sceneValidationStatusText.textContent = `0 / ${totalCards} Adegan Memiliki Gambar (Belum Digenerate)`;
            sceneValidationStatusText.style.color = '#f59e0b';
          } else {
            sceneValidationStatusText.textContent = 'Belum ada gambar adegan terdeteksi';
            sceneValidationStatusText.style.color = '#94a3b8';
          }
        }
      };

      chrome.storage.local.get(['latestActiveStoryboardTitle', 'storyboardQueue', 'activeIndex', 'renderedSceneUrls'], (st) => {
        if (!pName || pName === 'Proyek_Flow_Adegan') {
          if (st.latestActiveStoryboardTitle) {
            pName = st.latestActiveStoryboardTitle;
          } else if (st.storyboardQueue && st.storyboardQueue.title) {
            pName = st.storyboardQueue.title;
          }
        }
        const rawQ = st.storyboardQueue || [];
        const q = Array.isArray(rawQ) ? rawQ : (rawQ.scenes || []);
        const actIdx = typeof st.activeIndex === 'number' ? st.activeIndex : -1;
        const completedInQueue = (q.length > 0 && actIdx >= 0) ? Math.min(q.length, actIdx + 1) : 0;
        const renderedUrlsCount = (st.renderedSceneUrls && typeof st.renderedSceneUrls === 'object')
          ? Object.keys(st.renderedSceneUrls).length
          : 0;
        // v2.7.3: Pure DOM visual validation (fakta gambar kanvas nyata)
        detectedSceneCount = res.count || 0;
        updateUIWithData(pName);
      });
    } else {
      if (flowDetectedBadge) {
        flowDetectedBadge.textContent = 'Gagal Memindai';
        flowDetectedBadge.className = 'badge badge-offline';
      }
      if (sceneValidationStatusText) {
        sceneValidationStatusText.textContent = res.error || 'Tidak dapat memindai adegan';
        sceneValidationStatusText.style.color = '#f87171';
      }
    }
  }

  function scanScenesAcrossAllFrames(tabId, callback) {
    if (window.FlowCanvasDownloader && window.FlowCanvasDownloader.scanScenesAcrossAllFrames) {
      window.FlowCanvasDownloader.scanScenesAcrossAllFrames(tabId, callback);
    } else if (tabId) {
      chrome.tabs.sendMessage(tabId, { action: 'fab_check_scenes_on_screen' }, (res) => {
        if (callback) callback(res || { success: false, items: [], count: 0, totalCards: 0 });
      });
    } else {
      if (callback) callback({ success: false, items: [], count: 0, totalCards: 0 });
    }
  }

  function checkFlowScenesOnScreen() {
    if (!activeTabId) return;
    if (flowDetectedBadge) {
      flowDetectedBadge.textContent = 'Memindai...';
      flowDetectedBadge.className = 'badge badge-active';
    }
    scanScenesAcrossAllFrames(activeTabId, (res) => {
      updateScanUI(res);
    });
  }

  if (btnRescanScenes) {
    btnRescanScenes.addEventListener('click', () => {
      updateStatus('Memindai ulang kartu adegan di layar...');
      checkFlowScenesOnScreen();
    });
  }

  // ─── 8b. Universal Download Settings Handlers (SRS-53) ────────────────────
  function handleOpenDownloadSettings() {
    chrome.tabs.query({}, (tabs) => {
      const existing = (tabs || []).find(t => t.url && t.url.startsWith('chrome://settings/downloads'));
      if (existing) {
        chrome.tabs.update(existing.id, { active: true });
        if (existing.windowId) {
          chrome.windows.update(existing.windowId, { focused: true });
        }
      } else {
        chrome.tabs.create({ url: 'chrome://settings/downloads' });
      }
    });
  }

  if (btnHeaderDownloadSettings) btnHeaderDownloadSettings.addEventListener('click', handleOpenDownloadSettings);
  if (btnOpenDownloadSettings) btnOpenDownloadSettings.addEventListener('click', handleOpenDownloadSettings);

  // ─── 9. Event Listeners: Ekstraksi & Mode Ekspor JSON ──────────────────────
  if (splitModeSelect) {
    chrome.storage.local.get(['splitMode'], (data) => {
      splitModeSelect.value = data.splitMode || 'full_json';
    });
    splitModeSelect.addEventListener('change', () => {
      const mode = splitModeSelect.value;
      chrome.storage.local.set({ splitMode: mode }, () => {
        updateStatus(`Format JSON: ${mode === 'full_json' ? 'Full 1 Master File' : 'Pecah 10 Adegan/Part'}`);
      });
    });
  }

  if (btnExtract) {
    btnExtract.addEventListener('click', () => {
      if (!activeTabId) return;
      btnExtract.disabled = true;
      const origText = btnExtract.innerHTML;
      btnExtract.innerHTML = '⏳ Mengekstrak...';
      updateStatus(`Mengekstrak naskah dari ${currentPlatform || 'AI'}...`);

      chrome.tabs.sendMessage(activeTabId, { action: 'extract_table' }, (response) => {
        btnExtract.disabled = false;
        btnExtract.innerHTML = origText;

        if (chrome.runtime.lastError) {
          updateStatus('Error: Koneksi gagal. Muat ulang tab (F5).');
          return;
        }
        if (response && response.success) {
          updateStatus(`✓ Sukses mengekstrak ${response.count} adegan storyboard!`);
          updateQueueUI();
        } else {
          updateStatus('Gagal: Format tabel naskah tidak ditemukan.');
        }
      });
    });
  }

  // ─── 10. Event Listeners: Otomatisasi Prompt Flow ─────────────────────────
  const selectFlowConcurrency = document.getElementById('select-flow-concurrency');
  if (selectFlowConcurrency) {
    chrome.storage.local.get(['flowConcurrencyLimit'], (data) => {
      if (data && data.flowConcurrencyLimit) {
        selectFlowConcurrency.value = String(data.flowConcurrencyLimit);
      }
    });
    selectFlowConcurrency.addEventListener('change', () => {
      const val = parseInt(selectFlowConcurrency.value, 10) || 3;
      chrome.storage.local.set({ flowConcurrencyLimit: val }, () => {
        updateStatus(`Kecepatan Pipeline: ${val} Prompt In-Flight`);
      });
    });
  }

  if (btnGenerate) {
    btnGenerate.addEventListener('click', () => {
      if (!activeTabId) return;
      updateStatus('Memulai otomatisasi prompt Google Flow...');
      const concurrency = selectFlowConcurrency ? parseInt(selectFlowConcurrency.value, 10) || 3 : 3;
      chrome.storage.local.set({ automationRunning: true, flowConcurrencyLimit: concurrency }, () => {
        chrome.tabs.sendMessage(activeTabId, { action: 'start_automation' }, (response) => {
          if (chrome.runtime.lastError) {
            updateStatus('Error: Tab Flow tidak merespons. Muat ulang halaman Flow (F5).');
            chrome.storage.local.set({ automationRunning: false }, updateQueueUI);
            return;
          }
          updateStatus(response && response.success ? '✓ Otomatisasi prompt berjalan.' : 'Gagal memulai otomatisasi.');
          updateQueueUI();
        });
      });
    });
  }

  if (btnPauseFlow) {
    btnPauseFlow.addEventListener('click', () => {
      if (!activeTabId) return;
      chrome.tabs.sendMessage(activeTabId, { action: 'pause_automation' }, () => {
        updateStatus('⏸ Otomatisasi dijeda setelah adegan ini.');
        updateQueueUI();
      });
    });
  }

  if (btnResumeFlow) {
    btnResumeFlow.addEventListener('click', () => {
      if (!activeTabId) return;
      chrome.storage.local.set({ automationRunning: true }, () => {
        chrome.tabs.sendMessage(activeTabId, { action: 'resume_automation' }, () => {
          updateStatus('▶ Otomatisasi dilanjutkan.');
          updateQueueUI();
        });
      });
    });
  }

  if (btnStopFlow) {
    btnStopFlow.addEventListener('click', () => {
      chrome.storage.local.set({ automationRunning: false }, () => {
        if (activeTabId) chrome.tabs.sendMessage(activeTabId, { action: 'stop_automation' }, () => {});
        updateStatus('⏹ Otomatisasi dihentikan.');
        updateQueueUI();
      });
    });
  }

  // ─── Direct CapCut Injector dari Tab Google Flow (SRS-FAB-058 / v2.6.2) ────
  if (btnFlowDirectCapcut) {
    btnFlowDirectCapcut.addEventListener('click', async () => {
      if (!window.CapCutDraftWriter) {
        updateStatus('Modul CapCutDraftWriter belum siap.');
        return;
      }
      if (window.PopupFlowQueue) {
        await window.PopupFlowQueue.handleFlowDirectCapCutInjection(btnFlowDirectCapcut, updateStatus);
      }
    });
  }

  // ─── 11. Event Listeners: Antrean (Reset & Clear) ──────────────────────────
  if (btnResetIndex) {
    btnResetIndex.addEventListener('click', () => {
      if (window.PopupFlowQueue) {
        window.PopupFlowQueue.resetFlowQueue(() => activeTabId, updateStatus, updateQueueUI);
      }
    });
  }

  if (btnClear) {
    btnClear.addEventListener('click', () => {
      if (window.PopupFlowQueue) {
        window.PopupFlowQueue.clearFlowQueue(updateStatus, updateQueueUI);
      }
    });
  }

  // ─── 12. Poller & Watcher ─────────────────────────────────────────────────
  await checkBackendStatus();
  const statusPollerInterval = setInterval(checkBackendStatus, 3000);
  window.addEventListener('unload', () => clearInterval(statusPollerInterval));

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.storyboardQueue || changes.activeIndex || changes.automationRunning || changes.flowExecutionState || changes.currentProcessingSceneId || changes.renderedSceneUrls) {
      updateQueueUI();
      if (changes.activeIndex || changes.renderedSceneUrls || changes.flowExecutionState || changes.storyboardQueue) {
        checkFlowScenesOnScreen();
      }
    }
  });
});
