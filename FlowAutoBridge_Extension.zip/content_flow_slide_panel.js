// ==============================================================================
// 📁 FILE   : content_flow_slide_panel.js (Lokasi: extension/)
// 📝 FUNGSI : Injektor DOM In-Page Persistent Slide Panel FlowAutoBridge (Chrome 109+)
//             Memungkinkan pengalaman Slide-Over Drawer persisten (tanpa auto-dismiss)
// ==============================================================================

(function () {
  'use strict';

  // FR-ISO-003: Proteksi Isolasi Top-Frame (Abaikan sub-iframe agar drawer tidak diinjeksi ganda)
  if (window !== window.top) {
    return;
  }

  // Cegah injeksi ganda jika skrip dieksekusi berulang kali
  if (window.__FLOWAUTOBRIDGE_SLIDE_PANEL_INITIALIZED__) {
    return;
  }
  window.__FLOWAUTOBRIDGE_SLIDE_PANEL_INITIALIZED__ = true;

  const STORAGE_KEY = 'slidePanelOpen';
  let containerEl = null;
  let iframeEl = null;
  let isOpen = false;

  function log(msg) {
    console.log(`[FlowAutoBridge:SlidePanel] ${msg}`);
  }

  function createSlidePanelDOM() {
    if (document.getElementById('flowautobridge-slide-container')) {
      return document.getElementById('flowautobridge-slide-container');
    }

    // 1. Kontainer Utama Drawer
    const container = document.createElement('div');
    container.id = 'flowautobridge-slide-container';

    // 2. Pegangan Tab Geser (Floating Pull Tab Trigger)
    const pullTab = document.createElement('button');
    pullTab.id = 'flowautobridge-slide-tab';
    pullTab.setAttribute('type', 'button');
    pullTab.setAttribute('aria-label', 'Toggle FlowAutoBridge Slide Panel');
    pullTab.setAttribute('title', 'Buka / Tutup Panel FlowAutoBridge');
    pullTab.innerHTML = `
      <span class="fab-tab-icon">⚡</span>
      <span class="fab-tab-label">FlowBridge</span>
    `;

    // 3. Header Drawer
    const header = document.createElement('div');
    header.id = 'flowautobridge-slide-header';
    header.innerHTML = `
      <div class="fab-header-title-box">
        <span class="fab-status-dot"></span>
        <span class="fab-header-title">FlowAutoBridge</span>
        <span class="fab-header-badge">Slide Panel</span>
      </div>
      <button id="flowautobridge-slide-close-btn" class="fab-close-btn" title="Tutup Panel">✕</button>
    `;

    // 4. Iframe Konten Ekstensi (popup.html)
    const iframe = document.createElement('iframe');
    iframe.id = 'flowautobridge-slide-iframe';
    iframe.setAttribute('title', 'FlowAutoBridge Controller');
    // Muat URL ekstensi internal melalui chrome.runtime.getURL
    iframe.src = chrome.runtime.getURL('popup.html');

    // Susun Elemen
    container.appendChild(pullTab);
    container.appendChild(header);
    container.appendChild(iframe);

    document.body.appendChild(container);

    // 5. Event Listeners
    pullTab.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSlidePanel();
    });

    const closeBtn = header.querySelector('#flowautobridge-slide-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeSlidePanel();
      });
    }

    containerEl = container;
    iframeEl = iframe;

    log('In-Page Persistent Slide Panel berhasil diinjeksi ke DOM.');
    return container;
  }

  function openSlidePanel() {
    if (!containerEl) createSlidePanelDOM();
    if (!containerEl) return;

    isOpen = true;
    containerEl.classList.add('fab-slide-open');
    chrome.storage.local.set({ [STORAGE_KEY]: true });
    log('Slide Panel DIBUKA.');
  }

  function closeSlidePanel() {
    if (!containerEl) return;

    isOpen = false;
    containerEl.classList.remove('fab-slide-open');
    chrome.storage.local.set({ [STORAGE_KEY]: false });
    log('Slide Panel DITUTUP.');
  }

  function toggleSlidePanel() {
    if (isOpen) {
      closeSlidePanel();
    } else {
      openSlidePanel();
    }
  }

  function initSlidePanel() {
    createSlidePanelDOM();

    // Pulihkan status keterbukaan terakhir pengguna dari chrome.storage
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      if (res && res[STORAGE_KEY] === true) {
        openSlidePanel();
      }
    });

    // Dengarkan pesan dari background service worker atau toolbar action click
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.action) return false;

      if (message.action === 'TOGGLE_SLIDE_PANEL') {
        toggleSlidePanel();
        sendResponse({ success: true, isOpen: isOpen });
        return true;
      }
      if (message.action === 'OPEN_SLIDE_PANEL') {
        openSlidePanel();
        sendResponse({ success: true, isOpen: true });
        return true;
      }
      if (message.action === 'CLOSE_SLIDE_PANEL') {
        closeSlidePanel();
        sendResponse({ success: true, isOpen: false });
        return true;
      }
    });
  }

  // Jalankan inisialisasi saat DOM siap
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSlidePanel);
  } else {
    initSlidePanel();
  }
})();

