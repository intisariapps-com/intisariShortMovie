// extension/content_flow_evaluator.js
// Modul evaluasi semantik presisi dan inspeksi kartu DOM Google Flow

const COMMON_PRESET_STOPWORDS = new Set([
  // Preset Visual Styles & Descriptors
  'minimalist', 'doodle', 'stickman', 'stickfigure', 'sketchbook', 'paper', 'monochrome', 
  'linework', 'contour', 'black', 'white', 'simple', 'sparse', 'expressive', 
  'hand', 'drawn', 'style', 'frame', 'anime', 'cinematic', 'vertical', 'ratio', 
  'photo', 'with', 'from', 'view', 'soft', 'deep', 'gentle', 'apply', 'project', 
  'visual', 'treatment', 'recurring', 'subjects', 'present', 'objects', 'hands', 
  'back', 'faces', 'outside', 'including', 'reflections', 'backgrounds', 'include', 
  'exact', 'headline', 'compact', 'clearly', 'legible', 'accent', 'upper', 'safe', 
  'area', 'secondary', 'action', 'without', 'large', 'poster', 'banner', 
  'sufficient', 'contrast', 'letterforms', 'compatible', 'selected', 'medium', 
  'keep', 'main', 'subject', 'unobstructed', 'other', 'lettering', 'logos', 
  'watermarks', 'indonesia', 'english', 'dominant', 'block', 'supporting',
  'art', 'ink', 'lines', 'textured', 'aspect', 'the', 'and', 'for', 'this', 'that',
  // Retro / Pixel / Digital Painting Presets
  'retro', 'basic', 'paint', 'program', 'aesthetic', 'crude', 'pixel', 'pixelated', 
  'aliased', 'jagged', 'outlines', 'outline', 'flat', 'canvas', 'quirky', 
  'vintage', 'grainy', 'noise', 'analog', 'nostalgic', 'palette', 'stroke', 'brush',
  // General Rendering / Artwork Noise & Boilerplate Prompts (v2.7.1)
  'full', 'bleed', 'edge', 'drawing', 'drawings', 'illustration', 'illustrations', 
  'typography', 'framing', 'centered', 'bold', 'prominent', 'upper', 'lower', 'safe', 
  'area', 'doodles', 'stick', 'figure', 'figures', 'image', 'images',
  'vector', 'render', 'rendering', 'rendered', 'composition',
  'lighting', 'shadow', 'shadows', 'highlight', 'highlights', 'background', 'foreground',
  'shot', 'scene', 'photography', 'single', 'details', 'sharp', 'focus', 'clean', 'modern'
]);

/**
 * Pengecekan daftar hitam aset antarmuka (UI assets) Google Flow
 */
function isBlacklistedAssetUrl(url) {
  if (!url || typeof url !== 'string') return true;
  const lower = url.toLowerCase();
  return (
    lower.includes('ssl.gstatic.com/gb/images/ring/') ||
    lower.includes('googleusercontent.com/ogw/') ||
    lower.includes('gstatic.com/aitestkitchen/website/flow/icons/') ||
    lower.includes('gstatic.com/aitestkitchen/website/flow/banners/') ||
    lower.includes('gstatic.com/images/icons/')
  );
}

/**
 * Pengecekan kesesuaian aspek rasio (Aspect Ratio Gate)
 * Menolak gambar kotak 1:1 (seperti cincin profil 126x126) saat task meminta 9:16
 */
function isAspectRatioMatching(width, height, requestedRatio = '9:16') {
  if (!width || !height || width <= 0 || height <= 0) return true;
  if (!requestedRatio || requestedRatio === 'any' || requestedRatio === 'all') return true;
  const ratio = height / width; // Rasio tinggi terhadap lebar

  if (requestedRatio === '9:16') {
    // 9:16 normalnya rasio = 1.77. Tolak jika rasio <= 1.15 (kotak 1:1 atau landscape)
    return ratio >= 1.15;
  }
  if (requestedRatio === '16:9') {
    // 16:9 normalnya rasio = 9/16 = 0.5625. Toleransi presisi: 0.45 s/d 0.68.
    // Tolak jika rasio > 0.68 (seperti format 4:3 = 0.75 atau kotak 1:1) atau < 0.45 (terlalu pipih/banner)
    return ratio >= 0.45 && ratio <= 0.68;
  }
  if (requestedRatio === '1:1') {
    return ratio >= 0.80 && ratio <= 1.25;
  }
  return true;
}

/**
 * Mengekstrak teks headline eksak dari dalam prompt jika tersedia (v2.7.4: Multi-quote & Title Support)
 */
function extractHeadline(prompt) {
  if (!prompt || typeof prompt !== 'string') return '';
  // Mendukung tanda petik tunggal, petik ganda, dan kurung kurawal/tipografis
  const match = prompt.match(/headline\s*['"“‘]([^'"”’]+)['"”’]/i);
  if (match) return match[1].trim();
  // Fallback untuk judul COVER: title text '...' atau title '...'
  const matchTitle = prompt.match(/title(?:\s+text)?\s*['"“‘]([^'"”’]+)['"”’]/i);
  if (matchTitle) return matchTitle[1].trim();
  return '';
}

/**
 * Membersihkan prompt dari klausul non-semantik [Avoid: ...] dan parameter teknis --ar (v2.7.4)
 */
function sanitizePromptForSemanticMatching(prompt) {
  if (!prompt || typeof prompt !== 'string') return '';
  return prompt
    .replace(/\[avoid:[^\]]*\]/gi, '')
    .replace(/--ar\s+\d+:\d+/gi, '')
    .trim();
}

/**
 * Mengekstrak kata kunci aksi/subjek unik adegan dengan membuang kata-kata gaya visual umum & negative prompts
 */
function extractCoreActionKeywords(prompt) {
  if (!prompt || typeof prompt !== 'string') return [];
  const sanitized = sanitizePromptForSemanticMatching(prompt);
  const words = sanitized
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length >= 3 && !COMMON_PRESET_STOPWORDS.has(w) && isNaN(w));

  return Array.from(new Set(words));
}

function extractUniqueKeywords(prompt) {
  return extractCoreActionKeywords(prompt);
}

/**
 * Mengambil teks semantik dari kartu galeri DOM Google Flow tanpa batas kaku 500 karakter
 */
const flowCardPrompts = new WeakMap();

/**
 * Penjaga Pembersih Layar Otomatis (v2.6.6)
 * Menutup secara paksa lightbox, modal preview, atau media viewer yang tidak sengaja terbuka di Google Flow
 */
function dismissAnyOpenFlowViewer() {
  if (typeof document === 'undefined') return;
  try {
    const openDialogs = document.querySelectorAll('dialog[open], [role="dialog"], flow-media-viewer, flow-lightbox, flow-tile-detail-modal, flow-info-panel, [aria-modal="true"]');
    if (openDialogs.length > 0) {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true, cancelable: true
        }));
      }
      document.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true, cancelable: true
      }));
      openDialogs.forEach(dialog => {
        dialog.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true, cancelable: true
        }));
        const closeBtn = dialog.querySelector('button[aria-label*="close" i], button[title*="close" i], button[aria-label*="tutup" i], .close-button, [data-action="close"]');
        if (closeBtn && typeof closeBtn.click === 'function') {
          closeBtn.click();
        }
      });
    }
  } catch (err) {
    // Fail-safe silently
  }
}

// v2.6.6: Ekstraksi pasif murni 100% tanpa klik sintetik pada kartu galeri untuk mencegah modal terbuka.
async function hydrateFlowCardPrompt(imgElement) {
  if (!imgElement) return;
  const cached = flowCardPrompts.get(imgElement);
  if (cached && cached.src === imgElement.src) return;
  const card = imgElement.closest?.('flow-grid-tile-container') || imgElement.parentElement;
  const src = imgElement.src;

  const promptParts = [
    imgElement.getAttribute('alt') || '',
    imgElement.getAttribute('title') || '',
    imgElement.getAttribute('aria-label') || ''
  ];

  const promptEl = card?.querySelector?.('flow-expandable-prompt, .prompt-text, [data-prompt]');
  if (promptEl?.textContent) {
    promptParts.push(promptEl.textContent.trim());
  } else if (card?.innerText && card.innerText.length < 5000) {
    promptParts.push(card.innerText.trim());
  }

  const extractedPrompt = promptParts.filter(Boolean).join(' ').trim();
  if (extractedPrompt) {
    flowCardPrompts.set(imgElement, { src, prompt: extractedPrompt });
  }
}

function getCardSemanticText(imgElement) {
  if (!imgElement) return '';
  const cached = flowCardPrompts.get(imgElement);
  if (cached && cached.src === imgElement.src) return cached.prompt.toLowerCase();
  let container = imgElement.parentElement;
  const textParts = [
    imgElement.getAttribute('alt') || '',
    imgElement.getAttribute('title') || '',
    imgElement.getAttribute('aria-label') || ''
  ];

  // Abaikan elemen jika berada di dalam bar navigasi / akun Google (.gb_...)
  if (imgElement.closest && imgElement.closest('.gb_Ua, .gb_b, header, nav, [role="navigation"]')) {
    return '';
  }

  for (let depth = 0; depth < 8 && container; depth++) {
    if (typeof document !== 'undefined' && container === document.body) break;
    const aria = container.getAttribute?.('aria-label') || '';
    const title = container.getAttribute?.('title') || '';
    if (aria) textParts.push(aria);
    if (title) textParts.push(title);
    // Buka batas pembacaan hingga 5000 karakter agar seluruh teks prompt lengkap di kartu terbaca
    if (container.innerText && container.innerText.length < 5000) {
      textParts.push(container.innerText);
    }
    const promptEl = container.querySelector?.('flow-expandable-prompt, .prompt-text, [data-prompt]');
    if (promptEl && promptEl.textContent) {
      textParts.push(promptEl.textContent);
    }
    if (container.tagName?.toLowerCase() === 'flow-grid-tile-container') break;
    container = container.parentElement;
  }

  return textParts.join(' ').toLowerCase();
}

/**
 * Validasi Presisi Penuh: Mencocokkan teks kartu galeri terhadap teks prompt adegan
 */
function isImageMatchingPrompt(imgElement, expectedPrompt) {
  if (!expectedPrompt) return true;
  if (!imgElement) return false;

  const src = imgElement.src || '';
  if (isBlacklistedAssetUrl(src)) {
    return false;
  }

  // Prioritas 1: Jika cache prompt dari info panel cocok, terima langsung
  const cached = flowCardPrompts.get(imgElement);
  if (cached && cached.src === src) {
    if (cached.prompt.replace(/\s+/g, ' ').trim().toLowerCase() === expectedPrompt.replace(/\s+/g, ' ').trim().toLowerCase()) {
      return true;
    }
  }

  // Prioritas 2 (Fallback Semantik): Selalu periksa teks semantik kartu DOM
  const cardText = getCardSemanticText(imgElement);
  // WAJIB: Elemen yang tidak memiliki teks kartu galeri ditolak mutlak
  if (!cardText || cardText.trim().length === 0) {
    return false;
  }

  // 1. Uji Headline Eksak (Tingkat Tertinggi - 100% Presisi)
  const expectedHeadline = extractHeadline(expectedPrompt);
  const cardHeadline = extractHeadline(cardText);
  if (expectedHeadline) {
    if (cardText.includes(expectedHeadline.toLowerCase())) {
      return true;
    }
    // Jika kartu memuat headline lain yang bertolak belakang, tolak mutlak
    if (cardHeadline && cardHeadline.toLowerCase() !== expectedHeadline.toLowerCase()) {
      return false;
    }
  }

  // 2. Uji Kata Kunci Aksi Subjek Unik
  const coreKeywords = extractCoreActionKeywords(expectedPrompt);
  if (coreKeywords.length === 0) {
    return false;
  }

  let matchCount = 0;
  for (const kw of coreKeywords) {
    if (cardText.includes(kw)) matchCount++;
  }

  // Memerlukan kecocokan proporsi >= 50% kata unik DAN minimal 3 kata unik aksi (atau 100% jika <= 2 kata)
  if (coreKeywords.length <= 2) {
    return matchCount === coreKeywords.length;
  }
  return matchCount >= 3 && (matchCount / coreKeywords.length) >= 0.50;
}

// Evaluasi ketat khusus Pre-Flight (Inspeksi kartu lama di kanvas sebelum render)
function isStrictImageMatchingPrompt(imgElement, expectedPrompt) {
  if (!expectedPrompt || !imgElement) return false;

  const src = imgElement.src || '';
  if (isBlacklistedAssetUrl(src)) {
    return false;
  }

  const cached = flowCardPrompts.get(imgElement);
  if (cached && cached.src === src) return isImageMatchingPrompt(imgElement, expectedPrompt);

  const cardText = getCardSemanticText(imgElement);
  if (!cardText || cardText.trim().length === 0) {
    return false;
  }

  // 1. Jika ada Headline, wajib cocok eksak 100%
  const expectedHeadline = extractHeadline(expectedPrompt);
  const cardHeadline = extractHeadline(cardText);
  if (expectedHeadline) {
    if (cardText.includes(expectedHeadline.toLowerCase())) {
      return true;
    }
    return false;
  }

  // 2. Uji Kata Kunci Aksi Subjek Unik dengan Standar Sangat Ketat (Strict Pre-flight)
  const coreKeywords = extractCoreActionKeywords(expectedPrompt);
  if (coreKeywords.length === 0) {
    return false;
  }

  let matchCount = 0;
  for (const kw of coreKeywords) {
    if (cardText.includes(kw)) matchCount++;
  }

  // Pre-flight membutuhkan kecocokan minimal 75% DAN minimal 3 kata (atau 100% jika kata kunci <= 2)
  const ratio = matchCount / coreKeywords.length;
  if (coreKeywords.length <= 2) {
    return matchCount === coreKeywords.length;
  }
  return matchCount >= 3 && ratio >= 0.75;
}

function scanFailedCards() {
  const cards = document.querySelectorAll('div, section, article');
  let policyCount = 0;
  let unusualCount = 0;
  for (const c of cards) {
    if (c.children.length > 8) continue;
    const txt = (c.innerText || '').toLowerCase();
    if (
      txt.includes('aktivitas yang tidak biasa') ||
      txt.includes('unusual activity') ||
      txt.includes('kredit untuk pembuatan') ||
      txt.includes('tidak perlu menggunakan kredit')
    ) {
      unusualCount++;
    } else if (
      (txt.includes('gagal') && (txt.includes('kebijakan') || txt.includes('perintah lain'))) ||
      txt.includes('melanggar kebijakan') ||
      txt.includes('content violation') ||
      txt.includes("couldn't generate") ||
      txt.includes('failed to generate')
    ) {
      policyCount++;
    }
  }
  return { policyCount, unusualCount };
}

// ── PRE-FLIGHT CANVAS INSPECTOR (v2.7.3: Quantity Gate & Claimed Isolation) ──
async function inspectCanvasForPrompt(expectedPrompt, aspectRatio = '9:16', sceneIndex = 0, claimedUrls = null) {
  if (!expectedPrompt || typeof document === 'undefined') {
    return { found: false, status: 'none', imgElement: null };
  }

  const images = Array.from(document.querySelectorAll('img')).filter(img => {
    const src = img.src || '';
    const width = img.naturalWidth || img.clientWidth || 0;
    const height = img.naturalHeight || img.clientHeight || 0;
    return !!src && (width > 120 || height > 120) && !isBlacklistedAssetUrl(src) && isAspectRatioMatching(width, height, aspectRatio);
  });

  // ── 1. GERBANG KUANTITAS KANVAS FISIK (v2.7.3) ──
  // Untuk adegan index ke-N (0-based), kanvas fisik wajib memiliki minimal N + 1 gambar.
  // Jika di kanvas baru ada 1 gambar, adegan index 1 (ADEGAN_01) atau seterusnya MUST NOT MATCH!
  if (images.length <= sceneIndex) {
    return { found: false, status: 'none', imgElement: null, reason: 'canvas_count_too_low' };
  }

  // ── 2. FILTER GAMBAR YANG SUDAH DIKLAIM OLEH ADEGAN LAIN (v2.7.3) ──
  const claimedSet = (claimedUrls instanceof Set) ? claimedUrls : new Set(claimedUrls || []);
  const availableImages = images.filter(img => !claimedSet.has(img.src));
  if (availableImages.length === 0) {
    return { found: false, status: 'none', imgElement: null, reason: 'all_images_claimed' };
  }

  for (const img of availableImages) {
    await hydrateFlowCardPrompt(img);
    if (isStrictImageMatchingPrompt(img, expectedPrompt)) {
      return {
        found: true,
        status: 'completed',
        imgElement: img,
        cardElement: img.parentElement
      };
    }
  }

  return { found: false, status: 'none', imgElement: null };
}

// ── 5. PROTOKOL ANTI-GAMBAR PUTIH & VALIDASI INTEGRITAS BITMAP (SRS-FAB-LOCAL-WHITEGUARD-001) ──

function isFlowImageFullyRendered(imgElement) {
  if (!imgElement) return false;
  
  // 1. Validasi status pemuatan dasar
  if (imgElement.complete !== true) return false;
  
  // 2. Validasi dimensi asli bitmap (menolak ukuran semu CSS clientWidth)
  const nw = imgElement.naturalWidth || 0;
  const nh = imgElement.naturalHeight || 0;
  if (nw < 256 || nh < 256) return false;
  
  // 3. Validasi URL sumber
  const src = imgElement.src || '';
  if (!src || src.length < 30) return false;
  if (typeof isBlacklistedAssetUrl === 'function' && isBlacklistedAssetUrl(src)) return false;
  
  // 4. Periksa apakah kartu induk masih menampilkan indikator loading / spinner
  try {
    const card = imgElement.closest ? imgElement.closest('flow-grid-tile-container') : imgElement.parentElement;
    if (card) {
      const activeSpinner = card.querySelector('mat-progress-spinner, mdc-circular-progress, [class*="spinner" i], [class*="loading" i], [role="progressbar"], [aria-busy="true"]');
      if (activeSpinner) return false;
    }
  } catch (e) {}

  return true;
}

function isCanvasBitmapBlankWhite(canvas, ctx, w, h) {
  try {
    if (!ctx || !w || !h || w <= 0 || h <= 0) return true;
    const pad = Math.min(15, Math.floor(w * 0.05), Math.floor(h * 0.05));
    const samplePoints = [
      [Math.floor(w / 2), Math.floor(h / 2)],
      [pad, pad],
      [w - pad, pad],
      [pad, h - pad],
      [w - pad, h - pad]
    ];
    let whiteCount = 0;
    let transparentCount = 0;
    for (const [x, y] of samplePoints) {
      const pixel = ctx.getImageData(x, y, 1, 1).data;
      if (pixel[0] >= 248 && pixel[1] >= 248 && pixel[2] >= 248) whiteCount++;
      if (pixel[3] < 15) transparentCount++;
    }
    // Jika semua titik sampel putih murni atau transparan kosong -> tolak sebagai blank image
    if (whiteCount === samplePoints.length || transparentCount === samplePoints.length) {
      return true;
    }
    return false;
  } catch (e) {
    return false;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    isBlacklistedAssetUrl,
    isAspectRatioMatching,
    extractHeadline,
    sanitizePromptForSemanticMatching,
    extractCoreActionKeywords,
    extractUniqueKeywords,
    getCardSemanticText,
    hydrateFlowCardPrompt,
    dismissAnyOpenFlowViewer,
    isImageMatchingPrompt,
    isStrictImageMatchingPrompt,
    scanFailedCards,
    inspectCanvasForPrompt,
    isFlowImageFullyRendered,
    isCanvasBitmapBlankWhite
  };
} else if (typeof globalThis !== 'undefined') {
  globalThis.isBlacklistedAssetUrl = isBlacklistedAssetUrl;
  globalThis.isAspectRatioMatching = isAspectRatioMatching;
  globalThis.extractHeadline = extractHeadline;
  globalThis.sanitizePromptForSemanticMatching = sanitizePromptForSemanticMatching;
  globalThis.extractCoreActionKeywords = extractCoreActionKeywords;
  globalThis.extractUniqueKeywords = extractUniqueKeywords;
  globalThis.getCardSemanticText = getCardSemanticText;
  globalThis.hydrateFlowCardPrompt = hydrateFlowCardPrompt;
  globalThis.dismissAnyOpenFlowViewer = dismissAnyOpenFlowViewer;
  globalThis.isImageMatchingPrompt = isImageMatchingPrompt;
  globalThis.scanFailedCards = scanFailedCards;
  globalThis.inspectCanvasForPrompt = inspectCanvasForPrompt;
  globalThis.isFlowImageFullyRendered = isFlowImageFullyRendered;
  globalThis.isCanvasBitmapBlankWhite = isCanvasBitmapBlankWhite;
}
