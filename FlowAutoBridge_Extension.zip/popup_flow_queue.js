// ==============================================================================
// 📁 FILE   : extension/popup_flow_queue.js
// 📝 FUNGSI : Modul terisolasi khusus Tab Google Flow (Manajemen Antrean,
//             Impor JSON Mandiri, Kalkulasi Progres, & Daftar Kartu Adegan).
//             Mematuhi Batas < 1.000 Baris & Isolasi Fitur 3 Tab (v2.6.2).
// ==============================================================================

(function(global) {
  'use strict';

  /**
   * Menghitung persentase progres render berdasarkan adegan cerita (non-COVER).
   */
  function calculateProgress(mode, clusterData, localQueue, activeIndex) {
    if (mode === 'swarm' && clusterData && clusterData.total_scenes > 0) {
      const pct = Math.round((clusterData.completed_scenes / clusterData.total_scenes) * 100);
      return Math.min(100, Math.max(0, pct));
    }
    const q = Array.isArray(localQueue) ? localQueue : [];
    const realQueue = q.filter(sc => String(sc.id || '').toUpperCase() !== 'COVER');
    const total = realQueue.length || q.length;
    if (total === 0 || activeIndex < 0) return 0;
    const completedReal = realQueue.length > 0
      ? q.slice(0, activeIndex + 1).filter(sc => String(sc.id || '').toUpperCase() !== 'COVER').length
      : Math.min(activeIndex + 1, total);
    const pct = Math.round((Math.min(completedReal, total) / total) * 100);
    return Math.min(100, Math.max(0, pct));
  }

  /**
   * Penjaga ketat (Gatekeeper) penyelesaian 100% seluruh gambar di antrean Flow.
   */
  function isFlowRenderCompletelyFinished(mode, clusterData, queue, activeIndex, isRunning, flowState) {
    const q = Array.isArray(queue) ? queue : [];
    if (q.length === 0) return false;
    if (mode === 'swarm' && clusterData && clusterData.total_scenes > 0) {
      return clusterData.completed_scenes >= clusterData.total_scenes && (clusterData.in_progress_scenes || 0) === 0;
    }
    const state = flowState || {};
    const allScenesDone = activeIndex >= q.length - 1;
    const isStateFinished = !isRunning || state.allCompleted === true || state.status === 'done';
    return allScenesDone && isStateFinished;
  }

  /**
   * Menentukan status visibilitas tombol Mulai / Jeda / Lanjut / Stop / Ulangi.
   */
  function getButtonStates(isAutomationRunning, flowStatus) {
    const isRunning = !!isAutomationRunning;
    // v2.7.3: Jika isRunning false dan status masih 'running', normalkan ke 'idle'
    const status = (!isRunning && flowStatus === 'running') ? 'idle' : (flowStatus || 'idle');
    if (status === 'done' || (!isRunning && status !== 'paused')) {
      return { showStart: true, showPause: false, showResume: false, showStop: false, canReset: true };
    }
    if (status === 'paused') {
      return { showStart: false, showPause: false, showResume: true, showStop: true, canReset: false };
    }
    return { showStart: false, showPause: true, showResume: false, showStop: true, canReset: false };
  }

  /**
   * Merender daftar kartu setiap adegan (COVER + ADEGAN_01..N) dengan tombol Kirim / Buat Ulang.
   */
  function renderSceneCardsList(ui, queue, activeIndex, isRunning, currentProcessingId, getActiveTabId, updateStatus) {
    const { sceneCardsSection, sceneCardsCountBadge, sceneCardsList } = ui || {};
    if (!sceneCardsSection || !sceneCardsList) return;

    const q = Array.isArray(queue) ? queue : [];
    if (q.length === 0) {
      sceneCardsSection.style.display = 'none';
      sceneCardsList.innerHTML = '';
      return;
    }

    sceneCardsSection.style.display = 'block';
    if (sceneCardsCountBadge) sceneCardsCountBadge.textContent = `${q.length} Prompt`;

    sceneCardsList.innerHTML = '';
    q.forEach((sc, idx) => {
      const sceneId = String(sc.id || `ADEGAN_${String(idx + 1).padStart(2, '0')}`).toUpperCase();
      const promptText = String(sc.image_prompt || sc.prompt_flow || sc.prompt || '').trim();
      const aspectRatio = sc.aspect_ratio || (promptText.includes('16:9') ? '16:9' : '9:16');
      const isDone = idx <= activeIndex;
      const isProcessingNow = isRunning && (idx === activeIndex + 1 || String(currentProcessingId || '').toUpperCase() === sceneId);

      const card = document.createElement('div');
      card.className = 'scene-card-item';

      const statusBadgeClass = isProcessingNow ? 'badge-active' : (isDone ? 'badge-online' : 'badge-offline');
      const statusLabel = isProcessingNow ? '⏳ Proses' : (isDone ? '✓ Selesai' : '• Antre');
      const btnLabel = isDone ? '🔄 Buat Ulang' : '⚡ Kirim';

      card.innerHTML = `
        <div class="scene-card-header">
          <div style="display:flex;align-items:center;gap:5px;">
            <strong style="font-size:11px;color:#93c5fd;">${sceneId === 'COVER' ? '🖼️ COVER' : '🎬 ' + sceneId}</strong>
            <span class="badge ${statusBadgeClass}" style="font-size:9px;padding:2px 6px;">${statusLabel}</span>
          </div>
          <div style="display:flex;align-items:center;gap:4px;">
            <button type="button" class="btn-copy-scene" title="Salin Prompt" style="background:rgba(255,255,255,0.06);border:1px solid var(--border-color);border-radius:5px;color:#94a3b8;font-size:10px;padding:2px 6px;cursor:pointer;">📋</button>
            <button type="button" class="btn-scene-send">${btnLabel}</button>
          </div>
        </div>
        <div class="scene-card-prompt" title="${promptText.replace(/"/g, '&quot;')}">${promptText || '(Prompt kosong)'}</div>
      `;

      const btnCopy = card.querySelector('.btn-copy-scene');
      if (btnCopy) {
        btnCopy.addEventListener('click', () => {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(promptText);
            btnCopy.textContent = '✓';
            if (typeof updateStatus === 'function') updateStatus(`Prompt ${sceneId} disalin ke clipboard.`);
            setTimeout(() => { btnCopy.textContent = '📋'; }, 1800);
          }
        });
      }

      const btnSend = card.querySelector('.btn-scene-send');
      if (btnSend) {
        btnSend.addEventListener('click', () => {
          btnSend.disabled = true;
          btnSend.textContent = '⏳ Mengirim...';
          if (typeof updateStatus === 'function') updateStatus(`Mengirim prompt ${sceneId} ke Google Flow...`);

          chrome.tabs.query({}, (tabs) => {
            const flowTab = (tabs || []).find(t => t.url && (
              t.url.includes('flow.google.com') ||
              t.url.includes('google.com/flow') ||
              t.url.includes('labs.google/fx')
            ));
            const fallbackTabId = typeof getActiveTabId === 'function' ? getActiveTabId() : null;
            const targetTabId = (flowTab && flowTab.id) || fallbackTabId;

            if (!targetTabId) {
              if (typeof updateStatus === 'function') updateStatus('Buka tab Google Flow terlebih dahulu.');
              btnSend.disabled = false;
              btnSend.textContent = btnLabel;
              return;
            }

            if (flowTab && !flowTab.active) chrome.tabs.update(flowTab.id, { active: true });
            chrome.tabs.sendMessage(targetTabId, {
              action: 'send_single_scene',
              sceneIndex: idx,
              sceneId: sceneId,
              prompt: promptText,
              aspectRatio: aspectRatio
            }, (res) => {
              btnSend.disabled = false;
              if (chrome.runtime.lastError || !res || !res.success) {
                if (typeof updateStatus === 'function') updateStatus(`Gagal kirim ${sceneId}: Muat ulang (F5) tab Google Flow.`);
                btnSend.textContent = btnLabel;
                return;
              }
              btnSend.textContent = '✓ Terkirim';
              if (typeof updateStatus === 'function') updateStatus(`✓ Prompt ${sceneId} sedang dirender di Google Flow...`);
              setTimeout(() => { btnSend.textContent = '🔄 Buat Ulang'; }, 2500);
            });
          });
        });
      }

      sceneCardsList.appendChild(card);
    });
  }

  /**
   * Mengimpor berkas .json storyboard secara langsung di dalam Tab Google Flow.
   */
  async function handleFlowJsonFilesImport(files, updateStatus, onQueueUpdated) {
    if (!files || files.length === 0) return;
    const jsonFile = Array.from(files).find(f => f.name.toLowerCase().endsWith('.json'));
    if (!jsonFile) {
      if (typeof updateStatus === 'function') updateStatus('Pilih berkas storyboard berformat .json.');
      return;
    }

    try {
      const text = await jsonFile.text();
      const parsed = JSON.parse(text);
      const rawScenes = Array.isArray(parsed) ? parsed : (parsed.scenes || parsed.storyboard || []);
      if (!Array.isArray(rawScenes) || rawScenes.length === 0) {
        if (typeof updateStatus === 'function') updateStatus('Format JSON tidak memiliki daftar scenes yang valid.');
        return;
      }

      const rawTitle = parsed.title || parsed.project_title || jsonFile.name.replace(/\.json$/i, '') || 'Proyek_ShortMovie';
      const cleanTitle = String(rawTitle)
        .replace(/\(?part\s*\d+\)?/gi, '')
        .replace(/[^\w\s\-]+/g, ' ')
        .trim()
        .split(/\s+/)
        .slice(0, 5)
        .join('_') || 'Proyek';

      // Jika nama file atau judul sudah berakhiran _hashTag (4 karakter alfanumerik), pertahankan untuk konsistensi eksperimen
      let projectFolder = '';
      const existingHashMatch = cleanTitle.match(/^(.+)_([a-z0-9]{4})$/i) || jsonFile.name.replace(/\.json$/i, '').match(/^(.+)_([a-z0-9]{4})$/i);
      if (existingHashMatch) {
        projectFolder = `${existingHashMatch[1]}_${existingHashMatch[2].toLowerCase()}`;
      } else {
        const hashTag = Math.random().toString(36).substring(2, 6);
        projectFolder = `${cleanTitle}_${hashTag}`;
      }

      const queue = [];
      const topCoverPrompt = String(parsed.cover_prompt || parsed.thumbnail_prompt || '').trim();
      const hasCoverInArray = rawScenes.some(sc => String(sc.id || '').toUpperCase() === 'COVER');
      if (topCoverPrompt && !hasCoverInArray) {
        queue.push({
          id: 'COVER',
          narrative: '',
          image_prompt: topCoverPrompt,
          prompt_flow: topCoverPrompt
        });
      }

      let realCounter = 0;
      rawScenes.forEach((sc) => {
        const rawId = String(sc.id || '').toUpperCase();
        const isCover = rawId === 'COVER';
        if (!isCover) realCounter++;
        const normId = isCover ? 'COVER' : `ADEGAN_${String(realCounter).padStart(2, '0')}`;
        const imgPrompt = String(sc.image_prompt || sc.prompt_flow || sc.prompt || '').trim();
        queue.push({
          ...sc,
          id: normId,
          image_prompt: imgPrompt,
          prompt_flow: imgPrompt
        });
      });

      let detectedRatio = parsed.aspect_ratio || parsed.video_ratio || '';
      if (!detectedRatio) {
        for (const sc of queue) {
          const p = `${sc.image_prompt || ''} ${sc.prompt_flow || ''}`;
          if (/--ar\s+9:16|vertical\s+9:16|\b9:16\b/i.test(p)) { detectedRatio = '9:16'; break; }
          if (/--ar\s+16:9|horizontal\s+16:9|\b16:9\b/i.test(p)) { detectedRatio = '16:9'; break; }
        }
      }
      if (!detectedRatio) detectedRatio = '9:16';

      chrome.storage.local.set({
        storyboardQueue: queue,
        latestActiveStoryboardTitle: rawTitle,
        activeProjectFolder: projectFolder,
        activeAspectRatio: detectedRatio,
        activeIndex: -1,
        automationRunning: false,
        renderedSceneUrls: {},
        flowExecutionState: {
          text: `✓ ${queue.length} prompt dimuat dari ${jsonFile.name}. Siap mulai!`,
          status: 'idle',
          mode: 'local',
          allCompleted: false
        }
      }, () => {
        // Auto-download salinan naskah JSON ke folder proyek yang sama dengan adegan (v2.6.3)
        try {
          if (!parsed.aspect_ratio) {
            parsed.aspect_ratio = detectedRatio;
            parsed.video_ratio = detectedRatio;
          }
          const serializedText = JSON.stringify(parsed, null, 2);
          const jsonBlob = new Blob([serializedText], { type: 'application/json' });
          const reader = new FileReader();
          reader.onloadend = () => {
            chrome.runtime.sendMessage({
              action: 'download_storyboard_json',
              dataUrl: reader.result,
              filename: `${projectFolder}.json`,
              projectFolder: projectFolder,
              subfolder: 'intisariShortMovie'
            }, () => {
              const _ignored = chrome.runtime.lastError;
            });
          };
          reader.readAsDataURL(jsonBlob);
        } catch (_) {}

        // Jika audio sudah ada di storage, sinkronkan ke folder proyek baru ini juga
        chrome.storage.local.get(['activeProjectAudioDataUrl', 'activeProjectAudioExt'], (aRes) => {
          if (aRes && aRes.activeProjectAudioDataUrl) {
            const ext = aRes.activeProjectAudioExt || 'mp3';
            const audioName = `${projectFolder}.${ext}`;
            chrome.storage.local.set({ activeProjectAudioFileName: audioName });
            chrome.runtime.sendMessage({
              action: 'download_project_audio',
              dataUrl: aRes.activeProjectAudioDataUrl,
              filename: audioName,
              projectFolder: projectFolder,
              subfolder: 'intisariShortMovie'
            }, () => { const _ignored = chrome.runtime.lastError; });
          }
        });

        if (typeof updateStatus === 'function') {
          updateStatus(`✓ ${queue.length} prompt adegan & JSON tersimpan ke Downloads/intisariShortMovie/${projectFolder}/!`);
        }
        if (typeof onQueueUpdated === 'function') onQueueUpdated();
      });
    } catch (err) {
      if (typeof updateStatus === 'function') {
        updateStatus(`Gagal membaca JSON: ${err.message || err}`);
      }
    }
  }

  /**
   * Mereset progres antrean Flow ke awal (Scene 1) dengan sesi folder baru (v2.6.4).
   */
  async function resetFlowQueue(getActiveTabId, updateStatus, onQueueUpdated) {
    if (global.PopupModal && typeof global.PopupModal.showConfirm === 'function') {
      const ok = await global.PopupModal.showConfirm({
        variant: 'warning',
        icon: '↻',
        title: 'Ulangi Antrean dari Awal?',
        subtitle: 'Reset Progres Render Google Flow',
        badge: 'RESET ANTREAN',
        message: 'Progres antrean akan dikembalikan ke adegan pertama (COVER / Scene 1) dengan sesi folder proyek baru.',
        confirmText: '↻ Ya, Ulangi',
        cancelText: 'Batal'
      });
      if (!ok) return;
    }
    chrome.storage.local.get(['latestActiveStoryboardTitle', 'activeProjectFolder', 'activeProjectAudioDataUrl', 'activeProjectAudioExt'], (res) => {
      const rawTitle = res.latestActiveStoryboardTitle || 'Proyek';
      const cleanTitle = String(rawTitle).replace(/\(?part\s*\d+\)?/gi, '').replace(/[^\w\s\-]+/g, ' ').trim().split(/\s+/).slice(0, 5).join('_') || 'Proyek';
      const newHash = Math.random().toString(36).substring(2, 6);
      const newFolder = `${cleanTitle}_${newHash}`;
      const ext = res.activeProjectAudioExt || 'mp3';
      const nextAudioName = res.activeProjectAudioDataUrl ? `${newFolder}.${ext}` : '';
      chrome.storage.local.set({
        activeIndex: -1,
        activeProjectFolder: newFolder,
        renderedSceneUrls: {},
        ...(nextAudioName ? { activeProjectAudioFileName: nextAudioName } : {}),
        flowExecutionState: { text: 'Antrean direset ke awal. Siap mulai.', status: 'idle', allCompleted: false }
      }, () => {
        if (res.activeProjectAudioDataUrl && nextAudioName) {
          chrome.runtime.sendMessage({
            action: 'download_project_audio',
            dataUrl: res.activeProjectAudioDataUrl,
            filename: nextAudioName,
            projectFolder: newFolder,
            subfolder: 'intisariShortMovie'
          }, () => { const _ignored = chrome.runtime.lastError; });
        }
        const tabId = typeof getActiveTabId === 'function' ? getActiveTabId() : null;
        if (tabId) chrome.tabs.sendMessage(tabId, { action: 'reset_index', activeProjectFolder: newFolder }, () => {});
        if (typeof updateStatus === 'function') updateStatus(`Antrean direset ke awal. Sesi folder baru: ${newFolder}`);
        if (typeof onQueueUpdated === 'function') onQueueUpdated();
      });
    });
  }

  /**
   * Menghapus seluruh antrean prompt Google Flow (v2.6.4).
   */
  async function clearFlowQueue(updateStatus, onQueueUpdated) {
    if (global.PopupModal && typeof global.PopupModal.showConfirm === 'function') {
      const ok = await global.PopupModal.showConfirm({
        variant: 'danger',
        icon: '🗑️',
        title: 'Hapus Seluruh Antrean?',
        subtitle: 'Pembersihan Data Storyboard Flow',
        badge: 'HAPUS DATA',
        message: 'Seluruh daftar prompt adegan yang tersimpan di antrean Flow saat ini akan dibersihkan.',
        confirmText: '🗑️ Ya, Hapus',
        cancelText: 'Batal'
      });
      if (!ok) return;
    }
    chrome.storage.local.set({
      storyboardQueue: [],
      activeIndex: -1,
      automationRunning: false,
      renderedSceneUrls: {},
      flowExecutionState: { text: 'Antrean dibersihkan.', status: 'idle', allCompleted: false }
    }, () => {
      if (typeof updateStatus === 'function') updateStatus('Antrean dibersihkan.');
      if (typeof onQueueUpdated === 'function') onQueueUpdated();
    });
  }

  /**
   * Menulis draf CapCut langsung saat seluruh gambar di antrean Flow selesai 100%.
   */
  async function handleFlowDirectCapCutInjection(btnFlowDirectCapcut, updateStatus) {
    if (!global.CapCutDraftWriter) {
      if (typeof updateStatus === 'function') updateStatus('Modul CapCutDraftWriter belum siap.');
      return;
    }

    chrome.storage.local.get([
      'storyboardQueue',
      'latestActiveStoryboardTitle',
      'activeProjectFolder',
      'activeProjectTotalDurationUs',
      'activeProjectAudioDataUrl',
      'activeProjectAudioFileName',
      'activeProjectAudioExt'
    ], async (data) => {
      const studioProj = (global.PopupStandaloneStudio && typeof global.PopupStandaloneStudio.getActiveProject === 'function')
        ? global.PopupStandaloneStudio.getActiveProject()
        : null;
      let studioAudio = (global.PopupStandaloneStudio && typeof global.PopupStandaloneStudio.getActiveAudioFile === 'function')
        ? global.PopupStandaloneStudio.getActiveAudioFile()
        : null;

      const rawQueue = data.storyboardQueue || (studioProj && studioProj.scenes) || [];
      let scenes = Array.isArray(rawQueue) ? rawQueue : (rawQueue.scenes || []);
      const title = data.latestActiveStoryboardTitle || (studioProj && studioProj.title) || 'Proyek_ShortMovie';
      const projectFolder = data.activeProjectFolder || (studioProj && studioProj.projectFolder) || '';
      let totalDurationUs = data.activeProjectTotalDurationUs || (studioProj && studioProj.totalDurationUs) || 0;
      let coverOffset = (studioProj && studioProj.coverOffset) || 0.0;
      const audioExt = data.activeProjectAudioExt || 'mp3';
      const expectedAudioName = data.activeProjectAudioFileName
        ? (projectFolder ? `${projectFolder}.${audioExt}` : data.activeProjectAudioFileName)
        : ((studioProj && studioProj.audioFileName) || '');

      // Pulihkan objek File audio dari storage jika variabel RAM studioAudio kosong akibat tutup-buka ekstensi (v2.6.3)
      if (!studioAudio && data.activeProjectAudioDataUrl && global.PopupStandaloneStudio && typeof global.PopupStandaloneStudio.dataUrlToFile === 'function') {
        studioAudio = global.PopupStandaloneStudio.dataUrlToFile(data.activeProjectAudioDataUrl, expectedAudioName || `${projectFolder || 'narasi'}.${audioExt}`);
      }

      if (!scenes || scenes.length === 0) {
        if (typeof updateStatus === 'function') updateStatus('Antrean adegan tidak ditemukan. Impor JSON terlebih dahulu.');
        return;
      }

      const needsAlign = !totalDurationUs || scenes.some(sc => String(sc.id || '').toUpperCase() !== 'COVER' && !(sc.duration_us > 0));
      if (needsAlign && global.StoryboardAligner) {
        try {
          const aligned = global.StoryboardAligner.alignStoryboardWithWhisper(scenes, [], 0);
          scenes = aligned.allScenesWithCover || aligned.scenes || scenes;
          totalDurationUs = aligned.totalDurationUs || totalDurationUs;
          coverOffset = aligned.coverOffset || coverOffset;
        } catch (_) {}
      }

      try {
        if (btnFlowDirectCapcut) {
          btnFlowDirectCapcut.disabled = true;
          btnFlowDirectCapcut.textContent = '⏳ Menulis Draf CapCut...';
        }
        if (typeof updateStatus === 'function') updateStatus('Menghubungkan & menulis berkas draf CapCut...');

        let handle = await global.CapCutDraftWriter.getStoredDirectoryHandle();
        if (handle) {
          const isGranted = await global.CapCutDraftWriter.verifyPermission(handle, true);
          if (!isGranted) handle = await global.CapCutDraftWriter.pairCapCutDirectory();
        } else {
          handle = await global.CapCutDraftWriter.pairCapCutDirectory();
        }

        const projectData = { title, projectFolder, scenes, totalDurationUs, coverOffset, audioFileName: expectedAudioName };
        const res = await global.CapCutDraftWriter.writeCapCutDraft(handle, projectData, studioAudio, null);
        if (typeof updateStatus === 'function') updateStatus(`✓ Draf '${res.projectName}' berhasil diinjeksi ke CapCut!`);
        if (btnFlowDirectCapcut) btnFlowDirectCapcut.textContent = '✓ Draf CapCut Berhasil Dibuat!';
        if (global.PopupModal && typeof global.PopupModal.showSuccess === 'function') {
          await global.PopupModal.showSuccess({
            title: 'Draf CapCut Berhasil Dibuat!',
            subtitle: 'Injeksi 1-Klik dari Google Flow',
            badge: 'SUKSES 100%',
            projectName: res.projectName,
            message: 'Seluruh gambar adegan, subtitel SRT, dan trek audio telah terpasang rapi. Buka aplikasi CapCut Desktop untuk melihat linimasa video Anda.',
            confirmText: '✓ Mengerti & Tutup'
          });
        }
      } catch (err) {
        if (typeof updateStatus === 'function') updateStatus(`Gagal membuat draf CapCut: ${err.message || err}`);
        if (btnFlowDirectCapcut) btnFlowDirectCapcut.textContent = '🎬 Buat Draf CapCut Sekarang (1-Klik)';
      } finally {
        if (btnFlowDirectCapcut) btnFlowDirectCapcut.disabled = false;
      }
    });
  }

  global.PopupFlowQueue = {
    calculateProgress,
    isFlowRenderCompletelyFinished,
    getButtonStates,
    renderSceneCardsList,
    handleFlowJsonFilesImport,
    resetFlowQueue,
    clearFlowQueue,
    handleFlowDirectCapCutInjection
  };

})(typeof window !== 'undefined' ? window : globalThis);
